package bank.dao;

import bank.config.DatabaseConnection;
import bank.model.AccountStatusHistory;
import bank.model.BankAccount;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AccountDAO {
    public synchronized List<BankAccount> findAll() {
        if (DatabaseConnection.isMySqlMode()) {
            List<BankAccount> list = new ArrayList<>();
            String sql = "SELECT a.id, a.account_number, a.customer_id, c.full_name, a.balance, a.currency, a.status, a.created_at "
                    + "FROM accounts a JOIN customers c ON a.customer_id = c.id ORDER BY a.id DESC";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new BankAccount(
                            rs.getLong("id"), rs.getString("account_number"), rs.getLong("customer_id"),
                            rs.getString("full_name"), rs.getBigDecimal("balance"), rs.getString("currency"),
                            rs.getString("status"), rs.getTimestamp("created_at").toLocalDateTime()
                    ));
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi tải danh sách tài khoản: " + e.getMessage(), e);
            }
            return list;
        }
        return new ArrayList<>(DatabaseConnection.MEM_ACCOUNTS);
    }

    public synchronized BankAccount findByAccountNumber(String accNum) {
        if (accNum == null) return null;
        return findAll().stream()
                .filter(a -> a.getAccountNumber().equals(accNum.trim()))
                .findFirst().orElse(null);
    }

    public synchronized BankAccount insert(BankAccount acc) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "INSERT INTO accounts(account_number, customer_id, balance, currency, status) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, acc.getAccountNumber());
                ps.setLong(2, acc.getCustomerId());
                ps.setBigDecimal(3, acc.getBalance());
                ps.setString(4, acc.getCurrency());
                ps.setString(5, acc.getStatus());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) acc.setId(keys.getLong(1));
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi mở tài khoản: " + e.getMessage(), e);
            }
            return acc;
        }
        long nextId = DatabaseConnection.MEM_ACCOUNTS.stream().mapToLong(BankAccount::getId).max().orElse(0L) + 1;
        acc.setId(nextId);
        DatabaseConnection.MEM_ACCOUNTS.add(acc);
        DatabaseConnection.saveState();
        return acc;
    }

    public synchronized void updateStatus(long accountId, String newStatus, String reason, String actorUsername) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "UPDATE accounts SET status = ? WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, newStatus);
                ps.setLong(2, accountId);
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi cập nhật trạng thái tài khoản: " + e.getMessage(), e);
            }
            return;
        }
        for (BankAccount a : DatabaseConnection.MEM_ACCOUNTS) {
            if (a.getId() == accountId) {
                String oldStatus = a.getStatus();
                a.setStatus(newStatus);
                long nextHistId = DatabaseConnection.MEM_STATUS_HISTORY.stream()
                        .mapToLong(AccountStatusHistory::getId).max().orElse(0L) + 1;
                DatabaseConnection.MEM_STATUS_HISTORY.add(new AccountStatusHistory(
                        nextHistId, accountId, a.getAccountNumber(), oldStatus, newStatus,
                        reason, actorUsername, LocalDateTime.now()
                ));
                break;
            }
        }
        DatabaseConnection.saveState();
    }

    public synchronized List<AccountStatusHistory> findStatusHistory(Long accountId) {
        return DatabaseConnection.MEM_STATUS_HISTORY.stream()
                .filter(h -> accountId == null || h.getAccountId() == accountId)
                .sorted(Comparator.comparing(AccountStatusHistory::getChangedAt).reversed())
                .collect(Collectors.toList());
    }
}
