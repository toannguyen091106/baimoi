package bank.dao;

import bank.config.DatabaseConnection;
import bank.model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    public synchronized User findByUsername(String username) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "SELECT id, username, password_hash, full_name, role, status, created_at FROM users WHERE username = ?";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new User(rs.getLong("id"), rs.getString("username"), rs.getString("password_hash"),
                                rs.getString("full_name"), rs.getString("role"), rs.getString("status"),
                                rs.getTimestamp("created_at").toLocalDateTime());
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi truy vấn nhân viên: " + e.getMessage(), e);
            }
            return null;
        }
        return DatabaseConnection.MEM_USERS.stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username))
                .findFirst().orElse(null);
    }

    public synchronized List<User> findAll() {
        if (DatabaseConnection.isMySqlMode()) {
            List<User> list = new ArrayList<>();
            String sql = "SELECT id, username, password_hash, full_name, role, status, created_at FROM users ORDER BY id";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new User(rs.getLong("id"), rs.getString("username"), rs.getString("password_hash"),
                            rs.getString("full_name"), rs.getString("role"), rs.getString("status"),
                            rs.getTimestamp("created_at").toLocalDateTime()));
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi tải danh sách nhân viên: " + e.getMessage(), e);
            }
            return list;
        }
        return new ArrayList<>(DatabaseConnection.MEM_USERS);
    }

    public synchronized void insert(User user) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "INSERT INTO users(username, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPasswordHash());
                ps.setString(3, user.getFullName());
                ps.setString(4, user.getRole());
                ps.setString(5, user.getStatus());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("Không thể thêm nhân viên: " + e.getMessage(), e);
            }
            return;
        }
        long nextId = DatabaseConnection.MEM_USERS.stream().mapToLong(User::getId).max().orElse(0L) + 1;
        user.setId(nextId);
        DatabaseConnection.MEM_USERS.add(user);
        DatabaseConnection.saveState();
    }

    public synchronized void update(User user) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "UPDATE users SET full_name = ?, role = ?, status = ?, password_hash = ? WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, user.getFullName());
                ps.setString(2, user.getRole());
                ps.setString(3, user.getStatus());
                ps.setString(4, user.getPasswordHash());
                ps.setLong(5, user.getId());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("Không thể cập nhật nhân viên: " + e.getMessage(), e);
            }
            return;
        }
        for (User u : DatabaseConnection.MEM_USERS) {
            if (u.getId() == user.getId()) {
                u.setFullName(user.getFullName());
                u.setRole(user.getRole());
                u.setStatus(user.getStatus());
                u.setPasswordHash(user.getPasswordHash());
                break;
            }
        }
        DatabaseConnection.saveState();
    }
}
