package bank.dao;

import bank.config.DatabaseConnection;
import bank.model.Transaction;
import bank.model.TransactionEntry;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TransactionDAO {
    public synchronized List<Transaction> findAll() {
        if (DatabaseConnection.isMySqlMode()) {
            List<Transaction> list = new ArrayList<>();
            String sql = "SELECT t.id, t.transaction_code, t.transaction_type, "
                    + "t.source_account_id, sa.account_number AS src_num, "
                    + "t.destination_account_id, da.account_number AS dst_num, "
                    + "t.amount, t.description, t.status, t.created_by, u.username, t.created_at "
                    + "FROM transactions t "
                    + "LEFT JOIN accounts sa ON t.source_account_id = sa.id "
                    + "LEFT JOIN accounts da ON t.destination_account_id = da.id "
                    + "JOIN users u ON t.created_by = u.id "
                    + "ORDER BY t.created_at DESC, t.id DESC";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Long srcId = rs.getObject("source_account_id") != null ? rs.getLong("source_account_id") : null;
                    Long dstId = rs.getObject("destination_account_id") != null ? rs.getLong("destination_account_id") : null;
                    list.add(new Transaction(
                            rs.getLong("id"), rs.getString("transaction_code"), rs.getString("transaction_type"),
                            srcId, rs.getString("src_num") != null ? rs.getString("src_num") : "-",
                            dstId, rs.getString("dst_num") != null ? rs.getString("dst_num") : "-",
                            rs.getBigDecimal("amount"), rs.getString("description"), rs.getString("status"),
                            rs.getLong("created_by"), rs.getString("username"),
                            rs.getTimestamp("created_at").toLocalDateTime()
                    ));
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi tải lịch sử giao dịch: " + e.getMessage(), e);
            }
            return list;
        }
        List<Transaction> sorted = new ArrayList<>(DatabaseConnection.MEM_TRANSACTIONS);
        sorted.sort(Comparator.comparing(Transaction::getCreatedAt).reversed());
        return sorted;
    }

    public synchronized List<TransactionEntry> findEntriesByTransactionId(long txId) {
        if (DatabaseConnection.isMySqlMode()) {
            List<TransactionEntry> list = new ArrayList<>();
            String sql = "SELECT e.id, e.transaction_id, e.account_id, a.account_number, e.entry_type, e.amount, e.balance_after, e.created_at "
                    + "FROM transaction_entries e JOIN accounts a ON e.account_id = a.id WHERE e.transaction_id = ? ORDER BY e.id";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setLong(1, txId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(new TransactionEntry(
                                rs.getLong("id"), rs.getLong("transaction_id"), rs.getLong("account_id"),
                                rs.getString("account_number"), rs.getString("entry_type"),
                                rs.getBigDecimal("amount"), rs.getBigDecimal("balance_after"),
                                rs.getTimestamp("created_at").toLocalDateTime()
                        ));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi tải bút toán: " + e.getMessage(), e);
            }
            return list;
        }
        return DatabaseConnection.MEM_ENTRIES.stream()
                .filter(e -> e.getTransactionId() == txId)
                .collect(Collectors.toList());
    }
}
