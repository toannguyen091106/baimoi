package bank.dao;

import bank.config.DatabaseConnection;
import bank.model.BankAccount;
import bank.model.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    public synchronized List<Customer> findAll() {
        if (DatabaseConnection.isMySqlMode()) {
            List<Customer> list = new ArrayList<>();
            String sql = "SELECT id, customer_code, full_name, date_of_birth, phone, email, address, status, created_at FROM customers ORDER BY id DESC";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapCustomer(rs));
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi tải khách hàng: " + e.getMessage(), e);
            }
            return list;
        }
        return new ArrayList<>(DatabaseConnection.MEM_CUSTOMERS);
    }

    public synchronized Customer findByCode(String code) {
        if (code == null || code.isBlank()) return null;
        return findAll().stream()
                .filter(c -> c.getCustomerCode().equalsIgnoreCase(code.trim()))
                .findFirst().orElse(null);
    }

    public synchronized Customer findByPhone(String phone, Long excludeCustomerId) {
        if (phone == null || phone.isBlank()) return null;
        String normalized = phone.trim();
        return findAll().stream()
                .filter(c -> (excludeCustomerId == null || c.getId() != excludeCustomerId)
                        && c.getPhone() != null
                        && c.getPhone().trim().equalsIgnoreCase(normalized))
                .findFirst().orElse(null);
    }

    public synchronized Customer findByEmail(String email, Long excludeCustomerId) {
        if (email == null || email.isBlank()) return null;
        String normalized = email.trim();
        return findAll().stream()
                .filter(c -> (excludeCustomerId == null || c.getId() != excludeCustomerId)
                        && c.getEmail() != null
                        && c.getEmail().trim().equalsIgnoreCase(normalized))
                .findFirst().orElse(null);
    }

    public synchronized void insert(Customer c) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "INSERT INTO customers(customer_code, full_name, date_of_birth, phone, email, address, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getCustomerCode());
                ps.setString(2, c.getFullName());
                ps.setDate(3, c.getDateOfBirth() != null ? java.sql.Date.valueOf(c.getDateOfBirth()) : null);
                ps.setString(4, c.getPhone());
                ps.setString(5, c.getEmail());
                ps.setString(6, c.getAddress());
                ps.setString(7, c.getStatus());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("Không thể thêm khách hàng: " + e.getMessage(), e);
            }
            return;
        }
        long nextId = DatabaseConnection.MEM_CUSTOMERS.stream().mapToLong(Customer::getId).max().orElse(0L) + 1;
        c.setId(nextId);
        DatabaseConnection.MEM_CUSTOMERS.add(c);
        DatabaseConnection.saveState();
    }

    public synchronized void update(Customer c) {
        if (DatabaseConnection.isMySqlMode()) {
            String sql = "UPDATE customers SET full_name = ?, date_of_birth = ?, phone = ?, email = ?, address = ?, status = ? WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getFullName());
                ps.setDate(2, c.getDateOfBirth() != null ? java.sql.Date.valueOf(c.getDateOfBirth()) : null);
                ps.setString(3, c.getPhone());
                ps.setString(4, c.getEmail());
                ps.setString(5, c.getAddress());
                ps.setString(6, c.getStatus());
                ps.setLong(7, c.getId());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("Không thể cập nhật khách hàng: " + e.getMessage(), e);
            }
            return;
        }
        for (Customer existing : DatabaseConnection.MEM_CUSTOMERS) {
            if (existing.getId() == c.getId()) {
                existing.setFullName(c.getFullName());
                existing.setDateOfBirth(c.getDateOfBirth());
                existing.setPhone(c.getPhone());
                existing.setEmail(c.getEmail());
                existing.setAddress(c.getAddress());
                existing.setStatus(c.getStatus());
                break;
            }
        }
        for (BankAccount acc : DatabaseConnection.MEM_ACCOUNTS) {
            if (acc.getCustomerId() == c.getId()) {
                acc.setCustomerName(c.getFullName());
            }
        }
        DatabaseConnection.saveState();
    }

    private Customer mapCustomer(ResultSet rs) throws SQLException {
        java.sql.Date dob = rs.getDate("date_of_birth");
        java.sql.Timestamp created = rs.getTimestamp("created_at");
        return new Customer(
                rs.getLong("id"),
                rs.getString("customer_code"),
                rs.getString("full_name"),
                dob != null ? dob.toLocalDate() : LocalDate.now(),
                rs.getString("phone"),
                rs.getString("email"),
                rs.getString("address"),
                rs.getString("status"),
                created != null ? created.toLocalDateTime() : LocalDateTime.now()
        );
    }
}
