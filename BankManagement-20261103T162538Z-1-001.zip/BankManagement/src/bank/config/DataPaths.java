package bank.config;

import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Vị trí dữ liệu gắn với dự án, không phụ thuộc thư mục mở terminal. */
public final class DataPaths {
    private DataPaths() {}

    public static Path projectDirectory() {
        String configured = System.getProperty("bank.app.dir");
        if (configured != null && !configured.isBlank()) {
            return Path.of(configured).toAbsolutePath().normalize();
        }
        try {
            Path location = Path.of(DataPaths.class.getProtectionDomain().getCodeSource()
                    .getLocation().toURI()).toAbsolutePath().normalize();
            if (Files.isRegularFile(location)) location = location.getParent();
            for (Path parent = location; parent != null; parent = parent.getParent()) {
                if (Files.isRegularFile(parent.resolve("run.bat")) && Files.isDirectory(parent.resolve("src"))) {
                    return parent;
                }
            }
            throw new IllegalStateException("Không xác định được thư mục dự án từ " + location
                    + ". Hãy mở đúng thư mục BankManagement hoặc đặt -Dbank.app.dir.");
        } catch (URISyntaxException | SecurityException e) {
            throw new IllegalStateException("Không xác định được vị trí lưu dữ liệu của ứng dụng.", e);
        }
    }

    public static Path dataDirectory() {
        String configured = System.getProperty("bank.data.dir");
        if (configured != null && !configured.isBlank()) {
            return Path.of(configured).toAbsolutePath().normalize();
        }
        return projectDirectory().resolve("data");
    }

    public static Path storageFile() {
        return dataDirectory().resolve("bank_data_store.ser");
    }

    static Path legacyStorageFile() {
        // Đường dẫn dữ liệu riêng dùng cho kiểm tra không tự nhập dữ liệu dự án thật.
        String explicitData = System.getProperty("bank.data.dir");
        String explicitApp = System.getProperty("bank.app.dir");
        if (explicitData != null && !explicitData.isBlank()
                && (explicitApp == null || explicitApp.isBlank())) return null;
        return projectDirectory().resolve("bank_data_store.ser");
    }
}
