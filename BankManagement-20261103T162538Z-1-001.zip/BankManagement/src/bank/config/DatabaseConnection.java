package bank.config;

import bank.model.AccountStatusHistory;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.PersistentDataStore;
import bank.model.Transaction;
import bank.model.TransactionEntry;
import bank.model.User;
import bank.service.AuthService;
import bank.util.PasswordUtils;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DatabaseConnection {
    private static final String URL = System.getenv().getOrDefault(
            "BANK_DB_URL", "jdbc:mysql://localhost:3306/bank_management");
    private static final String USER = System.getenv().getOrDefault("BANK_DB_USER", "bank_app");
    private static final String PASSWORD = System.getenv("BANK_DB_PASSWORD");
    private static final Path STORAGE_FILE = DataPaths.storageFile();
    private static final Path BACKUP_FILE = STORAGE_FILE.resolveSibling("bank_data_store.ser.bak");
    private static final Path LOCK_FILE = STORAGE_FILE.resolveSibling("bank_data_store.lock");
    private static boolean useMySql;
    private static boolean initialized;
    private static FileChannel lockChannel;
    private static FileLock storageLock;
    private static String recoveryMessage;

    public static final List<User> MEM_USERS = new ArrayList<>();
    public static final List<Customer> MEM_CUSTOMERS = new ArrayList<>();
    public static final List<BankAccount> MEM_ACCOUNTS = new ArrayList<>();
    public static final List<AccountStatusHistory> MEM_STATUS_HISTORY = new ArrayList<>();
    public static final List<Transaction> MEM_TRANSACTIONS = new ArrayList<>();
    public static final List<TransactionEntry> MEM_ENTRIES = new ArrayList<>();
    public static final Map<String, String> QUICK_LOGIN_PASSWORDS = new LinkedHashMap<>();
    private static String lastLoginUsername = "admin";
    private static boolean rememberLastLogin = true;

    public static synchronized void initialize() {
        if (initialized) return;
        recoveryMessage = null;
        if (PASSWORD != null && !PASSWORD.isBlank()) {
            try (Connection conn = getConnection()) {
                useMySql = true;
                initialized = true;
                return;
            } catch (SQLException e) {
                System.err.println("[Database] Không kết nối được MySQL, sử dụng dữ liệu cục bộ: " + e.getMessage());
            }
        }
        useMySql = false;
        try {
            acquireStorageLock();
            if (!loadSavedState()) {
                clearMemory();
                seedDefaultData();
            }
            initialized = true;
            saveState();
        } catch (Exception e) {
            initialized = false;
            releaseStorageLock();
            if (e instanceof RuntimeException) throw (RuntimeException) e;
            throw new IllegalStateException("Không thể mở dữ liệu: " + STORAGE_FILE, e);
        }
    }

    public static boolean isMySqlMode() { return useMySql; }
    public static String getStorageFilePath() { return STORAGE_FILE.toString(); }
    public static synchronized String getRecoveryMessage() { return recoveryMessage; }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** Đọc lại dữ liệu và giữ khóa ghi; không tạo dữ liệu mẫu nếu chưa có tệp. */
    public static synchronized boolean loadStateFromDisk() {
        if (useMySql) return true;
        try {
            acquireStorageLock();
            boolean found = loadSavedState();
            initialized = found;
            if (!found) releaseStorageLock();
            return found;
        } catch (Exception e) {
            initialized = false;
            releaseStorageLock();
            if (e instanceof RuntimeException) throw (RuntimeException) e;
            throw new IllegalStateException("Không thể đọc dữ liệu; các tệp gốc được giữ nguyên: " + STORAGE_FILE, e);
        }
    }

    private static boolean loadSavedState() throws IOException, ClassNotFoundException {
        if (Files.exists(STORAGE_FILE)) {
            try {
                apply(readStore(STORAGE_FILE));
                System.out.println("[Persistence] Đã tải dữ liệu: " + STORAGE_FILE);
                return true;
            } catch (IOException | ClassNotFoundException | RuntimeException primaryFailure) {
                if (!Files.exists(BACKUP_FILE)) {
                    throw new IOException("Tệp dữ liệu không đọc được và chưa có bản sao lưu. Không khởi tạo lại: "
                            + STORAGE_FILE, primaryFailure);
                }
                PersistentDataStore backup;
                try {
                    backup = readStore(BACKUP_FILE);
                } catch (Exception backupFailure) {
                    IOException failure = new IOException("Tệp dữ liệu và bản sao lưu đều không đọc được. "
                            + "Các tệp được giữ nguyên; không khởi tạo lại dữ liệu mẫu.", primaryFailure);
                    failure.addSuppressed(backupFailure);
                    throw failure;
                }
                Path preserved = Files.createTempFile(STORAGE_FILE.getParent(), "bank_data_store.corrupt-", ".ser");
                Files.copy(STORAGE_FILE, preserved, StandardCopyOption.REPLACE_EXISTING);
                writeStoreAtomically(STORAGE_FILE, backup);
                apply(backup);
                recoveryMessage = "Đã khôi phục dữ liệu từ bản sao lưu. Tệp lỗi được giữ tại " + preserved;
                System.err.println("[Persistence] " + recoveryMessage);
                return true;
            }
        }
        if (Files.exists(BACKUP_FILE)) {
            PersistentDataStore backup = readStore(BACKUP_FILE);
            writeStoreAtomically(STORAGE_FILE, backup);
            apply(backup);
            recoveryMessage = "Đã khôi phục tệp dữ liệu bị thiếu từ bản sao lưu: " + BACKUP_FILE;
            System.err.println("[Persistence] " + recoveryMessage);
            return true;
        }
        Path legacy = DataPaths.legacyStorageFile();
        if (legacy != null && !legacy.equals(STORAGE_FILE) && Files.exists(legacy)) {
            PersistentDataStore imported = readStore(legacy); // Kiểm tra trước khi nhập, không sửa tệp cũ.
            copyAtomically(legacy, STORAGE_FILE);
            apply(imported);
            System.out.println("[Persistence] Đã nhập dữ liệu cũ từ " + legacy);
            return true;
        }
        return false;
    }

    private static PersistentDataStore readStore(Path file) throws IOException, ClassNotFoundException {
        // Đóng cả tệp nếu bộ đọc từ chối header hỏng ngay trong constructor.
        try (FileInputStream fileInput = new FileInputStream(file.toFile());
             CompatibleObjectInputStream input = new CompatibleObjectInputStream(fileInput)) {
            Object value = input.readObject();
            if (!(value instanceof PersistentDataStore)) throw new IOException("Không đúng định dạng dữ liệu ngân hàng: " + file);
            PersistentDataStore store = (PersistentDataStore) value;
            if (store.users == null || store.users.isEmpty()) throw new IOException("Dữ liệu không có tài khoản đăng nhập.");
            checkList(store.users, User.class);
            checkList(store.customers, Customer.class);
            checkList(store.accounts, BankAccount.class);
            checkList(store.transactions, Transaction.class);
            checkList(store.entries, TransactionEntry.class);
            if (store.statusHistories != null) checkList(store.statusHistories, AccountStatusHistory.class);
            return store;
        }
    }

    private static void checkList(List<?> values, Class<?> expected) throws IOException {
        if (values == null) throw new IOException("Thiếu danh sách dữ liệu " + expected.getSimpleName());
        for (Object value : values) {
            if (!expected.isInstance(value)) throw new IOException("Sai cấu trúc dữ liệu " + expected.getSimpleName());
        }
    }

    private static void apply(PersistentDataStore store) {
        clearMemory();
        MEM_USERS.addAll(store.users);
        MEM_CUSTOMERS.addAll(store.customers);
        MEM_ACCOUNTS.addAll(store.accounts);
        if (store.statusHistories != null) MEM_STATUS_HISTORY.addAll(store.statusHistories);
        MEM_TRANSACTIONS.addAll(store.transactions);
        MEM_ENTRIES.addAll(store.entries);
        lastLoginUsername = store.lastLoginUsername == null ? "" : store.lastLoginUsername;
        rememberLastLogin = store.rememberLastLogin;
    }

    private static void clearMemory() {
        MEM_USERS.clear(); MEM_CUSTOMERS.clear(); MEM_ACCOUNTS.clear(); MEM_STATUS_HISTORY.clear();
        MEM_TRANSACTIONS.clear(); MEM_ENTRIES.clear(); QUICK_LOGIN_PASSWORDS.clear();
    }

    private static PersistentDataStore snapshot() {
        PersistentDataStore store = new PersistentDataStore();
        store.users = new ArrayList<>(MEM_USERS);
        store.customers = new ArrayList<>(MEM_CUSTOMERS);
        store.accounts = new ArrayList<>(MEM_ACCOUNTS);
        store.statusHistories = new ArrayList<>(MEM_STATUS_HISTORY);
        store.transactions = new ArrayList<>(MEM_TRANSACTIONS);
        store.entries = new ArrayList<>(MEM_ENTRIES);
        store.quickLoginPasswords = new LinkedHashMap<>();
        store.lastLoginUsername = lastLoginUsername;
        store.lastLoginPassword = "";
        store.rememberLastLogin = rememberLastLogin;
        return store;
    }

    /** Lưu ngay sau thay đổi; chỉ báo thành công khi dữ liệu đã được thay thế trên đĩa. */
    public static synchronized void saveState() {
        if (useMySql && initialized) return;
        if (!initialized || storageLock == null || !storageLock.isValid()) {
            throw new IllegalStateException("Dữ liệu chưa được mở an toàn; chưa thực hiện lưu.");
        }
        try {
            PersistentDataStore current = snapshot();
            if (current.users.isEmpty()) throw new IOException("Không lưu dữ liệu trống chưa khởi tạo.");
            if (Files.exists(STORAGE_FILE)) {
                readStore(STORAGE_FILE); // Không thay bản sao lưu tốt bằng một tệp đã hỏng.
                copyAtomically(STORAGE_FILE, BACKUP_FILE);
            } else if (!Files.exists(BACKUP_FILE)) {
                writeStoreAtomically(BACKUP_FILE, current);
            }
            writeStoreAtomically(STORAGE_FILE, current);
        } catch (Exception e) {
            throw new IllegalStateException("Không thể lưu dữ liệu vào " + STORAGE_FILE
                    + ". Thay đổi chưa được xác nhận lưu; hãy kiểm tra quyền ghi và dung lượng đĩa.", e);
        }
    }

    private static void writeStoreAtomically(Path target, PersistentDataStore store) throws IOException {
        Path temporary = Files.createTempFile(target.getParent(), target.getFileName() + ".", ".tmp");
        try {
            try (FileOutputStream file = new FileOutputStream(temporary.toFile());
                 ObjectOutputStream output = new ObjectOutputStream(file)) {
                output.writeObject(store);
                output.flush();
                file.getFD().sync();
            }
            replace(temporary, target);
        } finally {
            deleteTemporary(temporary);
        }
    }

    private static void copyAtomically(Path source, Path target) throws IOException {
        Path temporary = Files.createTempFile(target.getParent(), target.getFileName() + ".", ".tmp");
        try {
            try (FileInputStream input = new FileInputStream(source.toFile());
                 FileOutputStream output = new FileOutputStream(temporary.toFile())) {
                input.transferTo(output);
                output.flush();
                output.getFD().sync();
            }
            replace(temporary, target);
        } finally {
            deleteTemporary(temporary);
        }
    }

    private static void replace(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void deleteTemporary(Path temporary) {
        try { Files.deleteIfExists(temporary); }
        catch (IOException e) { System.err.println("[Persistence] Chưa xóa được tệp tạm: " + temporary); }
    }

    private static void acquireStorageLock() throws IOException {
        if (storageLock != null && storageLock.isValid()) return;
        Files.createDirectories(STORAGE_FILE.getParent());
        lockChannel = FileChannel.open(LOCK_FILE, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        try {
            storageLock = lockChannel.tryLock();
        } catch (OverlappingFileLockException e) {
            releaseStorageLock();
            throw new IllegalStateException("Dữ liệu đang được một cửa sổ ứng dụng khác sử dụng. Hãy dùng cửa sổ đã mở.", e);
        }
        if (storageLock == null) {
            releaseStorageLock();
            throw new IllegalStateException("Ứng dụng đã được mở. Hãy đóng cửa sổ cũ trước khi chạy lại để tránh ghi đè dữ liệu.");
        }
    }

    private static void releaseStorageLock() {
        try { if (storageLock != null && storageLock.isValid()) storageLock.release(); }
        catch (IOException e) { System.err.println("[Persistence] Không giải phóng được khóa dữ liệu: " + e.getMessage()); }
        storageLock = null;
        try { if (lockChannel != null) lockChannel.close(); }
        catch (IOException e) { System.err.println("[Persistence] Không đóng được tệp khóa: " + e.getMessage()); }
        lockChannel = null;
    }

    /** Chỉ lưu khi đã mở dữ liệu thành công, sau đó luôn giải phóng khóa. */
    public static synchronized void shutdown() {
        try {
            if (initialized && !useMySql && storageLock != null && storageLock.isValid()) saveState();
        } catch (RuntimeException e) {
            System.err.println("[Persistence] " + e.getMessage());
        } finally {
            initialized = false;
            releaseStorageLock();
        }
    }

    /** Chỉ thao tác quản trị được chủ động thay dữ liệu bằng mẫu. */
    public static synchronized void resetToDefaultData() {
        AuthService.requireAdmin();
        if (useMySql) throw new IllegalStateException("Khôi phục dữ liệu mẫu chỉ dùng cho chế độ lưu cục bộ.");
        if (!initialized || storageLock == null || !storageLock.isValid()) {
            throw new IllegalStateException("Dữ liệu chưa được mở an toàn; không thể khôi phục.");
        }
        PersistentDataStore before = snapshot();
        try {
            if (Files.exists(STORAGE_FILE)) {
                Path backup = Files.createTempFile(STORAGE_FILE.getParent(), "bank_data_store.before-reset-", ".ser");
                copyAtomically(STORAGE_FILE, backup);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Không thể sao lưu dữ liệu; chưa thực hiện khôi phục.", e);
        }
        clearMemory();
        seedDefaultData();
        try {
            saveState();
        } catch (RuntimeException e) {
            apply(before);
            throw e;
        }
        AuthService.logout();
    }

    public static synchronized void updateQuickLoginCredential(String username, String rawPassword) {
        QUICK_LOGIN_PASSWORDS.clear();
        saveState();
    }

    public static synchronized String getQuickPassword(String username) { return ""; }

    public static synchronized void saveLastLogin(String username, String rawPassword, boolean remember) {
        String previousUsername = lastLoginUsername;
        boolean previousRemember = rememberLastLogin;
        lastLoginUsername = remember && username != null ? username.trim() : "";
        rememberLastLogin = remember;
        QUICK_LOGIN_PASSWORDS.clear();
        try { saveState(); }
        catch (RuntimeException e) {
            lastLoginUsername = previousUsername;
            rememberLastLogin = previousRemember;
            throw e;
        }
    }

    public static String getLastLoginUsername() { return rememberLastLogin ? lastLoginUsername : ""; }
    public static String getLastLoginPassword() { return ""; }
    public static boolean isRememberLastLogin() { return rememberLastLogin; }

    private static void seedDefaultData() {
        LocalDateTime now = LocalDateTime.now();
        MEM_USERS.add(new User(1L, "admin", PasswordUtils.hashPassword("admin123"),
                "Nguyễn Quản Trị", "ADMIN", "ACTIVE", now.minusDays(30)));
        MEM_USERS.add(new User(2L, "staff", PasswordUtils.hashPassword("staff123"),
                "Trần Giao Dịch Viên", "STAFF", "ACTIVE", now.minusDays(20)));
        MEM_USERS.add(new User(3L, "teller02", PasswordUtils.hashPassword("staff123"),
                "Phạm Minh Anh", "STAFF", "ACTIVE", now.minusDays(10)));

        lastLoginUsername = "admin";
        rememberLastLogin = true;

        MEM_CUSTOMERS.add(new Customer(1L, "KH001", "Nguyễn Văn A", LocalDate.of(1995, 5, 12),
                "0901234567", "nguyenvana@gmail.com", "Cầu Giấy, Hà Nội", "ACTIVE", now.minusDays(15)));
        MEM_CUSTOMERS.add(new Customer(2L, "KH002", "Trần Văn B", LocalDate.of(1998, 8, 20),
                "0912345678", "tranvanb@gmail.com", "Hà Đông, Hà Nội", "ACTIVE", now.minusDays(14)));
        MEM_CUSTOMERS.add(new Customer(3L, "KH003", "Lê Thị C", LocalDate.of(2000, 11, 9),
                "0987654321", "lethic@gmail.com", "Đống Đa, Hà Nội", "ACTIVE", now.minusDays(10)));
        MEM_CUSTOMERS.add(new Customer(4L, "KH004", "Hoàng Đức Duy", LocalDate.of(2003, 4, 18),
                "0355582109", "duyhoang@gmail.com", "Thanh Xuân, Hà Nội", "ACTIVE", now.minusDays(5)));

        MEM_ACCOUNTS.add(new BankAccount(1L, "1000000001", 1L, "Nguyễn Văn A",
                new BigDecimal("4500000"), "VND", "ACTIVE", now.minusDays(15)));
        MEM_ACCOUNTS.add(new BankAccount(2L, "1000000002", 2L, "Trần Văn B",
                new BigDecimal("2000000"), "VND", "ACTIVE", now.minusDays(14)));
        MEM_ACCOUNTS.add(new BankAccount(3L, "1000000003", 3L, "Lê Thị C",
                new BigDecimal("12500000"), "VND", "LOCKED", now.minusDays(10)));
        MEM_ACCOUNTS.add(new BankAccount(4L, "1000000004", 4L, "Hoàng Đức Duy",
                new BigDecimal("8200000"), "VND", "ACTIVE", now.minusDays(5)));

        MEM_STATUS_HISTORY.add(new AccountStatusHistory(1L, 3L, "1000000003", "ACTIVE", "LOCKED",
                "Khách hàng báo mất thẻ và yêu cầu tạm khóa bảo vệ số dư", "admin", now.minusDays(8)));

        MEM_TRANSACTIONS.add(new Transaction(1L, "TXN20261001", "DEPOSIT",
                null, "-", 1L, "1000000001", new BigDecimal("6000000"),
                "Nộp tiền mở tài khoản KH001", "SUCCESS", 1L, "admin", now.minusDays(4)));
        MEM_ENTRIES.add(new TransactionEntry(1L, 1L, 1L, "1000000001",
                "CREDIT", new BigDecimal("6000000"), new BigDecimal("6000000"), now.minusDays(4)));

        MEM_TRANSACTIONS.add(new Transaction(2L, "TXN20261002", "DEPOSIT",
                null, "-", 2L, "1000000002", new BigDecimal("1500000"),
                "Nộp tiền mở tài khoản KH002", "SUCCESS", 1L, "admin", now.minusDays(3)));
        MEM_ENTRIES.add(new TransactionEntry(2L, 2L, 2L, "1000000002",
                "CREDIT", new BigDecimal("1500000"), new BigDecimal("1500000"), now.minusDays(3)));

        MEM_TRANSACTIONS.add(new Transaction(3L, "TXN20261003", "WITHDRAW",
                1L, "1000000001", null, "-", new BigDecimal("1000000"),
                "Rút tiền mặt tại quầy", "SUCCESS", 2L, "staff", now.minusDays(2)));
        MEM_ENTRIES.add(new TransactionEntry(3L, 3L, 1L, "1000000001",
                "DEBIT", new BigDecimal("1000000"), new BigDecimal("5000000"), now.minusDays(2)));

        MEM_TRANSACTIONS.add(new Transaction(4L, "TXN20261004", "TRANSFER",
                1L, "1000000001", 2L, "1000000002", new BigDecimal("500000"),
                "Chuyển khoản thanh toán hóa đơn", "SUCCESS", 2L, "staff", now.minusHours(5)));
        MEM_ENTRIES.add(new TransactionEntry(4L, 4L, 1L, "1000000001",
                "DEBIT", new BigDecimal("500000"), new BigDecimal("4500000"), now.minusHours(5)));
        MEM_ENTRIES.add(new TransactionEntry(5L, 4L, 2L, "1000000002",
                "CREDIT", new BigDecimal("500000"), new BigDecimal("2000000"), now.minusHours(5)));

        MEM_TRANSACTIONS.add(new Transaction(5L, "TXN20261005", "DEPOSIT",
                null, "-", 4L, "1000000004", new BigDecimal("8200000"),
                "Tiết kiệm linh hoạt tại quầy", "SUCCESS", 2L, "staff", now.minusHours(2)));
        MEM_ENTRIES.add(new TransactionEntry(6L, 5L, 4L, "1000000004",
                "CREDIT", new BigDecimal("8200000"), new BigDecimal("8200000"), now.minusHours(2)));
    }
}
