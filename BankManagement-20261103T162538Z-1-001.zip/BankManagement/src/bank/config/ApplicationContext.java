package bank.config;

import bank.dao.AccountDAO;
import bank.dao.CustomerDAO;
import bank.dao.TransactionDAO;
import bank.dao.UserDAO;
import bank.service.AccountService;
import bank.service.AuthService;
import bank.service.CustomerService;
import bank.service.TransactionService;
import bank.web.BankRestController;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

public class ApplicationContext {
    private static final Map<Class<?>, Object> BEANS = new ConcurrentHashMap<>();
    private static HttpServer webServer;
    private static int activePort = 8080;

    public static void run(Class<?> primarySource, String[] args) {
        printBanner();
        DatabaseConnection.initialize();

        // Đăng ký Singleton Beans theo đúng thứ tự phụ thuộc (Dependency Injection)
        registerBean(UserDAO.class, new UserDAO());
        registerBean(CustomerDAO.class, new CustomerDAO());
        registerBean(AccountDAO.class, new AccountDAO());
        registerBean(TransactionDAO.class, new TransactionDAO());

        registerBean(AuthService.class, new AuthService());
        registerBean(CustomerService.class, new CustomerService());
        registerBean(TransactionService.class, new TransactionService());
        registerBean(AccountService.class, new AccountService());
        registerBean(BankRestController.class, new BankRestController());

        // Đảm bảo luôn lưu dữ liệu khi tắt JVM
        Runtime.getRuntime().addShutdownHook(new Thread(DatabaseConnection::shutdown, "bank-save-on-exit"));

        startEmbeddedWebServer();
    }

    public static <T> void registerBean(Class<T> clazz, T instance) {
        BEANS.put(clazz, instance);
    }

    @SuppressWarnings("unchecked")
    public static <T> T getBean(Class<T> clazz) {
        return (T) BEANS.get(clazz);
    }

    public static int getActivePort() {
        return activePort;
    }

    private static void printBanner() {
        System.out.println(" ==============================================================");
        System.out.println("  CORE BANKING SYSTEM  (Swing UI + Web thong ke cuc bo)  v4.0.0");
        System.out.println(" ==============================================================");
    }

    private static void startEmbeddedWebServer() {
        int[] candidatePorts = {8080, 8081, 8090};
        for (int port : candidatePorts) {
            try {
                webServer = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
                activePort = port;
                BankRestController controller = getBean(BankRestController.class);
                webServer.createContext("/", controller::handleDashboardPage);
                webServer.createContext("/api/summary", controller::handleApiSummary);
                webServer.createContext("/api/accounts", controller::handleApiAccounts);
                webServer.createContext("/api/transactions", controller::handleApiTransactions);
                webServer.setExecutor(Executors.newCachedThreadPool());
                webServer.start();
                System.out.println("[Web] Embedded HTTP Server started at http://localhost:" + activePort);
                break;
            } catch (Exception ignored) {
            }
        }
    }
}
