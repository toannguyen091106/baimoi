package bank.config;

import bank.model.AccountStatusHistory;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.PersistentDataStore;
import bank.model.Transaction;
import bank.model.TransactionEntry;
import bank.model.User;
import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.io.ObjectStreamField;
import java.util.Map;
import java.util.Objects;

/** Đọc dữ liệu được lưu trước khi các lớp được tách khỏi test.test. */
public final class CompatibleObjectInputStream extends ObjectInputStream {
    private static final Map<String, Class<?>> LEGACY_CLASSES = Map.of(
            "test.test$User", User.class,
            "test.test$Customer", Customer.class,
            "test.test$BankAccount", BankAccount.class,
            "test.test$AccountStatusHistory", AccountStatusHistory.class,
            "test.test$Transaction", Transaction.class,
            "test.test$TransactionEntry", TransactionEntry.class,
            "test.test$PersistentDataStore", PersistentDataStore.class);

    private boolean legacyFormatRead;

    public CompatibleObjectInputStream(InputStream input) throws IOException {
        super(input);
    }

    public boolean wasLegacyFormatRead() {
        return legacyFormatRead;
    }

    @Override
    protected ObjectStreamClass readClassDescriptor() throws IOException, ClassNotFoundException {
        ObjectStreamClass storedDescriptor = super.readClassDescriptor();
        Class<?> replacementClass = LEGACY_CLASSES.get(storedDescriptor.getName());
        if (replacementClass == null) {
            return storedDescriptor;
        }

        ObjectStreamClass currentDescriptor = ObjectStreamClass.lookup(replacementClass);
        validateDescriptor(storedDescriptor, currentDescriptor);
        legacyFormatRead = true;
        return currentDescriptor;
    }

    private static void validateDescriptor(ObjectStreamClass stored, ObjectStreamClass current)
            throws InvalidClassException {
        if (stored.getSerialVersionUID() != current.getSerialVersionUID()) {
            throw new InvalidClassException(stored.getName(), "Phiên bản dữ liệu cũ không tương thích");
        }

        ObjectStreamField[] storedFields = stored.getFields();
        ObjectStreamField[] currentFields = current.getFields();
        if (storedFields.length != currentFields.length) {
            throw new InvalidClassException(stored.getName(), "Số lượng trường dữ liệu đã thay đổi");
        }

        for (int index = 0; index < storedFields.length; index++) {
            ObjectStreamField storedField = storedFields[index];
            ObjectStreamField currentField = currentFields[index];
            if (!storedField.getName().equals(currentField.getName())
                    || storedField.getTypeCode() != currentField.getTypeCode()
                    || !Objects.equals(storedField.getTypeString(), currentField.getTypeString())) {
                throw new InvalidClassException(stored.getName(),
                        "Trường dữ liệu không tương thích: " + storedField.getName());
            }
        }
    }
}
