package bank.service;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.dao.AccountDAO;
import bank.dao.CustomerDAO;
import bank.model.AccountStatusHistory;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.User;
import bank.util.MoneyUtils;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AccountService {
    private AccountDAO accountDAO() { return ApplicationContext.getBean(AccountDAO.class); }
    private CustomerDAO customerDAO() { return ApplicationContext.getBean(CustomerDAO.class); }
    private TransactionService transactionService() { return ApplicationContext.getBean(TransactionService.class); }

    public List<BankAccount> getAllAccounts() {
        return accountDAO().findAll();
    }

    public BankAccount findByAccountNumber(String accNum) {
        return accountDAO().findByAccountNumber(accNum);
    }

    public String generateUniqueAccountNumber() {
        long max = 1000000000L;
        for (BankAccount a : accountDAO().findAll()) {
            try {
                long val = Long.parseLong(a.getAccountNumber());
                if (val > max) max = val;
            } catch (NumberFormatException ignored) {
            }
        }
        return String.valueOf(max + 1);
    }

    public String checkAccountEligibilityError(Customer customer) {
        if (customer == null) {
            return "Vui lòng chọn khách hàng.";
        }
        if (!"ACTIVE".equalsIgnoreCase(customer.getStatus())) {
            return "Khách hàng đang ngừng hoạt động.";
        }

        String phone = customer.getPhone() == null ? "" : customer.getPhone().trim();
        String email = customer.getEmail() == null ? "" : customer.getEmail().trim();

        List<BankAccount> existingAccounts = accountDAO().findAll();
        Map<Long, Customer> customerMap = customerDAO().findAll().stream()
                .collect(Collectors.toMap(Customer::getId, c -> c, (a, b) -> a));

        for (BankAccount acc : existingAccounts) {
            if ("CLOSED".equalsIgnoreCase(acc.getStatus())) continue;

            if (acc.getCustomerId() == customer.getId()) {
                return "Khách hàng '" + customer.getFullName() + "' (" + customer.getCustomerCode()
                        + ") đã có tài khoản ngân hàng số " + acc.getAccountNumber()
                        + ". Mỗi số điện thoại / email chỉ được tạo 1 tài khoản duy nhất!";
            }

            Customer owner = customerMap.get(acc.getCustomerId());
            if (owner != null) {
                if (!phone.isEmpty() && owner.getPhone() != null && owner.getPhone().trim().equalsIgnoreCase(phone)) {
                    return "Số điện thoại '" + phone + "' đã được dùng để mở tài khoản số "
                            + acc.getAccountNumber() + " (Chủ TK: " + owner.getFullName() + " - " + owner.getCustomerCode()
                            + "). Dù dùng tên khác nhưng trùng SĐT vẫn không thể tạo thêm tài khoản ngân hàng!";
                }
                if (!email.isEmpty() && owner.getEmail() != null && owner.getEmail().trim().equalsIgnoreCase(email)) {
                    return "Email '" + email + "' đã được dùng để mở tài khoản số "
                            + acc.getAccountNumber() + " (Chủ TK: " + owner.getFullName() + " - " + owner.getCustomerCode()
                            + "). Dù dùng tên khác nhưng trùng Email vẫn không thể tạo thêm tài khoản ngân hàng!";
                }
            }
        }
        return null;
    }

    /** Mở tài khoản & nộp tiền ban đầu đảm bảo tính nguyên tử (Atomic Rollback nếu lỗi) */
    public synchronized BankAccount openAccount(Customer customer, BigDecimal initialDeposit, User actor) {
        String eligibilityError = checkAccountEligibilityError(customer);
        if (eligibilityError != null) {
            throw new IllegalArgumentException(eligibilityError);
        }
        if (initialDeposit != null && initialDeposit.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Số tiền nộp ban đầu không được âm.");
        }
        if (initialDeposit != null && initialDeposit.compareTo(MoneyUtils.MAX_TX_LIMIT) > 0) {
            throw new IllegalArgumentException("Số tiền nộp ban đầu vượt hạn mức 10 tỷ VND.");
        }

        String newAccNum = generateUniqueAccountNumber();
        BankAccount acc = new BankAccount(0L, newAccNum, customer.getId(), customer.getFullName(),
                BigDecimal.ZERO, "VND", "ACTIVE", LocalDateTime.now());
        accountDAO().insert(acc);

        try {
            if (initialDeposit != null && initialDeposit.compareTo(BigDecimal.ZERO) > 0) {
                transactionService().deposit(newAccNum, initialDeposit, "Nộp tiền mở tài khoản ban đầu", actor);
            }
            DatabaseConnection.saveState();
            return accountDAO().findByAccountNumber(newAccNum);
        } catch (Exception ex) {
            // Rollback tài khoản vừa tạo nếu nộp tiền ban đầu thất bại
            DatabaseConnection.MEM_ACCOUNTS.removeIf(a -> a.getAccountNumber().equals(newAccNum));
            DatabaseConnection.saveState();
            throw new RuntimeException("Mở tài khoản thất bại (đã rollback): " + ex.getMessage(), ex);
        }
    }

    public synchronized void toggleLockStatus(BankAccount acc, String reason, User actor) {
        if (acc == null) {
            throw new IllegalArgumentException("Vui lòng chọn một tài khoản.");
        }
        if ("CLOSED".equalsIgnoreCase(acc.getStatus())) {
            throw new IllegalArgumentException("Tài khoản đã đóng, không thể thay đổi trạng thái.");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập lý do Khóa / Mở khóa tài khoản để lưu nhật ký kiểm toán.");
        }
        String newStatus = "ACTIVE".equalsIgnoreCase(acc.getStatus()) ? "LOCKED" : "ACTIVE";
        String actorName = actor != null ? actor.getUsername() : "system";
        accountDAO().updateStatus(acc.getId(), newStatus, reason.trim(), actorName);
    }

    public synchronized void closeAccount(BankAccount acc, String reason, User actor) {
        if (acc == null) {
            throw new IllegalArgumentException("Vui lòng chọn một tài khoản.");
        }
        if ("CLOSED".equalsIgnoreCase(acc.getStatus())) {
            throw new IllegalArgumentException("Tài khoản này đã được đóng trước đó.");
        }
        if (acc.getBalance().compareTo(BigDecimal.ZERO) > 0) {
            throw new IllegalArgumentException("Chỉ có thể đóng tài khoản khi số dư bằng 0 VND (Số dư hiện tại: "
                    + MoneyUtils.formatVND(acc.getBalance()) + "). Vui lòng tất toán/rút hết tiền trước.");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập lý do đóng tài khoản.");
        }
        String actorName = actor != null ? actor.getUsername() : "system";
        accountDAO().updateStatus(acc.getId(), "CLOSED", "Đóng TK: " + reason.trim(), actorName);
    }

    public List<AccountStatusHistory> getStatusHistory(Long accountId) {
        return accountDAO().findStatusHistory(accountId);
    }
}
