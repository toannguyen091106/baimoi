package bank.service;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.dao.UserDAO;
import bank.model.User;
import bank.util.PasswordUtils;

public class AuthService {
    private static volatile User currentUser;

    private UserDAO userDAO() {
        return ApplicationContext.getBean(UserDAO.class);
    }

    public User login(String username, String password, boolean rememberMe) {
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.");
        }
        User user = userDAO().findByUsername(username.trim());
        if (user == null || !PasswordUtils.verifyPassword(password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Tên đăng nhập hoặc mật khẩu không chính xác.");
        }
        if (!"ACTIVE".equalsIgnoreCase(user.getStatus())) {
            throw new IllegalArgumentException("Tài khoản nhân viên đang bị khóa.");
        }
        DatabaseConnection.saveLastLogin(user.getUsername(), password, rememberMe);
        currentUser = user;
        return user;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void logout() {
        currentUser = null;
    }

    public static void requireAdmin() {
        if (currentUser == null || !"ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            throw new SecurityException("Chức năng này chỉ dành cho quản trị viên.");
        }
        if (!"ACTIVE".equalsIgnoreCase(currentUser.getStatus())) {
            throw new SecurityException("Tài khoản quản trị hiện đã bị khóa.");
        }
    }

    public static void requireAdmin(User actor) {
        requireAdmin();
        if (actor == null || actor.getId() != currentUser.getId()) {
            throw new SecurityException("Người thực hiện không khớp với phiên đăng nhập.");
        }
    }

    public void changeOwnPassword(User user, String oldPass, String newPass) {
        if (user == null) throw new IllegalArgumentException("Phiên đăng nhập không hợp lệ.");
        if (!PasswordUtils.verifyPassword(oldPass, user.getPasswordHash())) {
            throw new IllegalArgumentException("Mật khẩu hiện tại không chính xác.");
        }
        if (newPass == null || newPass.trim().length() < 6) {
            throw new IllegalArgumentException("Mật khẩu mới phải có từ 6 ký tự trở lên.");
        }
        user.setPasswordHash(PasswordUtils.hashPassword(newPass.trim()));
        userDAO().update(user);
    }
}
