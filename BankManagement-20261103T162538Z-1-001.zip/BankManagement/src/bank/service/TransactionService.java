package bank.service;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.dao.AccountDAO;
import bank.dao.TransactionDAO;
import bank.model.BankAccount;
import bank.model.Transaction;
import bank.model.TransactionEntry;
import bank.model.User;
import bank.util.MoneyUtils;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public class TransactionService {
    private static final AtomicLong TX_SEQ = new AtomicLong(1000);

    private AccountDAO accountDAO() { return ApplicationContext.getBean(AccountDAO.class); }
    private TransactionDAO transactionDAO() { return ApplicationContext.getBean(TransactionDAO.class); }

    private String generateTransactionCode() {
        String timePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"));
        long seq = TX_SEQ.incrementAndGet() % 10000;
        return String.format("TXN%s%04d", timePart, seq);
    }

    public synchronized Transaction deposit(String accountNumber, BigDecimal amount, String description, User actor) {
        MoneyUtils.validateAmount(amount);
        String desc = (description == null || description.isBlank()) ? "Nộp tiền mặt tại quầy" : description.trim();
        String txCode = generateTransactionCode();

        if (DatabaseConnection.isMySqlMode()) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    BankAccount acc = lockAccountForUpdate(conn, accountNumber);
                    validateActiveAccount(acc, "Tài khoản thụ hưởng");

                    BigDecimal newBalance = acc.getBalance().add(amount);
                    updateBalanceInTx(conn, acc.getId(), newBalance);
                    long txId = insertTransactionInTx(conn, txCode, "DEPOSIT", null, acc.getId(), amount, desc, actor.getId());
                    insertEntryInTx(conn, txId, acc.getId(), "CREDIT", amount, newBalance);

                    conn.commit();
                    return new Transaction(txId, txCode, "DEPOSIT", null, "-", acc.getId(), acc.getAccountNumber(),
                            amount, desc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
                } catch (Exception ex) {
                    conn.rollback();
                    throw ex;
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi CSDL khi nộp tiền: " + e.getMessage(), e);
            }
        }

        BankAccount acc = accountDAO().findByAccountNumber(accountNumber);
        validateActiveAccount(acc, "Tài khoản nộp tiền");
        BigDecimal newBalance = acc.getBalance().add(amount);
        acc.setBalance(newBalance);

        long txId = DatabaseConnection.MEM_TRANSACTIONS.stream().mapToLong(Transaction::getId).max().orElse(0L) + 1;
        Transaction tx = new Transaction(txId, txCode, "DEPOSIT", null, "-", acc.getId(), acc.getAccountNumber(),
                amount, desc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
        DatabaseConnection.MEM_TRANSACTIONS.add(tx);

        long entryId = DatabaseConnection.MEM_ENTRIES.stream().mapToLong(TransactionEntry::getId).max().orElse(0L) + 1;
        DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(entryId, txId, acc.getId(), acc.getAccountNumber(),
                "CREDIT", amount, newBalance, LocalDateTime.now()));
        DatabaseConnection.saveState();
        return tx;
    }

    public synchronized Transaction withdraw(String accountNumber, BigDecimal amount, String description, User actor) {
        MoneyUtils.validateAmount(amount);
        String desc = (description == null || description.isBlank()) ? "Rút tiền mặt tại quầy" : description.trim();
        String txCode = generateTransactionCode();

        if (DatabaseConnection.isMySqlMode()) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    BankAccount acc = lockAccountForUpdate(conn, accountNumber);
                    validateActiveAccount(acc, "Tài khoản rút tiền");
                    if (acc.getBalance().compareTo(amount) < 0) {
                        throw new IllegalArgumentException("Số dư khả dụng không đủ để thực hiện rút tiền.");
                    }

                    BigDecimal newBalance = acc.getBalance().subtract(amount);
                    updateBalanceInTx(conn, acc.getId(), newBalance);
                    long txId = insertTransactionInTx(conn, txCode, "WITHDRAW", acc.getId(), null, amount, desc, actor.getId());
                    insertEntryInTx(conn, txId, acc.getId(), "DEBIT", amount, newBalance);

                    conn.commit();
                    return new Transaction(txId, txCode, "WITHDRAW", acc.getId(), acc.getAccountNumber(), null, "-",
                            amount, desc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
                } catch (Exception ex) {
                    conn.rollback();
                    throw ex;
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi CSDL khi rút tiền: " + e.getMessage(), e);
            }
        }

        BankAccount acc = accountDAO().findByAccountNumber(accountNumber);
        validateActiveAccount(acc, "Tài khoản rút tiền");
        if (acc.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Số dư khả dụng (" + MoneyUtils.formatVND(acc.getBalance()) + ") không đủ để rút.");
        }
        BigDecimal newBalance = acc.getBalance().subtract(amount);
        acc.setBalance(newBalance);

        long txId = DatabaseConnection.MEM_TRANSACTIONS.stream().mapToLong(Transaction::getId).max().orElse(0L) + 1;
        Transaction tx = new Transaction(txId, txCode, "WITHDRAW", acc.getId(), acc.getAccountNumber(), null, "-",
                amount, desc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
        DatabaseConnection.MEM_TRANSACTIONS.add(tx);

        long entryId = DatabaseConnection.MEM_ENTRIES.stream().mapToLong(TransactionEntry::getId).max().orElse(0L) + 1;
        DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(entryId, txId, acc.getId(), acc.getAccountNumber(),
                "DEBIT", amount, newBalance, LocalDateTime.now()));
        DatabaseConnection.saveState();
        return tx;
    }

    public synchronized Transaction transfer(String sourceAccNum, String destAccNum, BigDecimal amount, String description, User actor) {
        MoneyUtils.validateAmount(amount);
        if (sourceAccNum == null || destAccNum == null || sourceAccNum.trim().equals(destAccNum.trim())) {
            throw new IllegalArgumentException("Tài khoản gửi và Tài khoản nhận không hợp lệ hoặc trùng nhau.");
        }
        String desc = (description == null || description.isBlank()) ? "Chuyển khoản liên tài khoản" : description.trim();
        String txCode = generateTransactionCode();

        if (DatabaseConnection.isMySqlMode()) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    // Khóa theo thứ tự từ điển của số tài khoản để chống Deadlock 100%
                    String firstNum = sourceAccNum.trim().compareTo(destAccNum.trim()) < 0 ? sourceAccNum.trim() : destAccNum.trim();
                    String secondNum = firstNum.equals(sourceAccNum.trim()) ? destAccNum.trim() : sourceAccNum.trim();

                    BankAccount firstLocked = lockAccountForUpdate(conn, firstNum);
                    BankAccount secondLocked = lockAccountForUpdate(conn, secondNum);

                    BankAccount srcAcc = firstNum.equals(sourceAccNum.trim()) ? firstLocked : secondLocked;
                    BankAccount dstAcc = firstNum.equals(sourceAccNum.trim()) ? secondLocked : firstLocked;

                    validateActiveAccount(srcAcc, "Tài khoản gửi");
                    validateActiveAccount(dstAcc, "Tài khoản nhận");
                    if (srcAcc.getBalance().compareTo(amount) < 0) {
                        throw new IllegalArgumentException("Tài khoản gửi không đủ số dư khả dụng.");
                    }

                    BigDecimal newSrcBal = srcAcc.getBalance().subtract(amount);
                    BigDecimal newDstBal = dstAcc.getBalance().add(amount);
                    updateBalanceInTx(conn, srcAcc.getId(), newSrcBal);
                    updateBalanceInTx(conn, dstAcc.getId(), newDstBal);

                    long txId = insertTransactionInTx(conn, txCode, "TRANSFER", srcAcc.getId(), dstAcc.getId(), amount, desc, actor.getId());
                    insertEntryInTx(conn, txId, srcAcc.getId(), "DEBIT", amount, newSrcBal);
                    insertEntryInTx(conn, txId, dstAcc.getId(), "CREDIT", amount, newDstBal);

                    conn.commit();
                    return new Transaction(txId, txCode, "TRANSFER", srcAcc.getId(), srcAcc.getAccountNumber(),
                            dstAcc.getId(), dstAcc.getAccountNumber(), amount, desc, "SUCCESS",
                            actor.getId(), actor.getUsername(), LocalDateTime.now());
                } catch (Exception ex) {
                    conn.rollback();
                    throw ex;
                }
            } catch (SQLException e) {
                throw new RuntimeException("Lỗi CSDL khi chuyển khoản: " + e.getMessage(), e);
            }
        }

        BankAccount srcAcc = accountDAO().findByAccountNumber(sourceAccNum.trim());
        BankAccount dstAcc = accountDAO().findByAccountNumber(destAccNum.trim());
        validateActiveAccount(srcAcc, "Tài khoản gửi");
        validateActiveAccount(dstAcc, "Tài khoản nhận");
        if (srcAcc.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Tài khoản gửi (" + MoneyUtils.formatVND(srcAcc.getBalance()) + ") không đủ số dư.");
        }

        BigDecimal newSrcBal = srcAcc.getBalance().subtract(amount);
        BigDecimal newDstBal = dstAcc.getBalance().add(amount);
        srcAcc.setBalance(newSrcBal);
        dstAcc.setBalance(newDstBal);

        long txId = DatabaseConnection.MEM_TRANSACTIONS.stream().mapToLong(Transaction::getId).max().orElse(0L) + 1;
        Transaction tx = new Transaction(txId, txCode, "TRANSFER", srcAcc.getId(), srcAcc.getAccountNumber(),
                dstAcc.getId(), dstAcc.getAccountNumber(), amount, desc, "SUCCESS",
                actor.getId(), actor.getUsername(), LocalDateTime.now());
        DatabaseConnection.MEM_TRANSACTIONS.add(tx);

        long entryId = DatabaseConnection.MEM_ENTRIES.stream().mapToLong(TransactionEntry::getId).max().orElse(0L) + 1;
        DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(entryId, txId, srcAcc.getId(), srcAcc.getAccountNumber(),
                "DEBIT", amount, newSrcBal, LocalDateTime.now()));
        DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(entryId + 1, txId, dstAcc.getId(), dstAcc.getAccountNumber(),
                "CREDIT", amount, newDstBal, LocalDateTime.now()));
        DatabaseConnection.saveState();
        return tx;
    }

    /** Chức năng Hoàn tác giao dịch bằng giao dịch đảo (REVERSAL) */
    public synchronized Transaction reverseTransaction(Transaction originalTx, String reason, User actor) {
        AuthService.requireAdmin(actor);
        if (originalTx == null) {
            throw new IllegalArgumentException("Vui lòng chọn giao dịch cần hoàn tác.");
        }
        if (!"SUCCESS".equalsIgnoreCase(originalTx.getStatus())) {
            throw new IllegalArgumentException("Giao dịch đã được hoàn tác hoặc chưa hoàn thành thành công.");
        }
        if ("REVERSAL".equalsIgnoreCase(originalTx.getTransactionType())) {
            throw new IllegalArgumentException("Không thể hoàn tác một giao dịch đảo.");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập lý do hoàn tác giao dịch.");
        }

        BigDecimal amt = originalTx.getAmount();
        String revCode = generateTransactionCode();
        String revDesc = "Hoàn tác GD " + originalTx.getTransactionCode() + ": " + reason.trim();
        long txId = DatabaseConnection.MEM_TRANSACTIONS.stream().mapToLong(Transaction::getId).max().orElse(0L) + 1;
        long nextEntryId = DatabaseConnection.MEM_ENTRIES.stream().mapToLong(TransactionEntry::getId).max().orElse(0L) + 1;

        Transaction revTx;
        if ("DEPOSIT".equalsIgnoreCase(originalTx.getTransactionType())) {
            BankAccount acc = accountDAO().findByAccountNumber(originalTx.getDestinationAccountNumber());
            validateActiveAccount(acc, "Tài khoản hoàn tác");
            if (acc.getBalance().compareTo(amt) < 0) {
                throw new IllegalArgumentException("Số dư tài khoản không đủ để thu hồi khoản nộp tiền.");
            }
            BigDecimal newBal = acc.getBalance().subtract(amt);
            acc.setBalance(newBal);
            revTx = new Transaction(txId, revCode, "REVERSAL", acc.getId(), acc.getAccountNumber(), null, "-",
                    amt, revDesc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
            DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(nextEntryId, txId, acc.getId(), acc.getAccountNumber(),
                    "DEBIT", amt, newBal, LocalDateTime.now()));
        } else if ("WITHDRAW".equalsIgnoreCase(originalTx.getTransactionType())) {
            BankAccount acc = accountDAO().findByAccountNumber(originalTx.getSourceAccountNumber());
            validateActiveAccount(acc, "Tài khoản hoàn tác");
            BigDecimal newBal = acc.getBalance().add(amt);
            acc.setBalance(newBal);
            revTx = new Transaction(txId, revCode, "REVERSAL", null, "-", acc.getId(), acc.getAccountNumber(),
                    amt, revDesc, "SUCCESS", actor.getId(), actor.getUsername(), LocalDateTime.now());
            DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(nextEntryId, txId, acc.getId(), acc.getAccountNumber(),
                    "CREDIT", amt, newBal, LocalDateTime.now()));
        } else {
            BankAccount srcAcc = accountDAO().findByAccountNumber(originalTx.getSourceAccountNumber());
            BankAccount dstAcc = accountDAO().findByAccountNumber(originalTx.getDestinationAccountNumber());
            validateActiveAccount(srcAcc, "Tài khoản gốc");
            validateActiveAccount(dstAcc, "Tài khoản thụ hưởng");
            if (dstAcc.getBalance().compareTo(amt) < 0) {
                throw new IllegalArgumentException("Tài khoản nhận không đủ số dư để hoàn trả giao dịch chuyển khoản.");
            }
            BigDecimal newDstBal = dstAcc.getBalance().subtract(amt);
            BigDecimal newSrcBal = srcAcc.getBalance().add(amt);
            dstAcc.setBalance(newDstBal);
            srcAcc.setBalance(newSrcBal);
            revTx = new Transaction(txId, revCode, "REVERSAL", dstAcc.getId(), dstAcc.getAccountNumber(),
                    srcAcc.getId(), srcAcc.getAccountNumber(), amt, revDesc, "SUCCESS",
                    actor.getId(), actor.getUsername(), LocalDateTime.now());
            DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(nextEntryId, txId, dstAcc.getId(), dstAcc.getAccountNumber(),
                    "DEBIT", amt, newDstBal, LocalDateTime.now()));
            DatabaseConnection.MEM_ENTRIES.add(new TransactionEntry(nextEntryId + 1, txId, srcAcc.getId(), srcAcc.getAccountNumber(),
                    "CREDIT", amt, newSrcBal, LocalDateTime.now()));
        }

        originalTx.setStatus("REVERSED");
        DatabaseConnection.MEM_TRANSACTIONS.add(revTx);
        DatabaseConnection.saveState();
        return revTx;
    }

    private void validateActiveAccount(BankAccount acc, String label) {
        if (acc == null) {
            throw new IllegalArgumentException(label + " không tồn tại trên hệ thống.");
        }
        if (!"ACTIVE".equalsIgnoreCase(acc.getStatus())) {
            throw new IllegalArgumentException(label + " (" + acc.getAccountNumber() + ") không ở trạng thái hoạt động.");
        }
    }

    private BankAccount lockAccountForUpdate(Connection conn, String accNum) throws SQLException {
        String sql = "SELECT a.id, a.account_number, a.customer_id, c.full_name, a.balance, a.currency, a.status, a.created_at "
                + "FROM accounts a JOIN customers c ON a.customer_id = c.id WHERE a.account_number = ? FOR UPDATE";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, accNum.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new BankAccount(rs.getLong("id"), rs.getString("account_number"), rs.getLong("customer_id"),
                            rs.getString("full_name"), rs.getBigDecimal("balance"), rs.getString("currency"),
                            rs.getString("status"), rs.getTimestamp("created_at").toLocalDateTime());
                }
            }
        }
        return null;
    }

    private void updateBalanceInTx(Connection conn, long accountId, BigDecimal newBalance) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE accounts SET balance = ? WHERE id = ?")) {
            ps.setBigDecimal(1, newBalance);
            ps.setLong(2, accountId);
            ps.executeUpdate();
        }
    }

    private long insertTransactionInTx(Connection conn, String code, String type, Long srcId, Long dstId,
                                       BigDecimal amount, String desc, long userId) throws SQLException {
        String sql = "INSERT INTO transactions(transaction_code, transaction_type, source_account_id, destination_account_id, amount, description, status, created_by) "
                + "VALUES (?, ?, ?, ?, ?, ?, 'SUCCESS', ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, code);
            ps.setString(2, type);
            if (srcId != null) ps.setLong(3, srcId);
            else ps.setNull(3, Types.BIGINT);
            if (dstId != null) ps.setLong(4, dstId);
            else ps.setNull(4, Types.BIGINT);
            ps.setBigDecimal(5, amount);
            ps.setString(6, desc);
            ps.setLong(7, userId);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getLong(1);
            }
        }
        throw new SQLException("Không thể tạo bản ghi giao dịch.");
    }

    private void insertEntryInTx(Connection conn, long txId, long accId, String entryType, BigDecimal amount, BigDecimal balanceAfter) throws SQLException {
        String sql = "INSERT INTO transaction_entries(transaction_id, account_id, entry_type, amount, balance_after) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, txId);
            ps.setLong(2, accId);
            ps.setString(3, entryType);
            ps.setBigDecimal(4, amount);
            ps.setBigDecimal(5, balanceAfter);
            ps.executeUpdate();
        }
    }

    public List<Transaction> searchHistory(String txCode, String accountNum, String type, String status) {
        return searchHistory(txCode, accountNum, type, status, null, null, null);
    }

    /** Hai ngày giới hạn đều được tính trọn ngày; để trống để không giới hạn. */
    public List<Transaction> searchHistory(String txCode, String accountNum, String type, String status,
                                           LocalDate fromDate, LocalDate toDate, String createdBy) {
        if (fromDate != null && toDate != null && fromDate.isAfter(toDate)) {
            throw new IllegalArgumentException("Ngày bắt đầu không được sau ngày kết thúc.");
        }
        return transactionDAO().findAll().stream().filter(t -> {
            if (txCode != null && !txCode.isBlank() && !t.getTransactionCode().toLowerCase().contains(txCode.trim().toLowerCase())) {
                return false;
            }
            if (accountNum != null && !accountNum.isBlank()) {
                String acc = accountNum.trim();
                boolean matchSrc = t.getSourceAccountNumber() != null && t.getSourceAccountNumber().contains(acc);
                boolean matchDst = t.getDestinationAccountNumber() != null && t.getDestinationAccountNumber().contains(acc);
                if (!matchSrc && !matchDst) return false;
            }
            if (type != null && !"ALL".equals(type) && !t.getTransactionType().equalsIgnoreCase(type)) {
                return false;
            }
            if (status != null && !"ALL".equals(status) && !t.getStatus().equalsIgnoreCase(status)) {
                return false;
            }
            if (fromDate != null || toDate != null) {
                if (t.getCreatedAt() == null) return false;
                LocalDate transactionDate = t.getCreatedAt().toLocalDate();
                if (fromDate != null && transactionDate.isBefore(fromDate)) return false;
                if (toDate != null && transactionDate.isAfter(toDate)) return false;
            }
            if (createdBy != null && !createdBy.isBlank()
                    && (t.getCreatedByUsername() == null || !t.getCreatedByUsername().toLowerCase(java.util.Locale.ROOT)
                            .contains(createdBy.trim().toLowerCase(java.util.Locale.ROOT)))) {
                return false;
            }
            return true;
        }).collect(Collectors.toList());
    }

    public List<TransactionEntry> getEntriesForTransaction(long txId) {
        return transactionDAO().findEntriesByTransactionId(txId);
    }
}
