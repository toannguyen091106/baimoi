package bank.service;

import bank.config.ApplicationContext;
import bank.dao.CustomerDAO;
import bank.model.Customer;
import bank.util.ValidationUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class CustomerService {
    private CustomerDAO customerDAO() {
        return ApplicationContext.getBean(CustomerDAO.class);
    }

    public List<Customer> getAllCustomers() {
        return customerDAO().findAll();
    }

    public List<Customer> searchCustomers(String keyword, String statusFilter) {
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        return customerDAO().findAll().stream().filter(c -> {
            boolean matchKw = kw.isEmpty()
                    || c.getCustomerCode().toLowerCase().contains(kw)
                    || c.getFullName().toLowerCase().contains(kw)
                    || c.getPhone().toLowerCase().contains(kw)
                    || c.getEmail().toLowerCase().contains(kw)
                    || c.getAddress().toLowerCase().contains(kw);
            boolean matchStatus = statusFilter == null || "ALL".equalsIgnoreCase(statusFilter)
                    || c.getStatus().equalsIgnoreCase(statusFilter);
            return matchKw && matchStatus;
        }).collect(Collectors.toList());
    }

    public String generateNextCustomerCode() {
        int maxNum = 0;
        for (Customer c : customerDAO().findAll()) {
            String code = c.getCustomerCode().toUpperCase().replace("KH", "").trim();
            try {
                int val = Integer.parseInt(code);
                if (val > maxNum) maxNum = val;
            } catch (NumberFormatException ignored) {
            }
        }
        return String.format("KH%03d", maxNum + 1);
    }

    private void validateUniquePhoneAndEmail(String phone, String email, Long excludeCustomerId) {
        Customer dupPhone = customerDAO().findByPhone(phone, excludeCustomerId);
        if (dupPhone != null) {
            throw new IllegalArgumentException(
                    "Số điện thoại '" + phone.trim() + "' đã được đăng ký cho khách hàng '"
                            + dupPhone.getFullName() + "' (" + dupPhone.getCustomerCode() + ").\n"
                            + "Mỗi số điện thoại chỉ được đăng ký duy nhất 1 hồ sơ / 1 tài khoản ngân hàng (dù dùng tên khác)!");
        }

        Customer dupEmail = customerDAO().findByEmail(email, excludeCustomerId);
        if (dupEmail != null) {
            throw new IllegalArgumentException(
                    "Địa chỉ Email '" + email.trim() + "' đã được đăng ký cho khách hàng '"
                            + dupEmail.getFullName() + "' (" + dupEmail.getCustomerCode() + ").\n"
                            + "Mỗi Email chỉ được đăng ký duy nhất 1 hồ sơ / 1 tài khoản ngân hàng (dù dùng tên khác)!");
        }
    }

    public void addCustomer(String code, String fullName, String dobStr, String phone, String email, String address) {
        if (code == null || code.isBlank() || fullName == null || fullName.isBlank()) {
            throw new IllegalArgumentException("Mã khách hàng và Họ tên là bắt buộc.");
        }
        if (customerDAO().findByCode(code.trim()) != null) {
            throw new IllegalArgumentException("Mã khách hàng '" + code.trim() + "' đã tồn tại.");
        }
        LocalDate dob = ValidationUtils.parseDate(dobStr);
        if (!ValidationUtils.isValidPhone(phone)) {
            throw new IllegalArgumentException("Số điện thoại không hợp lệ (10-11 chữ số, bắt đầu bằng 0).");
        }
        if (!ValidationUtils.isValidEmail(email)) {
            throw new IllegalArgumentException("Địa chỉ Email không đúng định dạng.");
        }
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Địa chỉ liên hệ không được để trống.");
        }

        validateUniquePhoneAndEmail(phone, email, null);

        Customer customer = new Customer(0L, code.trim().toUpperCase(), fullName.trim(),
                dob, phone.trim(), email.trim(), address.trim(), "ACTIVE", LocalDateTime.now());
        customerDAO().insert(customer);
    }

    public void updateCustomer(Customer customer, String fullName, String dobStr, String phone, String email, String address, String status) {
        if (fullName == null || fullName.isBlank()) {
            throw new IllegalArgumentException("Họ tên khách hàng không được để trống.");
        }
        LocalDate dob = ValidationUtils.parseDate(dobStr);
        if (!ValidationUtils.isValidPhone(phone)) {
            throw new IllegalArgumentException("Số điện thoại không hợp lệ (10-11 chữ số, bắt đầu bằng 0).");
        }
        if (!ValidationUtils.isValidEmail(email)) {
            throw new IllegalArgumentException("Địa chỉ Email không đúng định dạng.");
        }
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Địa chỉ không được để trống.");
        }

        validateUniquePhoneAndEmail(phone, email, customer.getId());

        customer.setFullName(fullName.trim());
        customer.setDateOfBirth(dob);
        customer.setPhone(phone.trim());
        customer.setEmail(email.trim());
        customer.setAddress(address.trim());
        customer.setStatus(status);
        customerDAO().update(customer);
    }
}
