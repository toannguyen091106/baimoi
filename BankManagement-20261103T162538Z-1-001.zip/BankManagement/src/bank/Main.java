package bank;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.ui.LoginFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.JOptionPane;

public final class Main {
    private Main() {}

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
        }

        try {
            ApplicationContext.run(Main.class, args);
        } catch (RuntimeException | ExceptionInInitializerError error) {
            Throwable detail = error instanceof ExceptionInInitializerError && error.getCause() != null
                    ? error.getCause() : error;
            JOptionPane.showMessageDialog(null,
                    "Không thể mở ứng dụng.\n\n" + detail.getMessage(),
                    "Không thể mở dữ liệu", JOptionPane.ERROR_MESSAGE);
            return;
        }
        SwingUtilities.invokeLater(() -> {
            String recovery = DatabaseConnection.getRecoveryMessage();
            if (recovery != null) {
                JOptionPane.showMessageDialog(null, recovery,
                        "Đã khôi phục dữ liệu", JOptionPane.INFORMATION_MESSAGE);
            }
            new LoginFrame().setVisible(true);
        });
    }
}
