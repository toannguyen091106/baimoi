package bank.web;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.Transaction;
import bank.service.AccountService;
import bank.service.CustomerService;
import bank.service.TransactionService;
import bank.ui.components.UiLabels;
import bank.util.MoneyUtils;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Trang web thống kê (chỉ đọc) và API JSON, chạy trên HttpServer có sẵn của JDK.
 * Mọi yêu cầu chỉ chấp nhận GET đúng đường dẫn; lỗi trả về JSON {"error": "..."}.
 */
public class BankRestController {
    /** Số giao dịch mới nhất trả về mặc định cho mục "Giao dịch gần đây". */
    static final int DEFAULT_RECENT_LIMIT = 20;
    static final int MAX_RECENT_LIMIT = 200;

    private static final String JSON = "application/json; charset=UTF-8";
    private static final String HTML = "text/html; charset=UTF-8";
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private CustomerService customerService() { return ApplicationContext.getBean(CustomerService.class); }
    private AccountService accountService() { return ApplicationContext.getBean(AccountService.class); }
    private TransactionService transactionService() { return ApplicationContext.getBean(TransactionService.class); }

    // ===================== API =====================

    public void handleApiSummary(HttpExchange ex) {
        respondJson(ex, "/api/summary", () -> {
            List<Customer> customers = customerService().getAllCustomers();
            List<BankAccount> accounts = accountService().getAllAccounts();
            List<Transaction> txs = transactionService().searchHistory(null, null, "ALL", "ALL");
            BigDecimal totalBalance = accounts.stream().map(BankAccount::getBalance)
                    .filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
            return String.format("{\"customers\":%d,\"accounts\":%d,\"transactions\":%d,\"totalBalance\":\"%s\"}",
                    customers.size(), accounts.size(), txs.size(), escapeJson(MoneyUtils.formatVND(totalBalance)));
        });
    }

    public void handleApiAccounts(HttpExchange ex) {
        respondJson(ex, "/api/accounts", () -> {
            StringBuilder sb = new StringBuilder("[");
            List<BankAccount> list = accountService().getAllAccounts();
            for (int i = 0; i < list.size(); i++) {
                BankAccount a = list.get(i);
                if (i > 0) sb.append(",");
                sb.append("{")
                        .append(field("accountNumber", a.getAccountNumber())).append(",")
                        .append(field("customerName", a.getCustomerName())).append(",")
                        .append(field("balance", MoneyUtils.formatVND(a.getBalance()))).append(",")
                        .append(field("status", a.getStatus())).append(",")
                        .append(field("statusLabel", UiLabels.text(a.getStatus())))
                        .append("}");
            }
            return sb.append("]").toString();
        });
    }

    /** Trả về các giao dịch mới nhất (mặc định 20, đổi bằng ?limit=N, tối đa 200). */
    public void handleApiTransactions(HttpExchange ex) {
        int limit = parseLimit(ex.getRequestURI().getRawQuery());
        respondJson(ex, "/api/transactions", () -> {
            // DAO đã sắp xếp mới nhất trước ở cả chế độ dữ liệu cục bộ và MySQL.
            List<Transaction> all = transactionService().searchHistory(null, null, "ALL", "ALL");
            List<Transaction> list = all.subList(0, Math.min(limit, all.size()));
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < list.size(); i++) {
                Transaction t = list.get(i);
                if (i > 0) sb.append(",");
                sb.append("{")
                        .append(field("time", t.getCreatedAt() == null ? "" : t.getCreatedAt().format(TIME_FORMAT))).append(",")
                        .append(field("code", t.getTransactionCode())).append(",")
                        .append(field("type", t.getTransactionType())).append(",")
                        .append(field("typeLabel", UiLabels.text(t.getTransactionType()))).append(",")
                        .append(field("src", t.getSourceAccountNumber())).append(",")
                        .append(field("dst", t.getDestinationAccountNumber())).append(",")
                        .append(field("amount", MoneyUtils.formatVND(t.getAmount()))).append(",")
                        .append(field("desc", t.getDescription())).append(",")
                        .append(field("status", t.getStatus())).append(",")
                        .append(field("statusLabel", UiLabels.text(t.getStatus())))
                        .append("}");
            }
            return sb.append("]").toString();
        });
    }

    // ===================== Trang web =====================

    public void handleDashboardPage(HttpExchange ex) {
        try {
            if (!acceptRequest(ex, "/")) return;
            sendResponse(ex, 200, HTML, buildDashboardHtml());
        } catch (RuntimeException e) {
            System.err.println("[Web] Lỗi tạo trang " + ex.getRequestURI() + ": " + e);
            sendResponse(ex, 500, HTML, "<!DOCTYPE html><meta charset='UTF-8'><h3>Không thể tạo trang thống kê.</h3>");
        } finally {
            ex.close();
        }
    }

    private String buildDashboardHtml() {
        String dataSource = DatabaseConnection.isMySqlMode() ? "MySQL" : "data/bank_data_store.ser";
        return "<!DOCTYPE html><html lang='vi'><head><meta charset='UTF-8'>"
                + "<title>Core Banking - Trang thống kê</title>"
                + "<link rel='icon' href='data:,'>"
                + "<style>"
                + "body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;margin:0;color:#0f172a;}"
                + "header{background:linear-gradient(135deg,#0f172a,#1e3a8a);color:#fff;padding:22px 40px;display:flex;justify-content:space-between;align-items:center;gap:16px;}"
                + ".container{max-width:1160px;margin:28px auto;padding:0 20px;}"
                + ".cards{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:24px;}"
                + ".card{background:#fff;border-radius:14px;padding:20px;box-shadow:0 4px 12px rgba(0,0,0,0.05);border-top:4px solid #2563eb;}"
                + ".card h4{margin:0 0 8px 0;color:#64748b;font-size:13px;}"
                + ".card .val{font-size:22px;font-weight:700;color:#0f172a;}"
                + "table{width:100%;border-collapse:collapse;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05);}"
                + "th,td{padding:13px 16px;text-align:left;border-bottom:1px solid #e2e8f0;font-size:14px;}"
                + "th{background:#f8fafc;color:#475569;font-weight:700;}"
                + "td.empty{text-align:center;color:#64748b;}"
                + ".nw{white-space:nowrap;}"
                + "h3 small{font-weight:400;color:#64748b;font-size:13px;}"
                + ".badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:700;white-space:nowrap;}"
                + ".ok{background:#d1fae5;color:#065f46;}"
                + ".bad{background:#fee2e2;color:#991b1b;}"
                + ".warn{background:#fef3c7;color:#92400e;}"
                + ".muted{background:#e2e8f0;color:#475569;}"
                + ".info{background:#dbeafe;color:#1e40af;}"
                + ".alert{background:#fee2e2;color:#991b1b;border:1px solid #fecaca;padding:12px 16px;border-radius:10px;margin-bottom:18px;font-size:14px;}"
                + ".meta{color:#64748b;font-size:13px;margin:-8px 0 18px 0;}"
                + "</style></head><body>"
                + "<header><div><h2 style='margin:0'>🏦 CORE BANKING – TRANG THỐNG KÊ</h2>"
                + "<small>Tự cập nhật mỗi 3 giây · Nguồn dữ liệu: " + dataSource + "</small></div>"
                + "<span class='badge ok'>localhost:" + ApplicationContext.getActivePort() + "</span></header>"
                + "<div class='container'>"
                + "<div id='err' class='alert' role='alert' hidden></div>"
                + "<div class='cards' id='kpi'></div>"
                + "<div class='meta' id='updated'>Đang tải dữ liệu…</div>"
                + "<h3>Danh sách tài khoản</h3><table id='accTbl'><thead><tr><th>Số TK</th><th>Chủ tài khoản</th><th>Số dư</th><th>Trạng thái</th></tr></thead><tbody></tbody></table>"
                + "<h3 style='margin-top:28px'>Giao dịch gần đây <small>(" + DEFAULT_RECENT_LIMIT + " giao dịch mới nhất)</small></h3>"
                + "<table id='txTbl'><thead><tr><th>Thời gian</th><th>Mã GD</th><th>Loại</th><th>TK nguồn</th><th>TK nhận</th><th>Số tiền</th><th>Diễn giải</th><th>Trạng thái</th></tr></thead><tbody></tbody></table>"
                + "</div>"
                + "<script>"
                + "const LIMIT=" + DEFAULT_RECENT_LIMIT + ";"
                + "const STATUS_CLASS={ACTIVE:'ok',SUCCESS:'ok',LOCKED:'bad',INACTIVE:'muted',CLOSED:'muted',REVERSED:'warn'};"
                + "function esc(s){const d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML;}"
                + "function badge(code,label,cls){const c=cls||STATUS_CLASS[String(code==null?'':code).toUpperCase()]||'muted';"
                + "return `<span class='badge ${c}'>${esc(label||code)}</span>`;}"
                + "function emptyRow(cols){return `<tr><td colspan='${cols}' class='empty'>Chưa có dữ liệu</td></tr>`;}"
                + "async function getJson(url){"
                + "const r=await fetch(url,{cache:'no-store'});"
                + "let data=null;try{data=await r.json();}catch(_){}"
                + "if(!r.ok)throw new Error((data&&data.error)||('Máy chủ trả về lỗi '+r.status));"
                + "if(data===null)throw new Error('Dữ liệu trả về không hợp lệ.');"
                + "return data;}"
                + "function showError(msg){const e=document.getElementById('err');e.textContent=msg;e.hidden=false;}"
                + "function hideError(){document.getElementById('err').hidden=true;}"
                + "let busy=false;"
                + "async function load(){"
                + "if(busy)return;busy=true;"
                + "try{"
                + "const [s,accs,txs]=await Promise.all([getJson('/api/summary'),getJson('/api/accounts'),getJson('/api/transactions?limit='+LIMIT)]);"
                + "document.getElementById('kpi').innerHTML="
                + "`<div class='card'><h4>Tổng khách hàng</h4><div class='val'>${esc(s.customers)} KH</div></div>"
                + "<div class='card'><h4>Tổng tài khoản</h4><div class='val'>${esc(s.accounts)} TK</div></div>"
                + "<div class='card'><h4>Tổng giao dịch</h4><div class='val'>${esc(s.transactions)} GD</div></div>"
                + "<div class='card'><h4>Tổng số dư hệ thống</h4><div class='val'>${esc(s.totalBalance)}</div></div>`;"
                + "document.querySelector('#accTbl tbody').innerHTML=accs.length?accs.map(a=>"
                + "`<tr><td><b>${esc(a.accountNumber)}</b></td><td>${esc(a.customerName)}</td><td class='nw'><b>${esc(a.balance)}</b></td><td>${badge(a.status,a.statusLabel)}</td></tr>`).join(''):emptyRow(4);"
                + "document.querySelector('#txTbl tbody').innerHTML=txs.length?txs.map(t=>"
                + "`<tr><td class='nw'>${esc(t.time)}</td><td><b>${esc(t.code)}</b></td><td>${badge(t.type,t.typeLabel,'info')}</td><td>${esc(t.src)}</td><td>${esc(t.dst)}</td>"
                + "<td class='nw'><b>${esc(t.amount)}</b></td><td>${esc(t.desc)}</td><td>${badge(t.status,t.statusLabel)}</td></tr>`).join(''):emptyRow(8);"
                + "hideError();"
                + "document.getElementById('updated').textContent='Cập nhật lúc '+new Date().toLocaleTimeString('vi-VN');"
                + "}catch(e){"
                + "const offline=e instanceof TypeError&&/fetch/i.test(e.message);"
                + "const msg=offline?'Không tải được dữ liệu: mất kết nối tới ứng dụng (ứng dụng có thể đã đóng).':e.message;"
                + "showError(msg.replace(/\\.?$/,'.')+' Trang sẽ tự thử lại sau 3 giây; số liệu đang hiển thị có thể chưa mới nhất.');"
                + "}finally{busy=false;}}"
                + "load();setInterval(load,3000);"
                + "</script></body></html>";
    }

    // ===================== Xử lý chung =====================

    /** Kiểm tra yêu cầu, tạo nội dung JSON và luôn trả lời (200 hoặc 4xx/500), không để trình duyệt chờ. */
    private void respondJson(HttpExchange ex, String path, Supplier<String> body) {
        try {
            if (!acceptRequest(ex, path)) return;
            sendResponse(ex, 200, JSON, body.get());
        } catch (RuntimeException e) {
            System.err.println("[Web] Lỗi xử lý " + ex.getRequestURI() + ": " + e);
            String reason = e.getMessage() == null || e.getMessage().isBlank()
                    ? e.getClass().getSimpleName() : e.getMessage();
            sendResponse(ex, 500, JSON, errorJson("Không thể tải dữ liệu: " + reason));
        } finally {
            ex.close();
        }
    }

    /** Chỉ nhận GET đúng đường dẫn; sai phương thức → 405, sai đường dẫn → 404. */
    private boolean acceptRequest(HttpExchange ex, String expectedPath) {
        String path = ex.getRequestURI().getPath();
        boolean api = path != null && path.startsWith("/api/");
        if (!expectedPath.equals(path)) {
            if (api) {
                sendResponse(ex, 404, JSON, errorJson("Không tìm thấy API: " + path));
            } else {
                sendResponse(ex, 404, HTML, "<!DOCTYPE html><html lang='vi'><head><meta charset='UTF-8'>"
                        + "<title>Không tìm thấy trang</title></head><body style='font-family:Segoe UI,sans-serif;padding:40px'>"
                        + "<h2>404 – Không tìm thấy trang</h2><p><a href='/'>Về trang thống kê</a></p></body></html>");
            }
            return false;
        }
        if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
            ex.getResponseHeaders().set("Allow", "GET");
            sendResponse(ex, 405, JSON, errorJson("Chỉ hỗ trợ phương thức GET."));
            return false;
        }
        return true;
    }

    private void sendResponse(HttpExchange ex, int status, String contentType, String body) {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        try {
            ex.getResponseHeaders().set("Content-Type", contentType);
            ex.getResponseHeaders().set("Cache-Control", "no-store");
            ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            ex.sendResponseHeaders(status, bytes.length == 0 ? -1 : bytes.length);
            if (bytes.length > 0) {
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(bytes);
                }
            }
        } catch (IOException e) {
            // Thường do trình duyệt đóng kết nối giữa chừng (tải lại trang); không ảnh hưởng dữ liệu.
            System.err.println("[Web] Không gửi được phản hồi " + ex.getRequestURI() + ": " + e.getMessage());
        }
    }

    static int parseLimit(String rawQuery) {
        if (rawQuery != null) {
            for (String part : rawQuery.split("&")) {
                if (part.startsWith("limit=")) {
                    try {
                        int value = Integer.parseInt(part.substring("limit=".length()));
                        return Math.max(1, Math.min(MAX_RECENT_LIMIT, value));
                    } catch (NumberFormatException ignored) {
                        return DEFAULT_RECENT_LIMIT;
                    }
                }
            }
        }
        return DEFAULT_RECENT_LIMIT;
    }

    private static String field(String name, String value) {
        return "\"" + name + "\":\"" + escapeJson(value) + "\"";
    }

    private static String errorJson(String message) {
        return "{" + field("error", message) + "}";
    }

    /**
     * Escape chuỗi theo chuẩn JSON: mọi ký tự điều khiển (< 0x20, gồm cả Tab) đều phải thoát,
     * nếu không trình duyệt sẽ báo lỗi khi đọc JSON. Thoát thêm &lt; &gt; &amp; để an toàn khi nhúng vào HTML.
     */
    static String escapeJson(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '<': sb.append("\\u003c"); break;
                case '>': sb.append("\\u003e"); break;
                case '&': sb.append("\\u0026"); break;
                case ' ': sb.append("\\u2028"); break;
                case ' ': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }
}
