package bank.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class MoneyUtils {
    private static final DecimalFormat VND_FORMAT;
    public static final BigDecimal MAX_TX_LIMIT = new BigDecimal("10000000000");

    static {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        VND_FORMAT = new DecimalFormat("#,##0", symbols);
    }

    public static String formatVND(BigDecimal amount) {
        if (amount == null) return "0 VND";
        return VND_FORMAT.format(amount) + " VND";
    }

    public static BigDecimal parseAmount(String input) {
        if (input == null || input.trim().isEmpty()) {
            throw new IllegalArgumentException("Vui lòng nhập số tiền giao dịch.");
        }
        String raw = input.trim().replace(" ", "");
        // Chặn trường hợp nhập số lẻ thập phân kiểu 1,5 hoặc 1.5
        if (raw.matches("^\\d+[.,]\\d{1,2}$")) {
            throw new IllegalArgumentException("Tiền tệ VND không sử dụng phần thập phân lẻ (VD: nhập 500000 hoặc 500.000).");
        }
        String cleaned = raw.replace(".", "").replace(",", "");
        try {
            BigDecimal value = new BigDecimal(cleaned);
            validateAmount(value);
            return value;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Số tiền không hợp lệ (chỉ nhập chữ số).");
        }
    }

    public static void validateAmount(BigDecimal value) {
        if (value == null || value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Số tiền giao dịch phải lớn hơn 0 VND.");
        }
        if (value.compareTo(MAX_TX_LIMIT) > 0) {
            throw new IllegalArgumentException("Số tiền vượt hạn mức 10 tỷ VND / lần.");
        }
    }
}
