package bank.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

public final class ValidationUtils {
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^0[0-9]{9,10}$");
    public static final int MIN_CUSTOMER_AGE = 15;

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.trim()).matches();
    }

    public static LocalDate parseDate(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) {
            throw new IllegalArgumentException("Vui lòng nhập ngày sinh.");
        }
        try {
            LocalDate dob = LocalDate.parse(dateStr.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            if (dob.isAfter(LocalDate.now().minusYears(MIN_CUSTOMER_AGE))) {
                throw new IllegalArgumentException("Khách hàng mở hồ sơ phải từ đủ " + MIN_CUSTOMER_AGE + " tuổi trở lên.");
            }
            if (dob.isBefore(LocalDate.of(1900, 1, 1))) {
                throw new IllegalArgumentException("Năm sinh không hợp lệ.");
            }
            return dob;
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Ngày sinh phải đúng định dạng yyyy-MM-dd (VD: 2005-11-09).");
        }
    }
}
