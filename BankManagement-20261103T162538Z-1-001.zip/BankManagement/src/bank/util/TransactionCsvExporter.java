package bank.util;

import bank.model.Transaction;
import bank.ui.components.UiLabels;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Xuất đúng danh sách đã lọc, theo thứ tự mà màn hình truyền vào. */
public final class TransactionCsvExporter {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private TransactionCsvExporter() {}

    public static void write(Path destination, List<Transaction> transactions) throws IOException {
        Path absolute = destination.toAbsolutePath();
        Path temporary = Files.createTempFile(absolute.getParent(), absolute.getFileName().toString() + ".", ".tmp");
        try {
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                writer.write('\uFEFF'); // Excel nhận diện tiếng Việt UTF-8.
                row(writer, "Mã giao dịch", "Loại giao dịch", "Tài khoản nguồn", "Tài khoản nhận", "Số tiền (VND)",
                        "Nội dung", "Trạng thái", "Người tạo", "Thời gian");
                for (Transaction tx : transactions) {
                    row(writer, text(tx.getTransactionCode()), text(UiLabels.text(tx.getTransactionType())),
                            text(tx.getSourceAccountNumber()), text(tx.getDestinationAccountNumber()),
                            tx.getAmount() == null ? "" : tx.getAmount().toPlainString(), text(tx.getDescription()),
                            text(UiLabels.text(tx.getStatus())), text(tx.getCreatedByUsername()),
                            tx.getCreatedAt() == null ? "" : TIME.format(tx.getCreatedAt()));
                }
            }
            try {
                Files.move(temporary, absolute, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    /** Chặn công thức bảng tính trong mọi cột văn bản do người dùng nhập. */
    public static String text(String value) {
        if (value == null || value.isEmpty()) return "";
        String leadingTrimmed = value.stripLeading();
        if ((!leadingTrimmed.isEmpty() && "=+-@".indexOf(leadingTrimmed.charAt(0)) >= 0)
                || value.charAt(0) == '\t' || value.charAt(0) == '\r' || value.charAt(0) == '\n') {
            return "'" + value;
        }
        return value;
    }

    private static void row(BufferedWriter writer, String... values) throws IOException {
        for (int index = 0; index < values.length; index++) {
            if (index != 0) writer.write(',');
            writer.write('"');
            writer.write(values[index].replace("\"", "\"\""));
            writer.write('"');
        }
        writer.write("\r\n");
    }
}
