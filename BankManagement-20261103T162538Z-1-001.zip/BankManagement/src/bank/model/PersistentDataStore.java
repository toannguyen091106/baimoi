package bank.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PersistentDataStore implements Serializable {
    private static final long serialVersionUID = 1L;
    public List<User> users = new ArrayList<>();
    public List<Customer> customers = new ArrayList<>();
    public List<BankAccount> accounts = new ArrayList<>();
    public List<AccountStatusHistory> statusHistories = new ArrayList<>();
    public List<Transaction> transactions = new ArrayList<>();
    public List<TransactionEntry> entries = new ArrayList<>();

    public Map<String, String> quickLoginPasswords = new LinkedHashMap<>();
    public String lastLoginUsername = "admin";
    public String lastLoginPassword = "admin123";
    public boolean rememberLastLogin = true;
}
