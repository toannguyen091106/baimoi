package bank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class BankAccount implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private String accountNumber;
    private long customerId;
    private String customerName;
    private BigDecimal balance;
    private String currency;
    private String status;
    private LocalDateTime createdAt;

    public BankAccount(long id, String accountNumber, long customerId, String customerName,
                       BigDecimal balance, String currency, String status, LocalDateTime createdAt) {
        this.id = id;
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.customerName = customerName;
        this.balance = balance;
        this.currency = currency;
        this.status = status;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getAccountNumber() { return accountNumber; }
    public long getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
    public String getCurrency() { return currency; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
