package bank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Transaction implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private String transactionCode;
    private String transactionType;
    private Long sourceAccountId;
    private String sourceAccountNumber;
    private Long destinationAccountId;
    private String destinationAccountNumber;
    private BigDecimal amount;
    private String description;
    private String status;
    private long createdBy;
    private String createdByUsername;
    private LocalDateTime createdAt;

    public Transaction(long id, String transactionCode, String transactionType,
                       Long sourceAccountId, String sourceAccountNumber,
                       Long destinationAccountId, String destinationAccountNumber,
                       BigDecimal amount, String description, String status,
                       long createdBy, String createdByUsername, LocalDateTime createdAt) {
        this.id = id;
        this.transactionCode = transactionCode;
        this.transactionType = transactionType;
        this.sourceAccountId = sourceAccountId;
        this.sourceAccountNumber = sourceAccountNumber;
        this.destinationAccountId = destinationAccountId;
        this.destinationAccountNumber = destinationAccountNumber;
        this.amount = amount;
        this.description = description;
        this.status = status;
        this.createdBy = createdBy;
        this.createdByUsername = createdByUsername;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public String getTransactionCode() { return transactionCode; }
    public String getTransactionType() { return transactionType; }
    public Long getSourceAccountId() { return sourceAccountId; }
    public String getSourceAccountNumber() { return sourceAccountNumber; }
    public Long getDestinationAccountId() { return destinationAccountId; }
    public String getDestinationAccountNumber() { return destinationAccountNumber; }
    public BigDecimal getAmount() { return amount; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getCreatedBy() { return createdBy; }
    public String getCreatedByUsername() { return createdByUsername; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
