package bank.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class AccountStatusHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private long accountId;
    private String accountNumber;
    private String oldStatus;
    private String newStatus;
    private String reason;
    private String changedBy;
    private LocalDateTime changedAt;

    public AccountStatusHistory(long id, long accountId, String accountNumber, String oldStatus,
                                String newStatus, String reason, String changedBy, LocalDateTime changedAt) {
        this.id = id;
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.oldStatus = oldStatus;
        this.newStatus = newStatus;
        this.reason = reason;
        this.changedBy = changedBy;
        this.changedAt = changedAt;
    }

    public long getId() { return id; }
    public long getAccountId() { return accountId; }
    public String getAccountNumber() { return accountNumber; }
    public String getOldStatus() { return oldStatus; }
    public String getNewStatus() { return newStatus; }
    public String getReason() { return reason; }
    public String getChangedBy() { return changedBy; }
    public LocalDateTime getChangedAt() { return changedAt; }
}
