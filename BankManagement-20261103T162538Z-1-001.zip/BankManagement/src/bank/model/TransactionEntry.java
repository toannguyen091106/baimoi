package bank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionEntry implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private long transactionId;
    private long accountId;
    private String accountNumber;
    private String entryType;
    private BigDecimal amount;
    private BigDecimal balanceAfter;
    private LocalDateTime createdAt;

    public TransactionEntry(long id, long transactionId, long accountId, String accountNumber,
                            String entryType, BigDecimal amount, BigDecimal balanceAfter, LocalDateTime createdAt) {
        this.id = id;
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.entryType = entryType;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public long getTransactionId() { return transactionId; }
    public long getAccountId() { return accountId; }
    public String getAccountNumber() { return accountNumber; }
    public String getEntryType() { return entryType; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
