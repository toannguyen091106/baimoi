package bank.ui;

import bank.config.ApplicationContext;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.Transaction;
import bank.service.AccountService;
import bank.service.CustomerService;
import bank.service.TransactionService;
import bank.ui.components.AnalyticsChartPanel;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.util.MoneyUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class DashboardPanel extends JPanel {
    private final CustomerService customerService = ApplicationContext.getBean(CustomerService.class);
    private final AccountService accountService = ApplicationContext.getBean(AccountService.class);
    private final TransactionService transactionService = ApplicationContext.getBean(TransactionService.class);

    private final JLabel lblCustomerVal = new JLabel("0");
    private final JLabel lblAccountVal = new JLabel("0");
    private final JLabel lblSystemBalanceVal = new JLabel("0 VND");
    private final JLabel lblTxVolumeVal = new JLabel("0 VND");

    private final AnalyticsChartPanel chartPanel = new AnalyticsChartPanel();
    private final DefaultTableModel recentModel;

    public DashboardPanel(MainFrame parent) {
        setLayout(new BorderLayout(18, 18));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));

        JPanel kpiGrid = new JPanel(new GridLayout(1, 4, 16, 0));
        kpiGrid.setOpaque(false);
        kpiGrid.setPreferredSize(new Dimension(0, 115));

        kpiGrid.add(createKpiCard("TỔNG KHÁCH HÀNG", lblCustomerVal, "Hồ sơ định danh hệ thống", UIHelper.PRIMARY));
        kpiGrid.add(createKpiCard("TÀI KHOẢN HOẠT ĐỘNG", lblAccountVal, "Mỗi SĐT/Email tối đa 1 TK", UIHelper.SUCCESS));
        kpiGrid.add(createKpiCard("TỔNG SỐ DƯ TIỀN GỬI", lblSystemBalanceVal, "Tổng vốn lưu ký trong ngân hàng", UIHelper.PURPLE));
        kpiGrid.add(createKpiCard("DOANH SỐ GIAO DỊCH HỢP LỆ", lblTxVolumeVal, "Tổng lưu lượng GD thành công", UIHelper.WARNING));

        JPanel centerGrid = new JPanel(new GridLayout(1, 2, 18, 0));
        centerGrid.setOpaque(false);

        RoundedCard chartCard = new RoundedCard(new BorderLayout(0, 10));
        chartCard.setBorder(new EmptyBorder(18, 20, 18, 20));
        JLabel lblChartTitle = new JLabel("Biểu đồ Phân tích Lưu lượng theo Loại Giao dịch");
        lblChartTitle.setFont(UIHelper.FONT_SUBTITLE);
        lblChartTitle.setForeground(UIHelper.TEXT_MAIN);
        chartCard.add(lblChartTitle, BorderLayout.NORTH);
        chartCard.add(chartPanel, BorderLayout.CENTER);

        RoundedCard recentCard = new RoundedCard(new BorderLayout(0, 12));
        recentCard.setBorder(new EmptyBorder(18, 20, 18, 20));
        JLabel lblRecentTitle = new JLabel("Nhật ký Giao dịch Gần đây Nhất");
        lblRecentTitle.setFont(UIHelper.FONT_SUBTITLE);
        lblRecentTitle.setForeground(UIHelper.TEXT_MAIN);

        String[] cols = {"Mã GD", "Loại GD", "Số tiền", "Trạng thái", "Thời gian"};
        recentModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable tblRecent = new JTable(recentModel);
        UIHelper.setupModernTable(tblRecent);

        recentCard.add(lblRecentTitle, BorderLayout.NORTH);
        recentCard.add(new JScrollPane(tblRecent), BorderLayout.CENTER);

        centerGrid.add(chartCard);
        centerGrid.add(recentCard);

        add(kpiGrid, BorderLayout.NORTH);
        add(centerGrid, BorderLayout.CENTER);

        refreshData();
    }

    private RoundedCard createKpiCard(String title, JLabel lblMainValue, String subtitle, Color accent) {
        RoundedCard card = new RoundedCard(new BorderLayout(0, 6));
        card.setAccentTopColor(accent);
        card.setBorder(new EmptyBorder(16, 18, 14, 18));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 11));
        lblTitle.setForeground(UIHelper.TEXT_MUTED);

        lblMainValue.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblMainValue.setForeground(UIHelper.TEXT_MAIN);

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(UIHelper.FONT_SMALL);
        lblSub.setForeground(accent);

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(lblMainValue, BorderLayout.CENTER);
        card.add(lblSub, BorderLayout.SOUTH);
        return card;
    }

    public void refreshData() {
        List<Customer> customers = customerService.getAllCustomers();
        List<BankAccount> accounts = accountService.getAllAccounts();
        List<Transaction> txs = transactionService.searchHistory(null, null, "ALL", "ALL");

        long activeAcc = accounts.stream().filter(a -> "ACTIVE".equalsIgnoreCase(a.getStatus())).count();
        BigDecimal totalSystemBalance = accounts.stream()
                .map(BankAccount::getBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalVolume = BigDecimal.ZERO;
        BigDecimal dep = BigDecimal.ZERO;
        BigDecimal wit = BigDecimal.ZERO;
        BigDecimal tra = BigDecimal.ZERO;

        for (Transaction t : txs) {
            if (!"SUCCESS".equalsIgnoreCase(t.getStatus())) continue;
            totalVolume = totalVolume.add(t.getAmount());
            if ("DEPOSIT".equals(t.getTransactionType())) dep = dep.add(t.getAmount());
            else if ("WITHDRAW".equals(t.getTransactionType())) wit = wit.add(t.getAmount());
            else if ("TRANSFER".equals(t.getTransactionType())) tra = tra.add(t.getAmount());
        }

        lblCustomerVal.setText(customers.size() + " Khách hàng");
        lblAccountVal.setText(activeAcc + " / " + accounts.size() + " Tài khoản");
        lblSystemBalanceVal.setText(MoneyUtils.formatVND(totalSystemBalance));
        lblTxVolumeVal.setText(MoneyUtils.formatVND(totalVolume));

        chartPanel.updateValues(dep, wit, tra);

        recentModel.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        for (Transaction t : txs) {
            recentModel.addRow(new Object[]{
                    t.getTransactionCode(), t.getTransactionType(),
                    MoneyUtils.formatVND(t.getAmount()), t.getStatus(),
                    t.getCreatedAt().format(fmt)
            });
        }
    }
}
