package bank.ui;

import bank.config.ApplicationContext;
import bank.model.BankAccount;
import bank.model.Transaction;
import bank.model.User;
import bank.service.AccountService;
import bank.service.TransactionService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernTextField;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import bank.util.MoneyUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

public class TransactionPanel extends JPanel {
    private final MainFrame parent;
    private final User currentUser;
    private final AccountService accountService = ApplicationContext.getBean(AccountService.class);
    private final TransactionService transactionService = ApplicationContext.getBean(TransactionService.class);

    private int selectedMode = 0; // 0: DEPOSIT, 1: WITHDRAW, 2: TRANSFER
    private final ModernButton btnModeDeposit = UIHelper.createButton("📥 Nộp tiền", UIHelper.SUCCESS);
    private final ModernButton btnModeWithdraw = UIHelper.createOutlineButton("📤 Rút tiền");
    private final ModernButton btnModeTransfer = UIHelper.createOutlineButton("🔁 Chuyển khoản");

    private final ModernTextField txtSourceAcc = new ModernTextField("");
    private final JLabel lblSourceTitle;
    private final JLabel lblSourceInfo = new JLabel(" ");
    private final ModernTextField txtDestAcc = new ModernTextField("");
    private final JLabel lblDestInfo = new JLabel(" ");
    private final JPanel destGroupPanel;

    private final ModernTextField txtAmount = new ModernTextField("");
    private final ModernTextField txtDesc = new ModernTextField("Nộp tiền mặt tại quầy");
    private final ModernButton btnSubmit = UIHelper.createButton("KIỂM TRA GIAO DỊCH NỘP TIỀN", UIHelper.SUCCESS);
    private final ModernButton btnPickSrc = UIHelper.createButton("⬅ Chọn tài khoản nộp tiền", UIHelper.PRIMARY);
    private final ModernButton btnPickDst = UIHelper.createButton("⬅ Chọn tài khoản nhận", UIHelper.WARNING);
    private boolean transactionInProgress;

    private final DefaultTableModel accTableModel;
    private final JTable tblAccounts;

    public TransactionPanel(MainFrame parent, User currentUser) {
        this.parent = parent;
        this.currentUser = currentUser;
        setLayout(new GridLayout(1, 2, 18, 0));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));

        RoundedCard leftCard = new RoundedCard(new BorderLayout(0, 12));
        leftCard.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel modeBar = new JPanel(new GridLayout(1, 3, 10, 0));
        modeBar.setOpaque(false);
        modeBar.add(btnModeDeposit);
        modeBar.add(btnModeWithdraw);
        modeBar.add(btnModeTransfer);

        btnModeDeposit.addActionListener(e -> setTransactionMode(0));
        btnModeWithdraw.addActionListener(e -> setTransactionMode(1));
        btnModeTransfer.addActionListener(e -> setTransactionMode(2));

        JPanel formBox = new JPanel();
        formBox.setLayout(new BoxLayout(formBox, BoxLayout.Y_AXIS));
        formBox.setBackground(Color.WHITE);

        JPanel srcGroup = UIHelper.createFieldGroup("Tài khoản nhận tiền nộp:", txtSourceAcc);
        lblSourceTitle = (JLabel) ((BorderLayout) srcGroup.getLayout()).getLayoutComponent(BorderLayout.NORTH);
        srcGroup.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSourceInfo.setFont(UIHelper.FONT_SMALL);
        lblSourceInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        destGroupPanel = new JPanel();
        destGroupPanel.setLayout(new BoxLayout(destGroupPanel, BoxLayout.Y_AXIS));
        destGroupPanel.setOpaque(false);
        destGroupPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel dstFieldBox = UIHelper.createFieldGroup("2. Số tài khoản thụ hưởng (Nhận chuyển khoản):", txtDestAcc);
        dstFieldBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblDestInfo.setFont(UIHelper.FONT_SMALL);
        lblDestInfo.setAlignmentX(Component.LEFT_ALIGNMENT);
        destGroupPanel.add(dstFieldBox);
        destGroupPanel.add(Box.createVerticalStrut(4));
        destGroupPanel.add(lblDestInfo);
        destGroupPanel.add(Box.createVerticalStrut(10));
        destGroupPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        destGroupPanel.setVisible(false);

        JPanel amountGroup = UIHelper.createFieldGroup("Số tiền giao dịch (VND):", txtAmount);
        amountGroup.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel quickMoneyBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        quickMoneyBar.setOpaque(false);
        quickMoneyBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        quickMoneyBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        long[] presets = {100000L, 500000L, 1000000L, 5000000L, 10000000L};
        String[] presetLabels = {"+100k", "+500k", "+1M", "+5M", "+10M"};
        for (int i = 0; i < presets.length; i++) {
            long addVal = presets[i];
            ModernButton chip = UIHelper.createOutlineButton(presetLabels[i]);
            chip.setBorder(new EmptyBorder(4, 10, 4, 10));
            chip.setFont(UIHelper.FONT_SMALL);
            chip.addActionListener(e -> addQuickAmount(addVal));
            quickMoneyBar.add(chip);
        }
        ModernButton btnClearAmt = UIHelper.createOutlineButton("Xóa");
        btnClearAmt.setBorder(new EmptyBorder(4, 10, 4, 10));
        btnClearAmt.setFont(UIHelper.FONT_SMALL);
        btnClearAmt.addActionListener(e -> txtAmount.setText(""));
        quickMoneyBar.add(btnClearAmt);

        JPanel descGroup = UIHelper.createFieldGroup("Nội dung diễn giải:", txtDesc);
        descGroup.setAlignmentX(Component.LEFT_ALIGNMENT);

        formBox.add(srcGroup);
        formBox.add(Box.createVerticalStrut(4));
        formBox.add(lblSourceInfo);
        formBox.add(Box.createVerticalStrut(10));
        formBox.add(destGroupPanel);
        formBox.add(amountGroup);
        formBox.add(Box.createVerticalStrut(4));
        formBox.add(quickMoneyBar);
        formBox.add(Box.createVerticalStrut(8));
        formBox.add(descGroup);
        formBox.add(Box.createVerticalGlue());

        JScrollPane formScroll = new JScrollPane(formBox);
        formScroll.setBorder(null);
        formScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        formScroll.getVerticalScrollBar().setUnitIncrement(12);

        btnSubmit.setPreferredSize(new Dimension(0, 42));
        btnSubmit.addActionListener(e -> executeTransaction());

        leftCard.add(modeBar, BorderLayout.NORTH);
        leftCard.add(formScroll, BorderLayout.CENTER);
        leftCard.add(btnSubmit, BorderLayout.SOUTH);

        RoundedCard rightCard = new RoundedCard(new BorderLayout(0, 12));
        rightCard.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel lblRightTitle = new JLabel("Chọn tài khoản rồi bấm nút bên dưới để điền");
        lblRightTitle.setFont(UIHelper.FONT_SUBTITLE);

        String[] cols = {"Số tài khoản", "Chủ tài khoản", "Số dư khả dụng", "Trạng thái"};
        accTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tblAccounts = new JTable(accTableModel);
        UIHelper.setupModernTable(tblAccounts);

        JPanel pickBar = new JPanel(new GridLayout(1, 2, 10, 0));
        pickBar.setOpaque(false);
        btnPickSrc.setEnabled(false);
        btnPickDst.setEnabled(false);
        tblAccounts.getSelectionModel().addListSelectionListener(e -> {
            boolean selected = tblAccounts.getSelectedRow() >= 0;
            btnPickSrc.setEnabled(selected);
            btnPickDst.setEnabled(selected);
        });

        btnPickSrc.addActionListener(e -> {
            int r = tblAccounts.getSelectedRow();
            if (r >= 0) {
                int modelRow = tblAccounts.convertRowIndexToModel(r);
                txtSourceAcc.setText(accTableModel.getValueAt(modelRow, 0).toString());
            }
        });
        btnPickDst.addActionListener(e -> {
            int r = tblAccounts.getSelectedRow();
            if (r >= 0) {
                int modelRow = tblAccounts.convertRowIndexToModel(r);
                setTransactionMode(2);
                txtDestAcc.setText(accTableModel.getValueAt(modelRow, 0).toString());
            }
        });

        pickBar.add(btnPickSrc);
        pickBar.add(btnPickDst);

        rightCard.add(lblRightTitle, BorderLayout.NORTH);
        rightCard.add(new JScrollPane(tblAccounts), BorderLayout.CENTER);
        rightCard.add(pickBar, BorderLayout.SOUTH);

        DocumentListener lookupListener = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updateAccountPreview(); }
            public void removeUpdate(DocumentEvent e) { updateAccountPreview(); }
            public void changedUpdate(DocumentEvent e) { updateAccountPreview(); }
        };
        txtSourceAcc.getDocument().addDocumentListener(lookupListener);
        txtDestAcc.getDocument().addDocumentListener(lookupListener);

        add(leftCard);
        add(rightCard);

        refreshAccountList();
        updateAccountPreview();
    }

    public void prefillSourceAccount(String accNum) {
        txtSourceAcc.setText(accNum);
        updateAccountPreview();
    }

    private void setTransactionMode(int mode) {
        this.selectedMode = mode;
        btnModeDeposit.setColors(mode == 0 ? UIHelper.SUCCESS : new Color(241, 245, 249), mode == 0 ? Color.WHITE : UIHelper.TEXT_MAIN);
        btnModeWithdraw.setColors(mode == 1 ? UIHelper.DANGER : new Color(241, 245, 249), mode == 1 ? Color.WHITE : UIHelper.TEXT_MAIN);
        btnModeTransfer.setColors(mode == 2 ? UIHelper.WARNING : new Color(241, 245, 249), mode == 2 ? Color.WHITE : UIHelper.TEXT_MAIN);

        destGroupPanel.setVisible(mode == 2);
        if (mode == 0) {
            lblSourceTitle.setText("Tài khoản nhận tiền nộp:");
            btnPickSrc.setText("⬅ Chọn tài khoản nộp tiền");
            btnSubmit.setText("KIỂM TRA GIAO DỊCH NỘP TIỀN");
            btnSubmit.setColors(UIHelper.SUCCESS, Color.WHITE);
            txtDesc.setText("Nộp tiền mặt tại quầy");
        } else if (mode == 1) {
            lblSourceTitle.setText("Tài khoản rút tiền:");
            btnPickSrc.setText("⬅ Chọn tài khoản rút tiền");
            btnSubmit.setText("KIỂM TRA GIAO DỊCH RÚT TIỀN");
            btnSubmit.setColors(UIHelper.DANGER, Color.WHITE);
            txtDesc.setText("Rút tiền mặt tại quầy");
        } else {
            lblSourceTitle.setText("Tài khoản gửi tiền:");
            btnPickSrc.setText("⬅ Chọn tài khoản gửi");
            btnSubmit.setText("KIỂM TRA GIAO DỊCH CHUYỂN TIỀN");
            btnSubmit.setColors(UIHelper.WARNING, Color.WHITE);
            txtDesc.setText("Chuyển khoản liên tài khoản");
        }
        revalidate();
        repaint();
    }

    private void addQuickAmount(long addValue) {
        String raw = txtAmount.getText().trim().replace(".", "").replace(",", "");
        long current = 0;
        try {
            if (!raw.isEmpty()) current = Long.parseLong(raw);
        } catch (NumberFormatException ignored) {
        }
        long next = current + addValue;
        txtAmount.setText(String.valueOf(next));
    }

    private void updateAccountPreview() {
        BankAccount src = accountService.findByAccountNumber(txtSourceAcc.getText().trim());
        if (src != null) {
            lblSourceInfo.setForeground("ACTIVE".equalsIgnoreCase(src.getStatus()) ? new Color(6, 95, 70) : UIHelper.DANGER);
            lblSourceInfo.setText("✔ Chủ TK: " + src.getCustomerName() + " | Số dư: " + MoneyUtils.formatVND(src.getBalance()) + " [" + UiLabels.text(src.getStatus()) + "]");
        } else {
            lblSourceInfo.setForeground(UIHelper.DANGER);
            lblSourceInfo.setText(txtSourceAcc.getText().isBlank() ? "Nhập số tài khoản hoặc chọn trong danh sách bên phải." : "✖ Không tìm thấy tài khoản này");
        }

        BankAccount dst = accountService.findByAccountNumber(txtDestAcc.getText().trim());
        if (dst != null) {
            lblDestInfo.setForeground("ACTIVE".equalsIgnoreCase(dst.getStatus()) ? new Color(6, 95, 70) : UIHelper.DANGER);
            lblDestInfo.setText("✔ Người nhận: " + dst.getCustomerName() + " [" + UiLabels.text(dst.getStatus()) + "]");
        } else {
            lblDestInfo.setForeground(UIHelper.DANGER);
            lblDestInfo.setText(txtDestAcc.getText().isBlank() ? "Nhập hoặc chọn tài khoản nhận tiền." : "✖ Không tìm thấy tài khoản nhận");
        }
    }

    public void refreshAccountList() {
        String selectedAccount = null;
        int oldSelection = tblAccounts.getSelectedRow();
        if (oldSelection >= 0) {
            selectedAccount = accTableModel.getValueAt(tblAccounts.convertRowIndexToModel(oldSelection), 0).toString();
        }
        accTableModel.setRowCount(0);
        for (BankAccount a : accountService.getAllAccounts()) {
            accTableModel.addRow(new Object[]{
                    a.getAccountNumber(), a.getCustomerName(),
                    MoneyUtils.formatVND(a.getBalance()), a.getStatus()
            });
        }
        if (selectedAccount != null) {
            for (int row = 0; row < accTableModel.getRowCount(); row++) {
                if (selectedAccount.equals(accTableModel.getValueAt(row, 0))) {
                    int viewRow = tblAccounts.convertRowIndexToView(row);
                    if (viewRow >= 0) tblAccounts.setRowSelectionInterval(viewRow, viewRow);
                    break;
                }
            }
        }
        updateAccountPreview();
    }

    private void executeTransaction() {
        if (transactionInProgress) return;
        transactionInProgress = true;
        btnSubmit.setEnabled(false);
        try {
            int mode = selectedMode;
            BigDecimal amount = MoneyUtils.parseAmount(txtAmount.getText());
            String acc1 = txtSourceAcc.getText().trim();
            String acc2 = txtDestAcc.getText().trim();
            String desc = txtDesc.getText().trim();
            if (desc.isEmpty()) {
                desc = mode == 0 ? "Nộp tiền mặt tại quầy"
                        : mode == 1 ? "Rút tiền mặt tại quầy" : "Chuyển khoản liên tài khoản";
            }
            BankAccount mainAccount = accountService.findByAccountNumber(acc1);
            BankAccount recipient = mode == 2 ? accountService.findByAccountNumber(acc2) : null;
            String review = buildReviewHtml(mode, mainAccount, recipient, amount, desc);
            if (!showReviewDialog(review)) return;

            Transaction tx;
            if (mode == 0) {
                tx = transactionService.deposit(acc1, amount, desc, currentUser);
            } else if (mode == 1) {
                tx = transactionService.withdraw(acc1, amount, desc, currentUser);
            } else {
                tx = transactionService.transfer(acc1, acc2, amount, desc, currentUser);
            }

            txtAmount.setText("");
            parent.refreshAllViews();
            showReceiptDialog(tx);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể thực hiện giao dịch", JOptionPane.ERROR_MESSAGE);
        } finally {
            transactionInProgress = false;
            btnSubmit.setEnabled(true);
        }
    }

    /** Xem trước chỉ đọc số dư hiện tại; nghiệp vụ vẫn kiểm tra lại khi xác nhận. */
    static String buildReviewHtml(int mode, BankAccount mainAccount, BankAccount recipient,
                                  BigDecimal amount, String description) {
        if (mode < 0 || mode > 2) throw new IllegalArgumentException("Loại giao dịch không hợp lệ.");
        MoneyUtils.validateAmount(amount);
        String mainLabel = mode == 0 ? "Tài khoản nhận tiền nộp"
                : mode == 1 ? "Tài khoản rút tiền" : "Tài khoản gửi tiền";
        requireActiveAccount(mainAccount, mainLabel);
        if (mode != 0 && mainAccount.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException(mainLabel + " không đủ số dư khả dụng.");
        }
        if (mode == 2) {
            requireActiveAccount(recipient, "Tài khoản nhận tiền");
            if (mainAccount.getAccountNumber().equals(recipient.getAccountNumber())) {
                throw new IllegalArgumentException("Tài khoản gửi và tài khoản nhận phải khác nhau.");
            }
        }
        String type = mode == 0 ? "DEPOSIT" : mode == 1 ? "WITHDRAW" : "TRANSFER";
        BigDecimal mainAfter = mode == 0 ? mainAccount.getBalance().add(amount)
                : mainAccount.getBalance().subtract(amount);
        StringBuilder html = new StringBuilder("<html><div style='width:410px;padding:8px;font-family:SansSerif'>")
                .append("<h3 style='margin:0'>Kiểm tra thông tin trước khi thực hiện</h3>")
                .append("<p>Vui lòng kiểm tra tài khoản và số tiền. Chưa có giao dịch nào được ghi nhận.</p>")
                .append("<p><b>Loại giao dịch:</b> ").append(escapeHtml(UiLabels.text(type))).append("</p>");
        appendAccountReview(html, mainLabel, mainAccount, mainAfter);
        if (mode == 2) {
            appendAccountReview(html, "Tài khoản nhận tiền", recipient, recipient.getBalance().add(amount));
        }
        html.append("<p><b>Số tiền:</b> ").append(escapeHtml(MoneyUtils.formatVND(amount))).append("</p>")
                .append("<p><b>Nội dung:</b> ").append(escapeHtml(description)).append("</p>")
                .append("<p style='color:#64748b'>Số dư sau giao dịch là dự kiến; hệ thống sẽ kiểm tra lại khi xác nhận.</p>")
                .append("</div></html>");
        return html.toString();
    }

    private static void requireActiveAccount(BankAccount account, String label) {
        if (account == null) throw new IllegalArgumentException(label + " không tồn tại. Vui lòng chọn lại tài khoản.");
        if (!"ACTIVE".equalsIgnoreCase(account.getStatus())) {
            throw new IllegalArgumentException(label + " đang ở trạng thái " + UiLabels.text(account.getStatus()) + ".");
        }
    }

    private static void appendAccountReview(StringBuilder html, String label, BankAccount account, BigDecimal after) {
        html.append("<p><b>").append(escapeHtml(label)).append(":</b> ")
                .append(escapeHtml(account.getAccountNumber())).append("<br>")
                .append("<b>Chủ tài khoản:</b> ").append(escapeHtml(account.getCustomerName())).append("<br>")
                .append("<b>Số dư hiện tại:</b> ").append(escapeHtml(MoneyUtils.formatVND(account.getBalance()))).append("<br>")
                .append("<b>Số dư dự kiến:</b> ").append(escapeHtml(MoneyUtils.formatVND(after))).append("</p>");
    }

    protected boolean showReviewDialog(String html) {
        Object[] options = {"Quay lại sửa", "Xác nhận giao dịch"};
        int choice = JOptionPane.showOptionDialog(this, new JLabel(html), "Kiểm tra giao dịch",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return choice == 1;
    }

    private static String escapeHtml(String value) {
        return UiLabels.html(value).replace("\n", "<br>");
    }

    protected void showReceiptDialog(Transaction tx) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        StringBuilder accounts = new StringBuilder();
        if ("DEPOSIT".equals(tx.getTransactionType())) {
            appendReceiptAccount(accounts, "Tài khoản nhận tiền nộp", tx.getDestinationAccountNumber());
        } else if ("WITHDRAW".equals(tx.getTransactionType())) {
            appendReceiptAccount(accounts, "Tài khoản rút tiền", tx.getSourceAccountNumber());
        } else {
            appendReceiptAccount(accounts, "Tài khoản gửi", tx.getSourceAccountNumber());
            appendReceiptAccount(accounts, "Tài khoản nhận", tx.getDestinationAccountNumber());
        }
        String html = "<html><div style='width:310px;padding:8px;font-family:SansSerif'>"
                + "<h3 style='color:#065f46;margin:0'>✔ GIAO DỊCH THÀNH CÔNG (ĐÃ LƯU)</h3>"
                + "<hr style='border:1px dashed #cbd5e1'>"
                + "<p><b>Mã giao dịch:</b> " + escapeHtml(tx.getTransactionCode()) + "</p>"
                + "<p><b>Loại giao dịch:</b> " + escapeHtml(UiLabels.text(tx.getTransactionType())) + "</p>"
                + accounts
                + "<p><b>Số tiền:</b> <span style='color:#2563eb;font-size:14px'><b>" + MoneyUtils.formatVND(tx.getAmount()) + "</b></span></p>"
                + "<p><b>Nội dung:</b> " + escapeHtml(tx.getDescription()) + "</p>"
                + "<p><b>Giao dịch viên:</b> " + escapeHtml(tx.getCreatedByUsername()) + "</p>"
                + "<p><b>Thời gian:</b> " + tx.getCreatedAt().format(fmt) + "</p>"
                + "</div></html>";
        JOptionPane.showMessageDialog(this, new JLabel(html), "Biên lai Giao dịch Ngân hàng", JOptionPane.PLAIN_MESSAGE);
    }

    private void appendReceiptAccount(StringBuilder html, String label, String number) {
        BankAccount account = accountService.findByAccountNumber(number);
        html.append("<p><b>").append(escapeHtml(label)).append(":</b> ").append(escapeHtml(number));
        if (account != null) html.append("<br><b>Chủ tài khoản:</b> ").append(escapeHtml(account.getCustomerName()));
        html.append("</p>");
    }
}
