package bank.ui;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.dao.UserDAO;
import bank.model.User;
import bank.service.AuthService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernPasswordField;
import bank.ui.components.ModernTextField;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import bank.util.PasswordUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class StaffPanel extends JPanel {
    private final MainFrame parent;
    private final User currentUser;
    private final UserDAO userDAO = ApplicationContext.getBean(UserDAO.class);
    private final DefaultTableModel tableModel;
    private final JTable table;
    private List<User> staffList = new ArrayList<>();

    public StaffPanel(MainFrame parent, User currentUser) {
        this.parent = parent;
        this.currentUser = currentUser;
        setLayout(new BorderLayout(0, 16));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));

        RoundedCard topBar = new RoundedCard(new BorderLayout(10, 0));
        topBar.setBorder(new EmptyBorder(12, 16, 12, 16));

        JLabel lblTitle = new JLabel("Tài khoản nhân viên và quyền truy cập");
        lblTitle.setFont(UIHelper.FONT_SUBTITLE);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        ModernButton btnAdd = UIHelper.createButton("+ Thêm Nhân viên", UIHelper.SUCCESS);
        ModernButton btnRole = UIHelper.createButton("🔄 Đổi vai trò", UIHelper.PRIMARY);
        ModernButton btnResetPass = UIHelper.createButton("🔑 Đặt lại mật khẩu", UIHelper.WARNING);
        ModernButton btnLock = UIHelper.createButton("🔒 Khóa / Mở khóa", UIHelper.DANGER);

        btnAdd.addActionListener(e -> addStaffDialog());
        btnRole.addActionListener(e -> changeRole());
        btnResetPass.addActionListener(e -> resetPassword());
        btnLock.addActionListener(e -> toggleLock());

        actions.add(btnAdd);
        actions.add(btnRole);
        actions.add(btnResetPass);
        actions.add(btnLock);

        topBar.add(lblTitle, BorderLayout.NORTH);
        topBar.add(actions, BorderLayout.CENTER);

        RoundedCard tableCard = new RoundedCard(new BorderLayout());
        tableCard.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[] cols = {"ID", "Họ và tên nhân viên", "Tên đăng nhập", "Vai trò", "Trạng thái", "Ngày tạo"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        UIHelper.setupModernTable(table);
        Runnable updateActions = () -> {
            boolean hasSelection = table.getSelectedRow() >= 0;
            boolean admin = "ADMIN".equalsIgnoreCase(currentUser.getRole())
                    && "ACTIVE".equalsIgnoreCase(currentUser.getStatus());
            btnAdd.setEnabled(admin);
            btnRole.setEnabled(admin && hasSelection);
            btnResetPass.setEnabled(admin && hasSelection);
            btnLock.setEnabled(admin && hasSelection);
        };
        table.getSelectionModel().addListSelectionListener(e -> updateActions.run());
        updateActions.run();
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(tableCard, BorderLayout.CENTER);
        JPanel adminTools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        adminTools.setOpaque(false);
        ModernButton btnResetDemo = UIHelper.createOutlineButton("Khôi phục dữ liệu mẫu");
        btnResetDemo.setEnabled("ADMIN".equalsIgnoreCase(currentUser.getRole())
                && !DatabaseConnection.isMySqlMode());
        btnResetDemo.addActionListener(e -> resetDemoData());
        adminTools.add(btnResetDemo);
        adminTools.add(new JLabel("Chỉ quản trị viên • Tự sao lưu trước khi khôi phục"));
        add(adminTools, BorderLayout.SOUTH);
        refreshTable();
    }

    private void resetDemoData() {
        try {
            AuthService.requireAdmin(currentUser);
            int choice = JOptionPane.showConfirmDialog(this,
                    "Toàn bộ khách hàng, tài khoản và giao dịch hiện tại sẽ được thay bằng dữ liệu mẫu.\n"
                            + "Hệ thống sẽ tạo bản sao lưu trước khi thay đổi và yêu cầu đăng nhập lại.\n"
                            + "Bạn có muốn tiếp tục?",
                    "Khôi phục dữ liệu mẫu", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) return;
            DatabaseConnection.resetToDefaultData();
            JOptionPane.showMessageDialog(this, "Đã khôi phục dữ liệu mẫu. Vui lòng đăng nhập lại.");
            parent.dispose();
            new LoginFrame().setVisible(true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể khôi phục dữ liệu", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void refreshTable() {
        staffList = userDAO.findAll();
        tableModel.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (User u : staffList) {
            tableModel.addRow(new Object[]{
                    u.getId(), u.getFullName(), u.getUsername(), u.getRole(), u.getStatus(),
                    u.getCreatedAt() != null ? u.getCreatedAt().format(fmt) : "-"
            });
        }
    }

    private long countActiveAdmins() {
        return userDAO.findAll().stream()
                .filter(u -> "ADMIN".equalsIgnoreCase(u.getRole()) && "ACTIVE".equalsIgnoreCase(u.getStatus()))
                .count();
    }

    private void addStaffDialog() {
        JDialog dialog = new JDialog(parent, "Thêm Nhân viên Mới", true);
        dialog.setSize(440, 330);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        ModernTextField txtUser = new ModernTextField();
        ModernTextField txtName = new ModernTextField();
        ModernPasswordField txtPass = new ModernPasswordField("staff123", 16);
        JComboBox<String> cbRole = new JComboBox<>(new String[]{"STAFF", "ADMIN"});
        UiLabels.localizeCombo(cbRole);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(18, 22, 18, 22));

        String[] labels = {"Tên đăng nhập (*):", "Họ và tên (*):", "Mật khẩu khởi tạo (*):", "Vai trò hệ thống:"};
        JComponent[] fields = {txtUser, txtName, txtPass, cbRole};
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 6, 7, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.38;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(UIHelper.FONT_BOLD);
            form.add(lbl, gbc);
            gbc.gridx = 1; gbc.weightx = 0.62;
            form.add(fields[i], gbc);
        }

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        ModernButton btnCancel = UIHelper.createOutlineButton("Hủy");
        ModernButton btnSave = UIHelper.createButton("Tạo Nhân viên", UIHelper.SUCCESS);

        btnCancel.addActionListener(e -> dialog.dispose());
        btnSave.addActionListener(e -> {
            try {
                AuthService.requireAdmin();
                String uname = txtUser.getText().trim();
                String fname = txtName.getText().trim();
                String rawPass = new String(txtPass.getPassword()).trim();
                if (uname.isEmpty() || fname.isEmpty() || rawPass.length() < 6) {
                    throw new IllegalArgumentException("Vui lòng nhập đầy đủ Tên đăng nhập, Họ tên và Mật khẩu (>= 6 ký tự).");
                }
                if (userDAO.findByUsername(uname) != null) {
                    throw new IllegalArgumentException("Tên đăng nhập '" + uname + "' đã tồn tại!");
                }
                User u = new User(0L, uname, PasswordUtils.hashPassword(rawPass),
                        fname, (String) cbRole.getSelectedItem(), "ACTIVE", LocalDateTime.now());
                userDAO.insert(u);
                dialog.dispose();
                refreshTable();
                    JOptionPane.showMessageDialog(this, "Đã tạo tài khoản nhân viên '" + uname + "'.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        footer.add(btnCancel);
        footer.add(btnSave);
        dialog.add(form, BorderLayout.CENTER);
        dialog.add(footer, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void changeRole() {
        try {
            AuthService.requireAdmin();
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên trên bảng.");
                return;
            }
            User u = staffList.get(table.convertRowIndexToModel(viewRow));
            if (u.getId() == currentUser.getId()) {
                JOptionPane.showMessageDialog(this, "Không thể tự thay đổi vai trò của chính mình.");
                return;
            }
            if ("ADMIN".equalsIgnoreCase(u.getRole()) && countActiveAdmins() <= 1) {
                JOptionPane.showMessageDialog(this, "Không thể hạ quyền quản trị viên (ADMIN) duy nhất đang hoạt động!");
                return;
            }
            String newRole = "ADMIN".equalsIgnoreCase(u.getRole()) ? "STAFF" : "ADMIN";
            u.setRole(newRole);
            userDAO.update(u);
            refreshTable();
            JOptionPane.showMessageDialog(this,
                        "Đã đổi vai trò của '" + u.getUsername() + "' thành " + UiLabels.text(newRole) + ".");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Từ chối phân quyền", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetPassword() {
        try {
            AuthService.requireAdmin();
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên để đặt lại mật khẩu.");
                return;
            }
            User u = staffList.get(table.convertRowIndexToModel(viewRow));
            String newPass = JOptionPane.showInputDialog(this,
                    "Nhập mật khẩu mới (>= 6 ký tự) cho nhân viên '" + u.getUsername() + "':", "staff123");
            if (newPass != null && !newPass.isBlank()) {
                if (newPass.trim().length() < 6) {
                    JOptionPane.showMessageDialog(this, "Mật khẩu phải có từ 6 ký tự trở lên.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                u.setPasswordHash(PasswordUtils.hashPassword(newPass.trim()));
                userDAO.update(u);
                JOptionPane.showMessageDialog(this, "Đã cập nhật mật khẩu mới cho " + u.getFullName() + ".");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void toggleLock() {
        try {
            AuthService.requireAdmin();
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một nhân viên trên bảng.");
                return;
            }
            User u = staffList.get(table.convertRowIndexToModel(viewRow));
            if (u.getId() == currentUser.getId()) {
                JOptionPane.showMessageDialog(this, "Không thể tự khóa tài khoản đang đăng nhập.");
                return;
            }
            if ("ADMIN".equalsIgnoreCase(u.getRole()) && "ACTIVE".equalsIgnoreCase(u.getStatus()) && countActiveAdmins() <= 1) {
                JOptionPane.showMessageDialog(this, "Không thể khóa tài khoản ADMIN duy nhất còn hoạt động!");
                return;
            }
            u.setStatus("ACTIVE".equalsIgnoreCase(u.getStatus()) ? "LOCKED" : "ACTIVE");
            userDAO.update(u);
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
