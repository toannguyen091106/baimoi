package bank.ui;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.model.Customer;
import bank.model.User;
import bank.service.AuthService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernPasswordField;
import bank.ui.components.SidebarNavButton;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MainFrame extends JFrame {
    private final User currentUser;
    private final CardLayout contentCardLayout = new CardLayout();
    private final JPanel contentArea = new JPanel(contentCardLayout);
    private final JLabel lblPageTitle = new JLabel("Tổng quan Hệ thống Ngân hàng");
    private final List<SidebarNavButton> navButtons = new ArrayList<>();

    private final DashboardPanel dashboardPanel;
    private final CustomerPanel customerPanel;
    private final AccountPanel accountPanel;
    private final TransactionPanel transactionPanel;
    private final HistoryPanel historyPanel;
    private final StaffPanel staffPanel;

    public MainFrame(User user) {
        this.currentUser = user;
        setTitle("Quản lý ngân hàng - " + user.getFullName() + " [" + UiLabels.text(user.getRole()) + "]");
        setSize(1320, 780);
        setMinimumSize(new Dimension(1150, 680));
        WindowCloseHandler.install(this);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UIHelper.APP_BG);

        // 1. SIDEBAR BÊN TRÁI
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(UIHelper.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(250, 0));

        JPanel brandHeader = new JPanel(new BorderLayout(10, 4));
        brandHeader.setOpaque(false);
        brandHeader.setBorder(new EmptyBorder(22, 20, 20, 20));
        JLabel lblLogo = new JLabel("🏦 CORE BANKING");
        lblLogo.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblLogo.setForeground(Color.WHITE);
        JLabel lblVersion = new JLabel("Quản lý giao dịch tại quầy");
        lblVersion.setFont(UIHelper.FONT_SMALL);
        lblVersion.setForeground(new Color(148, 163, 184));
        brandHeader.add(lblLogo, BorderLayout.NORTH);
        brandHeader.add(lblVersion, BorderLayout.SOUTH);

        JPanel menuContainer = new JPanel();
        menuContainer.setLayout(new BoxLayout(menuContainer, BoxLayout.Y_AXIS));
        menuContainer.setOpaque(false);
        menuContainer.setBorder(new EmptyBorder(10, 12, 10, 12));

        dashboardPanel = new DashboardPanel(this);
        customerPanel = new CustomerPanel(this);
        accountPanel = new AccountPanel(this, currentUser);
        transactionPanel = new TransactionPanel(this, currentUser);
        historyPanel = new HistoryPanel(this, currentUser);
        staffPanel = new StaffPanel(this, currentUser);

        contentArea.setOpaque(false);
        contentArea.add(dashboardPanel, "DASHBOARD");
        contentArea.add(customerPanel, "CUSTOMER");
        contentArea.add(accountPanel, "ACCOUNT");
        contentArea.add(transactionPanel, "TRANSACTION");
        contentArea.add(historyPanel, "HISTORY");
        if ("ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            contentArea.add(staffPanel, "STAFF");
        }

        addNavItem(menuContainer, "📊  Trang chủ Thống kê", "DASHBOARD", "Tổng quan Hệ thống & Phân tích Dòng tiền", true);
        addNavItem(menuContainer, "👥  Quản lý Khách hàng", "CUSTOMER", "Quản lý Hồ sơ & Định danh Khách hàng", false);
        addNavItem(menuContainer, "💳  Quản lý Tài khoản", "ACCOUNT", "Quản lý Tài khoản & Nhật ký Trạng thái", false);
        addNavItem(menuContainer, "💸  Giao dịch Tại quầy", "TRANSACTION", "Thực hiện Giao dịch Nộp / Rút / Chuyển khoản", false);
        addNavItem(menuContainer, "📜  Lịch sử & Bút toán", "HISTORY", "Tra cứu Lịch sử Giao dịch, Sổ phụ & Hoàn tác", false);
        if ("ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            addNavItem(menuContainer, "🛡️  Nhân sự & Phân quyền", "STAFF", "Quản lý Nhân viên & Phân quyền Hệ thống", false);
        }

        // Khu vực thông tin User & Nút mở Web Portal dưới đáy Sidebar
        JPanel sidebarFooter = new JPanel();
        sidebarFooter.setLayout(new BoxLayout(sidebarFooter, BoxLayout.Y_AXIS));
        sidebarFooter.setOpaque(false);
        sidebarFooter.setBorder(new EmptyBorder(15, 16, 20, 16));

        ModernButton btnOpenWeb = UIHelper.createButton("🌐 Mở trang thống kê", new Color(14, 116, 144));
        btnOpenWeb.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnOpenWeb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        btnOpenWeb.addActionListener(e -> {
            try {
                Desktop.getDesktop().browse(new URI("http://localhost:" + ApplicationContext.getActivePort()));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Truy cập trình duyệt tại: http://localhost:" + ApplicationContext.getActivePort());
            }
        });

        JLabel lblUserInfo = new JLabel("<html><div style='color:#e2e8f0;margin-top:10px'><b>" + UiLabels.html(user.getFullName())
                + "</b> (" + UiLabels.html(user.getUsername()) + ")<br><span style='color:#38bdf8;font-size:11px'>Vai trò: "
                + UiLabels.html(UiLabels.text(user.getRole())) + "</span></div></html>");
        lblUserInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        ModernButton btnLogout = UIHelper.createButton("Đăng xuất", UIHelper.DANGER);
        btnLogout.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLogout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        btnLogout.addActionListener(e -> {
            try {
                DatabaseConnection.saveState();
                AuthService.logout();
                dispose();
                new LoginFrame().setVisible(true);
            } catch (RuntimeException error) {
                JOptionPane.showMessageDialog(this,
                        "Chưa thể lưu dữ liệu nên phiên làm việc vẫn được giữ mở.\n" + error.getMessage(),
                        "Không thể đăng xuất", JOptionPane.ERROR_MESSAGE);
            }
        });

        sidebarFooter.add(btnOpenWeb);
        sidebarFooter.add(Box.createVerticalStrut(8));
        sidebarFooter.add(lblUserInfo);
        sidebarFooter.add(Box.createVerticalStrut(12));
        sidebarFooter.add(btnLogout);

        sidebar.add(brandHeader, BorderLayout.NORTH);
        sidebar.add(menuContainer, BorderLayout.CENTER);
        sidebar.add(sidebarFooter, BorderLayout.SOUTH);

        // 2. KHU VỰC BÊN PHẢI (TOP HEADER + CONTENT)
        JPanel mainWrapper = new JPanel(new BorderLayout());
        mainWrapper.setBackground(UIHelper.APP_BG);

        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setBackground(Color.WHITE);
        topHeader.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UIHelper.BORDER_COLOR),
                new EmptyBorder(12, 24, 12, 24)
        ));

        lblPageTitle.setFont(UIHelper.FONT_TITLE);
        lblPageTitle.setForeground(UIHelper.TEXT_MAIN);

        JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        headerRight.setOpaque(false);

        String dbStatus = DatabaseConnection.isMySqlMode() ? "Đã kết nối cơ sở dữ liệu" : "Tự động lưu dữ liệu";
        JLabel lblBadge = new JLabel("● " + dbStatus);
        lblBadge.setFont(UIHelper.FONT_BOLD);
        lblBadge.setForeground(UIHelper.SUCCESS);

        ModernButton btnChangePass = UIHelper.createOutlineButton("🔑 Đổi mật khẩu");
        btnChangePass.addActionListener(e -> showChangeOwnPasswordDialog());

        ModernButton btnQuickRefresh = UIHelper.createOutlineButton("🔄 Làm mới");
        btnQuickRefresh.addActionListener(e -> refreshAllViews());

        headerRight.add(lblBadge);
        headerRight.add(btnChangePass);
        headerRight.add(btnQuickRefresh);

        topHeader.add(lblPageTitle, BorderLayout.WEST);
        topHeader.add(headerRight, BorderLayout.EAST);

        mainWrapper.add(topHeader, BorderLayout.NORTH);
        mainWrapper.add(contentArea, BorderLayout.CENTER);

        root.add(sidebar, BorderLayout.WEST);
        root.add(mainWrapper, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void showChangeOwnPasswordDialog() {
        JDialog dialog = new JDialog(this, "Đổi Mật khẩu Cá nhân (" + currentUser.getUsername() + ")", true);
        dialog.setSize(420, 270);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        ModernPasswordField txtOld = new ModernPasswordField("", 16);
        ModernPasswordField txtNew = new ModernPasswordField("", 16);
        ModernPasswordField txtConfirm = new ModernPasswordField("", 16);

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 12));
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(18, 22, 18, 22));
        form.add(new JLabel("Mật khẩu hiện tại (*):"));
        form.add(txtOld);
        form.add(new JLabel("Mật khẩu mới (>= 6 ký tự):"));
        form.add(txtNew);
        form.add(new JLabel("Nhập lại mật khẩu mới:"));
        form.add(txtConfirm);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        ModernButton btnCancel = UIHelper.createOutlineButton("Hủy");
        ModernButton btnSave = UIHelper.createButton("Lưu Mật khẩu", UIHelper.SUCCESS);

        btnCancel.addActionListener(e -> dialog.dispose());
        btnSave.addActionListener(e -> {
            try {
                String p1 = new String(txtNew.getPassword());
                String p2 = new String(txtConfirm.getPassword());
                if (!p1.equals(p2)) {
                    throw new IllegalArgumentException("Mật khẩu mới nhập lại không khớp.");
                }
                ApplicationContext.getBean(AuthService.class)
                        .changeOwnPassword(currentUser, new String(txtOld.getPassword()), p1);
                dialog.dispose();
                JOptionPane.showMessageDialog(this, "Đã đổi mật khẩu. Hãy dùng mật khẩu mới cho lần đăng nhập tiếp theo.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        footer.add(btnCancel);
        footer.add(btnSave);
        dialog.add(form, BorderLayout.CENTER);
        dialog.add(footer, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void addNavItem(JPanel container, String text, String cardKey, String headerTitle, boolean active) {
        SidebarNavButton btn = new SidebarNavButton(text, active);
        btn.putClientProperty("cardKey", cardKey);
        btn.addActionListener(e -> switchScreen(cardKey, headerTitle, btn));
        navButtons.add(btn);
        container.add(btn);
        container.add(Box.createVerticalStrut(6));
    }

    public void switchScreen(String cardKey, String headerTitle, SidebarNavButton clickedBtn) {
        for (SidebarNavButton b : navButtons) {
            b.setActive(b == clickedBtn);
        }
        lblPageTitle.setText(headerTitle);
        refreshAllViews();
        contentCardLayout.show(contentArea, cardKey);
    }

    public void navigateToTransactionTab(String accountNumber) {
        navigateToScreen("TRANSACTION", "Thực hiện giao dịch nộp / rút / chuyển khoản");
        transactionPanel.prefillSourceAccount(accountNumber);
    }

    public void openAccountForCustomer(Customer customer) {
        navigateToScreen("ACCOUNT", "Mở tài khoản cho khách hàng");
        accountPanel.openAccountForCustomer(customer);
    }

    public void createCustomerForAccount() {
        navigateToScreen("CUSTOMER", "Tạo khách hàng để mở tài khoản");
        customerPanel.createCustomerForAccount();
    }

    private void navigateToScreen(String cardKey, String title) {
        for (SidebarNavButton b : navButtons) {
            if (cardKey.equals(b.getClientProperty("cardKey"))) {
                switchScreen(cardKey, title, b);
                return;
            }
        }
        switchScreen(cardKey, title, null);
    }

    public void refreshAllViews() {
        dashboardPanel.refreshData();
        customerPanel.refreshTable();
        accountPanel.refreshTable();
        transactionPanel.refreshAccountList();
        historyPanel.refreshTable();
        staffPanel.refreshTable();
    }
}
