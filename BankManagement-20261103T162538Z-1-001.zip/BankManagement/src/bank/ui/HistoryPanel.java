package bank.ui;

import bank.config.ApplicationContext;
import bank.dao.UserDAO;
import bank.model.BankAccount;
import bank.model.Transaction;
import bank.model.TransactionEntry;
import bank.model.User;
import bank.service.AuthService;
import bank.service.AccountService;
import bank.service.TransactionService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernTextField;
import bank.ui.components.AutoCompleteTextField;
import bank.ui.components.AutoCompleteTextField.Suggestion;
import bank.ui.components.DatePickerField;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import bank.util.MoneyUtils;
import bank.util.TransactionCsvExporter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class HistoryPanel extends JPanel {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);
    private final MainFrame parent;
    private final User currentUser;
    private final TransactionService transactionService = ApplicationContext.getBean(TransactionService.class);
    private final AutoCompleteTextField txtTxCode = new AutoCompleteTextField("", 9);
    private final AutoCompleteTextField txtAccNum = new AutoCompleteTextField("", 11);
    private final ModernTextField txtFromDate = new ModernTextField("", 10);
    private final ModernTextField txtToDate = new ModernTextField("", 10);
    private final AutoCompleteTextField txtCreatedBy = new AutoCompleteTextField("", 12);
    private final JComboBox<String> cbType = new JComboBox<>(new String[]{"ALL", "DEPOSIT", "WITHDRAW", "TRANSFER", "REVERSAL"});
    private final JComboBox<String> cbStatus = new JComboBox<>(new String[]{"ALL", "SUCCESS", "REVERSED"});
    private final ModernButton btnDetail = UIHelper.createButton("Xem bút toán", UIHelper.SUCCESS);
    private final ModernButton btnReverse = UIHelper.createButton("Hoàn tác giao dịch", UIHelper.WARNING);
    private final ModernButton btnExport = UIHelper.createButton("Xuất CSV", UIHelper.PRIMARY);
    private final JLabel lblResult = new JLabel(" ");
    private final DefaultTableModel tableModel;
    private final JTable table;
    private List<Transaction> currentList = new ArrayList<>();
    private boolean filtersDirty;
    private boolean settingFilters;
    private final Map<String, String> accountSearchLabels = new LinkedHashMap<>();
    private final Map<String, String> creatorSearchLabels = new LinkedHashMap<>();
    private final Timer autoFilterTimer = new Timer(300, e -> applyFilters(false));

    public HistoryPanel(MainFrame parent, User currentUser) {
        this.parent = parent;
        this.currentUser = currentUser;
        autoFilterTimer.setRepeats(false);
        setLayout(new BorderLayout(0, 16));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));
        RoundedCard filterBar = new RoundedCard(new BorderLayout(0, 6));
        filterBar.setBorder(new EmptyBorder(10, 14, 10, 14));
        JPanel filterRows = new JPanel();
        filterRows.setOpaque(false);
        filterRows.setLayout(new BoxLayout(filterRows, BoxLayout.Y_AXIS));
        JPanel primaryFilters = new JPanel(new GridLayout(1, 4, 12, 0));
        primaryFilters.setOpaque(false);
        primaryFilters.add(UIHelper.createFieldGroup("Mã giao dịch", txtTxCode));
        primaryFilters.add(UIHelper.createFieldGroup("Tài khoản / tên khách", suggestionPicker(txtAccNum)));
        primaryFilters.add(UIHelper.createFieldGroup("Loại giao dịch", cbType));
        primaryFilters.add(UIHelper.createFieldGroup("Trạng thái", cbStatus));
        UiLabels.localizeCombo(cbType);
        UiLabels.localizeCombo(cbStatus);
        JPanel dateFilters = new JPanel(new GridLayout(1, 3, 12, 0));
        dateFilters.setOpaque(false);
        dateFilters.add(UIHelper.createFieldGroup("Từ ngày (dd/MM/yyyy)", new DatePickerField(txtFromDate)));
        dateFilters.add(UIHelper.createFieldGroup("Đến ngày (dd/MM/yyyy)", new DatePickerField(txtToDate)));
        dateFilters.add(UIHelper.createFieldGroup("Người tạo", suggestionPicker(txtCreatedBy)));
        txtFromDate.setToolTipText("Ngày bắt đầu, ví dụ 01/10/2026. Có tính cả ngày này.");
        txtToDate.setToolTipText("Ngày kết thúc, ví dụ 31/10/2026. Có tính cả ngày này.");
        txtTxCode.setToolTipText("Gõ một phần mã rồi chọn gợi ý; nhấn Enter để tìm ngay.");
        txtAccNum.setToolTipText("Gõ số hoặc tên chủ tài khoản rồi chọn tài khoản gợi ý.");
        txtCreatedBy.setToolTipText("Gõ tên đăng nhập/tên nhân viên rồi chọn gợi ý, hoặc bấm ▾.");
        JPanel actions = filterRow();
        ModernButton btnFilter = UIHelper.createButton("Lọc", UIHelper.PRIMARY);
        ModernButton btnReset = UIHelper.createOutlineButton("Xóa bộ lọc");
        ModernButton btnToday = UIHelper.createOutlineButton("Hôm nay");
        ModernButton btnSevenDays = UIHelper.createOutlineButton("7 ngày gần đây");
        actions.add(btnFilter);
        actions.add(btnToday);
        actions.add(btnSevenDays);
        actions.add(btnReset);
        JPanel recordActions = filterRow();
        recordActions.add(btnExport);
        recordActions.add(btnDetail);
        recordActions.add(btnReverse);
        btnReverse.setVisible("ADMIN".equalsIgnoreCase(currentUser.getRole()));
        btnReverse.setToolTipText("Chỉ quản trị viên được hoàn tác giao dịch thành công.");
        filterRows.add(primaryFilters);
        filterRows.add(javax.swing.Box.createVerticalStrut(8));
        filterRows.add(dateFilters);
        filterRows.add(javax.swing.Box.createVerticalStrut(5));
        filterRows.add(actions);
        filterRows.add(recordActions);
        filterBar.add(filterRows, BorderLayout.CENTER);
        lblResult.setFont(UIHelper.FONT_SMALL);
        lblResult.setForeground(UIHelper.TEXT_MUTED);
        filterBar.add(lblResult, BorderLayout.SOUTH);
        RoundedCard tableCard = new RoundedCard(new BorderLayout());
        tableCard.setBorder(new EmptyBorder(10, 10, 10, 10));
        String[] cols = {"Mã giao dịch", "Loại giao dịch", "Tài khoản nguồn", "Tài khoản nhận", "Số tiền", "Nội dung", "Trạng thái", "Người tạo", "Thời gian"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UIHelper.setupModernTable(table);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);
        DocumentListener dirtyListener = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { markFiltersDirty(); }
            @Override public void removeUpdate(DocumentEvent e) { markFiltersDirty(); }
            @Override public void changedUpdate(DocumentEvent e) { markFiltersDirty(); }
        };
        for (ModernTextField field : new ModernTextField[]{txtTxCode, txtAccNum, txtFromDate, txtToDate, txtCreatedBy}) {
            field.getDocument().addDocumentListener(dirtyListener);
            field.addActionListener(e -> applyFilters(true));
        }
        btnFilter.addActionListener(e -> applyFilters(true));
        cbType.addActionListener(e -> { if (!settingFilters) applyFilters(false); });
        cbStatus.addActionListener(e -> { if (!settingFilters) applyFilters(false); });
        btnReset.addActionListener(e -> changeFilters(() -> {
            txtTxCode.setText("");
            txtAccNum.setText("");
            txtFromDate.setText("");
            txtToDate.setText("");
            txtCreatedBy.setText("");
            cbType.setSelectedIndex(0);
            cbStatus.setSelectedIndex(0);
        }));
        btnToday.addActionListener(e -> setDateRange(LocalDate.now(), LocalDate.now()));
        btnSevenDays.addActionListener(e -> setDateRange(LocalDate.now().minusDays(6), LocalDate.now()));
        btnExport.addActionListener(e -> exportCsv());
        btnDetail.addActionListener(e -> showEntriesModal());
        btnReverse.addActionListener(e -> reverseSelectedTransaction());
        table.getSelectionModel().addListSelectionListener(e -> updateActionButtons());
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() >= 0) showEntriesModal();
            }
        });
        add(filterBar, BorderLayout.NORTH);
        add(tableCard, BorderLayout.CENTER);
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK), "focusQuickSearch");
        getActionMap().put("focusQuickSearch", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) {
                if (isShowing()) { txtTxCode.requestFocusInWindow(); txtTxCode.selectAll(); }
            }
        });
        refreshTable();
    }

    private JPanel suggestionPicker(AutoCompleteTextField input) {
        JPanel picker = new JPanel(new BorderLayout(4, 0));
        picker.setOpaque(false);
        ModernButton choose = UIHelper.createOutlineButton("▾");
        choose.setPreferredSize(new java.awt.Dimension(32, 36));
        choose.setBorder(new EmptyBorder(0, 0, 0, 0));
        choose.setMargin(new java.awt.Insets(0, 0, 0, 0));
        choose.setToolTipText("Chọn từ danh sách gợi ý");
        choose.setFocusable(false);
        choose.addActionListener(e -> input.showSuggestions());
        picker.add(input, BorderLayout.CENTER);
        picker.add(choose, BorderLayout.EAST);
        return picker;
    }

    private void changeFilters(Runnable change) {
        autoFilterTimer.stop();
        settingFilters = true;
        try { change.run(); }
        finally { settingFilters = false; }
        applyFilters(false);
    }

    private JPanel filterRow() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 4));
        panel.setOpaque(false);
        return panel;
    }

    private void setDateRange(LocalDate from, LocalDate to) {
        changeFilters(() -> {
            txtFromDate.setText(DATE.format(from));
            txtToDate.setText(DATE.format(to));
        });
    }

    private void markFiltersDirty() {
        if (settingFilters) return;
        filtersDirty = true;
        btnExport.setEnabled(false);
        updateActionButtons();
        lblResult.setText("Đang tìm… Gõ một phần hoặc chọn gợi ý; Enter để tìm ngay.");
        autoFilterTimer.restart();
    }

    public static LocalDate parseOptionalDate(String value, String label) {
        if (value == null || value.isBlank()) return null;
        try {
            return LocalDate.parse(value.trim(), DATE);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException(label + " không hợp lệ. Nhập theo dd/MM/yyyy, ví dụ 31/10/2026.");
        }
    }

    private boolean applyFilters(boolean showError) {
        autoFilterTimer.stop();
        try {
            LocalDate from = parseOptionalDate(txtFromDate.getText(), "Ngày bắt đầu");
            LocalDate to = parseOptionalDate(txtToDate.getText(), "Ngày kết thúc");
            List<Transaction> candidates = transactionService.searchHistory(txtTxCode.getText(), null,
                    (String) cbType.getSelectedItem(), (String) cbStatus.getSelectedItem(), from, to, null);
            currentList = new ArrayList<>();
            for (Transaction transaction : candidates) {
                boolean accountMatches = matchesSearch(txtAccNum.getText(), transaction.getSourceAccountNumber(),
                        accountSearchLabels.get(transaction.getSourceAccountNumber()))
                        || matchesSearch(txtAccNum.getText(), transaction.getDestinationAccountNumber(),
                                accountSearchLabels.get(transaction.getDestinationAccountNumber()));
                boolean creatorMatches = matchesSearch(txtCreatedBy.getText(), transaction.getCreatedByUsername(),
                        creatorSearchLabels.get(transaction.getCreatedByUsername()));
                if (accountMatches && creatorMatches) currentList.add(transaction);
            }
            filtersDirty = false;
            fillTable();
            lblResult.setText(currentList.size() + " giao dịch · Tự lọc khi ngừng gõ · Ctrl+F đến ô tìm mã · Để trống ngày để xem tất cả.");
            btnExport.setEnabled(!currentList.isEmpty());
            return true;
        } catch (IllegalArgumentException ex) {
            currentList = new ArrayList<>();
            tableModel.setRowCount(0);
            filtersDirty = true;
            btnExport.setEnabled(false);
            lblResult.setText(ex.getMessage());
            updateActionButtons();
            if (showError) JOptionPane.showMessageDialog(this, ex.getMessage(), "Kiểm tra bộ lọc", JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }

    public void refreshTable() {
        refreshSuggestions();
        applyFilters(false);
    }

    private void refreshSuggestions() {
        List<Transaction> all = transactionService.searchHistory(null, null, "ALL", "ALL");
        Map<String, Suggestion> codes = new LinkedHashMap<>();
        Map<String, Suggestion> accounts = new LinkedHashMap<>();
        Map<String, Suggestion> creators = new LinkedHashMap<>();
        AccountService accountService = ApplicationContext.getBean(AccountService.class);
        if (accountService != null) {
            for (BankAccount account : accountService.getAllAccounts()) {
                accounts.put(account.getAccountNumber(), new Suggestion(account.getAccountNumber(),
                        account.getAccountNumber() + " — " + account.getCustomerName()));
            }
        }
        UserDAO userDAO = ApplicationContext.getBean(UserDAO.class);
        if (userDAO != null) {
            for (User user : userDAO.findAll()) {
                creators.put(user.getUsername(), new Suggestion(user.getUsername(),
                        user.getUsername() + " — " + user.getFullName()));
            }
        }
        for (Transaction tx : all) {
            codes.put(tx.getTransactionCode(), new Suggestion(tx.getTransactionCode(), tx.getTransactionCode()
                    + " — " + UiLabels.text(tx.getTransactionType()) + " — " + MoneyUtils.formatVND(tx.getAmount())));
            addAccountSuggestion(accounts, tx.getSourceAccountNumber());
            addAccountSuggestion(accounts, tx.getDestinationAccountNumber());
            String creator = tx.getCreatedByUsername();
            if (creator != null && !creator.isBlank()) creators.putIfAbsent(creator, new Suggestion(creator, creator));
        }
        txtTxCode.setSuggestions(new ArrayList<>(codes.values()));
        txtAccNum.setSuggestions(new ArrayList<>(accounts.values()));
        txtCreatedBy.setSuggestions(new ArrayList<>(creators.values()));
        accountSearchLabels.clear();
        accounts.forEach((value, suggestion) -> accountSearchLabels.put(value, suggestion.getLabel()));
        creatorSearchLabels.clear();
        creators.forEach((value, suggestion) -> creatorSearchLabels.put(value, suggestion.getLabel()));
    }

    private boolean matchesSearch(String query, String value, String label) {
        String needle = normalizeSearch(query);
        return needle.isEmpty() || normalizeSearch(value).contains(needle) || normalizeSearch(label).contains(needle);
    }

    private String normalizeSearch(String value) {
        return value == null ? "" : java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").replace('đ', 'd').replace('Đ', 'D')
                .toLowerCase(java.util.Locale.ROOT).trim().replaceAll("\\s+", " ");
    }

    private void addAccountSuggestion(Map<String, Suggestion> target, String number) {
        if (number != null && !number.isBlank() && !"-".equals(number)) {
            target.putIfAbsent(number, new Suggestion(number, number));
        }
    }

    @Override public void removeNotify() {
        autoFilterTimer.stop();
        super.removeNotify();
    }

    private void fillTable() {
        tableModel.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        for (Transaction t : currentList) {
            tableModel.addRow(new Object[]{t.getTransactionCode(), t.getTransactionType(),
                    t.getSourceAccountNumber(), t.getDestinationAccountNumber(), MoneyUtils.formatVND(t.getAmount()),
                    t.getDescription(), t.getStatus(), t.getCreatedByUsername(),
                    t.getCreatedAt() == null ? "" : t.getCreatedAt().format(fmt)});
        }
        updateActionButtons();
    }

    private Transaction selectedTransaction() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) return null;
        int modelRow = table.convertRowIndexToModel(viewRow);
        return modelRow < currentList.size() ? currentList.get(modelRow) : null;
    }

    private void updateActionButtons() {
        Transaction selected = selectedTransaction();
        btnDetail.setEnabled(!filtersDirty && selected != null);
        User authenticated = AuthService.getCurrentUser();
        boolean admin = authenticated != null && authenticated.getId() == currentUser.getId()
                && "ADMIN".equalsIgnoreCase(authenticated.getRole()) && "ACTIVE".equalsIgnoreCase(authenticated.getStatus());
        btnReverse.setEnabled(!filtersDirty && admin && selected != null && "SUCCESS".equalsIgnoreCase(selected.getStatus())
                && !"REVERSAL".equalsIgnoreCase(selected.getTransactionType()));
    }

    private void exportCsv() {
        if (filtersDirty) {
            JOptionPane.showMessageDialog(this, "Đợi kết quả tìm kiếm cập nhật hoặc nhấn Enter trước khi xuất CSV.", "Đang cập nhật bộ lọc", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (currentList.isEmpty()) return;
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Xuất lịch sử giao dịch đã lọc");
        chooser.setFileFilter(new FileNameExtensionFilter("Tệp CSV (*.csv)", "csv"));
        chooser.setSelectedFile(new File("lich_su_giao_dich_" + LocalDate.now() + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File selectedFile = chooser.getSelectedFile();
        if (!selectedFile.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".csv")) {
            selectedFile = new File(selectedFile.getParentFile(), selectedFile.getName() + ".csv");
        }
        if (selectedFile.exists() && JOptionPane.showConfirmDialog(this,
                "Tệp đã tồn tại. Bạn muốn thay thế tệp này?\n" + selectedFile.getAbsolutePath(),
                "Xác nhận thay thế", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) return;
        List<Transaction> visibleOrder = new ArrayList<>();
        for (int row = 0; row < table.getRowCount(); row++) visibleOrder.add(currentList.get(table.convertRowIndexToModel(row)));
        Path destination = selectedFile.toPath();
        try {
            TransactionCsvExporter.write(destination, visibleOrder);
            JOptionPane.showMessageDialog(this, "Đã xuất " + visibleOrder.size() + " giao dịch.\n" + destination.toAbsolutePath(),
                    "Xuất CSV thành công", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không thể lưu CSV: " + ex.getMessage(), "Không thể xuất CSV", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void reverseSelectedTransaction() {
        Transaction tx = selectedTransaction();
        if (tx == null) return;
        try {
            AuthService.requireAdmin(currentUser);
            JTextArea reasonField = new JTextArea(3, 30);
            reasonField.setLineWrap(true);
            reasonField.setWrapStyleWord(true);
            JPanel review = new JPanel(new BorderLayout(0, 12));
            String summary = "Mã giao dịch: " + tx.getTransactionCode() + "\nLoại: " + UiLabels.text(tx.getTransactionType())
                    + "\nTài khoản nguồn: " + tx.getSourceAccountNumber() + "\nTài khoản nhận: " + tx.getDestinationAccountNumber()
                    + "\nSố tiền: " + MoneyUtils.formatVND(tx.getAmount())
                    + "\n\nHoàn tác sẽ tạo giao dịch đảo, giữ lại lịch sử gốc.\nLý do hoàn tác (bắt buộc):";
            JTextArea info = new JTextArea(summary);
            info.setEditable(false);
            info.setOpaque(false);
            info.setFont(UIHelper.FONT_NORMAL);
            review.add(info, BorderLayout.NORTH);
            review.add(new JScrollPane(reasonField), BorderLayout.CENTER);
            int choice = JOptionPane.showOptionDialog(this, review, "Kiểm tra trước khi hoàn tác",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,
                    new Object[]{"Quay lại", "Xác nhận hoàn tác"}, "Quay lại");
            if (choice != 1) return;
            Transaction rev = transactionService.reverseTransaction(tx, reasonField.getText(), currentUser);
            parent.refreshAllViews();
            JOptionPane.showMessageDialog(this, "Đã hoàn tác thành công.\nMã giao dịch đảo: " + rev.getTransactionCode()
                    + "\nSố tiền: " + MoneyUtils.formatVND(rev.getAmount()), "Hoàn tác thành công", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể hoàn tác", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showEntriesModal() {
        Transaction tx = selectedTransaction();
        if (tx == null) return;
        List<TransactionEntry> entries = transactionService.getEntriesForTransaction(tx.getId());
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Bút toán giao dịch " + tx.getTransactionCode(), true);
        dialog.setSize(720, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));
        String[] cols = {"Mã bút toán", "Số tài khoản", "Loại bút toán", "Số tiền phát sinh", "Số dư sau giao dịch"};
        DefaultTableModel entryModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        for (TransactionEntry entry : entries) entryModel.addRow(new Object[]{"#" + entry.getId(), entry.getAccountNumber(),
                entry.getEntryType(), MoneyUtils.formatVND(entry.getAmount()), MoneyUtils.formatVND(entry.getBalanceAfter())});
        JTable entryTable = new JTable(entryModel);
        UIHelper.setupModernTable(entryTable);
        JPanel topInfo = new JPanel(new GridLayout(2, 2, 10, 4));
        topInfo.setBackground(Color.WHITE);
        topInfo.setBorder(new EmptyBorder(14, 18, 10, 18));
        topInfo.add(new JLabel("Mã giao dịch: " + tx.getTransactionCode() + " · " + UiLabels.text(tx.getStatus())));
        topInfo.add(new JLabel("Loại: " + UiLabels.text(tx.getTransactionType())));
        topInfo.add(new JLabel("Số tiền: " + MoneyUtils.formatVND(tx.getAmount())));
        topInfo.add(new JLabel("Nội dung: " + tx.getDescription()));
        dialog.add(topInfo, BorderLayout.NORTH);
        dialog.add(new JScrollPane(entryTable), BorderLayout.CENTER);
        dialog.setVisible(true);
    }
}
