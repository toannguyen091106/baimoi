package bank.ui.components;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.IllegalComponentStateException;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

/** Gợi ý chỉ điền giá trị khi người dùng chọn, không sửa nội dung đang gõ. */
public class AutoCompleteTextField extends ModernTextField {
    private static final int MAX_SUGGESTIONS = 8;
    private static final Pattern ACCENTS = Pattern.compile("\\p{M}+");
    private final DefaultListModel<Suggestion> model = new DefaultListModel<>();
    private final JList<Suggestion> list = new JList<>(model);
    private final JPopupMenu popup = new JPopupMenu();
    private final JScrollPane scrollPane = new JScrollPane(list);
    private volatile List<Suggestion> suggestions = Collections.emptyList();
    private boolean popupDismissed;
    private boolean committing;
    private int updateVersion;

    public AutoCompleteTextField(String text, int columns) {
        super(text, columns);
        list.setFont(UIHelper.FONT_NORMAL);
        list.setFixedCellHeight(30);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectionBackground(UIHelper.PRIMARY);
        list.setSelectionForeground(java.awt.Color.WHITE);
        list.setFocusable(false);
        list.setRequestFocusEnabled(false);
        list.setCellRenderer(new DefaultListCellRenderer() {
            { putClientProperty("html.disable", Boolean.TRUE); }

            @Override
            public Component getListCellRendererComponent(JList<?> owner, Object value,
                    int index, boolean selected, boolean focused) {
                JLabel label = (JLabel) super.getListCellRendererComponent(owner, value,
                        index, selected, focused);
                label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                return label;
            }
        });
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setFocusable(false);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        popup.setLayout(new BorderLayout());
        popup.setFocusable(false);
        popup.setBorder(BorderFactory.createLineBorder(UIHelper.BORDER_COLOR));
        popup.addPopupMenuListener(new PopupMenuListener() {
            @Override public void popupMenuWillBecomeVisible(PopupMenuEvent event) {}
            @Override public void popupMenuWillBecomeInvisible(PopupMenuEvent event) {
                popupDismissed = true;
                ++updateVersion;
            }
            @Override public void popupMenuCanceled(PopupMenuEvent event) {
                popupDismissed = true;
                ++updateVersion;
            }
        });
        popup.add(scrollPane, BorderLayout.CENTER);
        JLabel hint = new JLabel("↑ ↓ chọn · Enter hoặc Tab để điền");
        hint.setFont(UIHelper.FONT_SMALL);
        hint.setForeground(UIHelper.TEXT_MUTED);
        hint.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        popup.add(hint, BorderLayout.SOUTH);

        getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent event) { textChanged(); }
            @Override public void removeUpdate(DocumentEvent event) { textChanged(); }
            @Override public void changedUpdate(DocumentEvent event) { textChanged(); }
        });
        addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent event) {
                if (!getText().isBlank()) {
                    popupDismissed = false;
                    schedulePopup();
                }
            }

            @Override public void focusLost(FocusEvent event) {
                dismissPopup();
            }
        });
        list.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent event) {
                if (!SwingUtilities.isLeftMouseButton(event)) return;
                int index = list.locationToIndex(event.getPoint());
                Rectangle bounds = index < 0 ? null : list.getCellBounds(index, index);
                if (bounds != null && bounds.contains(event.getPoint())) {
                    list.setSelectedIndex(index);
                    commitSelectedSuggestion();
                    event.consume();
                }
            }
        });
        installKeys();
    }

    /** Thay nguồn gợi ý nhưng giữ nguyên nội dung người dùng và vị trí con trỏ. */
    public void setSuggestions(List<Suggestion> values) {
        Map<String, Suggestion> unique = new LinkedHashMap<>();
        if (values != null) {
            for (Suggestion suggestion : values) {
                if (suggestion != null && !suggestion.getValue().isBlank()) {
                    unique.putIfAbsent(suggestion.getValue(), suggestion);
                }
            }
        }
        suggestions = Collections.unmodifiableList(new ArrayList<>(unique.values()));
        if (isFocusOwner() && (!getText().isBlank() || popup.isVisible())) schedulePopup();
    }

    public List<Suggestion> getMatchingSuggestions(String query) {
        String needle = normalize(query == null ? "" : query.trim());
        List<Suggestion> matches = new ArrayList<>();
        for (Suggestion suggestion : suggestions) {
            if (needle.isEmpty() || normalize(suggestion.getValue()).contains(needle)
                    || normalize(suggestion.getLabel()).contains(needle)) {
                matches.add(suggestion);
                if (matches.size() == MAX_SUGGESTIONS) break;
            }
        }
        return Collections.unmodifiableList(matches);
    }

    /** Dùng cho nút chọn nhanh; nội dung trống sẽ hiện các giá trị sẵn có. */
    public void showSuggestions() {
        if (!isEnabled() || !isEditable()) return;
        popupDismissed = false;
        requestFocusInWindow();
        schedulePopup();
    }

    private static String normalize(String text) {
        String decomposed = Normalizer.normalize(text, Normalizer.Form.NFD);
        return ACCENTS.matcher(decomposed).replaceAll("")
                .replace('đ', 'd').replace('Đ', 'D').toLowerCase(Locale.ROOT);
    }

    private void textChanged() {
        if (committing) return;
        if (getText().isBlank()) {
            dismissPopup();
            return;
        }
        popupDismissed = false;
        schedulePopup();
    }

    private void schedulePopup() {
        int version = ++updateVersion;
        SwingUtilities.invokeLater(() -> {
            if (version == updateVersion && !committing) refreshPopup();
        });
    }

    private void refreshPopup() {
        if (popupDismissed || !isEnabled() || !isEditable() || !isFocusOwner() || !isShowing()) {
            popup.setVisible(false);
            return;
        }
        List<Suggestion> matches = getMatchingSuggestions(getText());
        if (matches.isEmpty()) {
            popup.setVisible(false);
            return;
        }
        Suggestion previous = list.getSelectedValue();
        model.clear();
        for (Suggestion match : matches) model.addElement(match);
        int selected = previous == null ? -1 : matches.indexOf(previous);
        list.setSelectedIndex(selected >= 0 ? selected : 0);
        int width = Math.max(getWidth(), 290);
        for (Suggestion match : matches) {
            width = Math.max(width, list.getFontMetrics(list.getFont()).stringWidth(match.getLabel()) + 30);
        }
        width = Math.min(width, 520);
        scrollPane.setPreferredSize(new Dimension(width, matches.size() * list.getFixedCellHeight()));
        int hintHeight = popup.getComponent(1).getPreferredSize().height;
        popup.setPopupSize(new Dimension(width + 2,
                matches.size() * list.getFixedCellHeight() + hintHeight + 2));
        if (!popup.isVisible()) {
            try { popup.show(this, 0, getHeight()); }
            catch (IllegalComponentStateException ignored) { popup.setVisible(false); }
        }
        list.ensureIndexIsVisible(list.getSelectedIndex());
    }

    private void moveSelection(int direction) {
        boolean visible = popup.isVisible();
        if (!visible) {
            popupDismissed = false;
            refreshPopup();
            if (popup.isVisible()) list.setSelectedIndex(direction > 0 ? 0 : model.size() - 1);
            return;
        }
        int selected = list.getSelectedIndex();
        int next = selected < 0 ? (direction > 0 ? 0 : model.size() - 1)
                : Math.floorMod(selected + direction, model.size());
        list.setSelectedIndex(next);
        list.ensureIndexIsVisible(next);
    }

    private void commitSelectedSuggestion() {
        Suggestion selected = list.getSelectedValue();
        if (selected == null) return;
        committing = true;
        try {
            dismissPopup();
            setText(selected.getValue());
            setCaretPosition(getText().length());
        } finally {
            committing = false;
        }
    }

    private void dismissPopup() {
        popupDismissed = true;
        ++updateVersion;
        popup.setVisible(false);
    }

    private void installKeys() {
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "autocomplete-next", () -> moveSelection(1));
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "autocomplete-previous", () -> moveSelection(-1));
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "autocomplete-enter", () -> {
            if (popup.isVisible()) commitSelectedSuggestion();
            postActionEvent();
        });
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "autocomplete-dismiss", this::dismissPopup);
        setFocusTraversalKeysEnabled(false);
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0), "autocomplete-tab", () -> {
            if (popup.isVisible()) commitSelectedSuggestion();
            transferFocus();
        });
        bind(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, KeyEvent.SHIFT_DOWN_MASK),
                "autocomplete-back-tab", () -> {
                    dismissPopup();
                    transferFocusBackward();
                });
    }

    private void bind(KeyStroke key, String name, Runnable action) {
        getInputMap(WHEN_FOCUSED).put(key, name);
        getActionMap().put(name, new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) { action.run(); }
        });
    }

    public static final class Suggestion {
        private final String value;
        private final String label;

        public Suggestion(String value, String label) {
            this.value = Objects.requireNonNull(value, "value");
            this.label = label == null || label.isBlank() ? value : label;
        }

        public String getValue() { return value; }
        public String getLabel() { return label; }
        @Override public String toString() { return label; }
        @Override public boolean equals(Object other) {
            if (!(other instanceof Suggestion)) return false;
            Suggestion that = (Suggestion) other;
            return value.equals(that.value) && label.equals(that.label);
        }
        @Override public int hashCode() { return Objects.hash(value, label); }
    }
}
