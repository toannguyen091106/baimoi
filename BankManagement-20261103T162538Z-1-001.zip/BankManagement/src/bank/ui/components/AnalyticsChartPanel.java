package bank.ui.components;

import bank.util.MoneyUtils;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.math.BigDecimal;
import javax.swing.JPanel;

public class AnalyticsChartPanel extends JPanel {
    private BigDecimal deposit = BigDecimal.ZERO;
    private BigDecimal withdraw = BigDecimal.ZERO;
    private BigDecimal transfer = BigDecimal.ZERO;

    public AnalyticsChartPanel() {
        setOpaque(false);
    }

    public void updateValues(BigDecimal dep, BigDecimal wit, BigDecimal tra) {
        this.deposit = dep;
        this.withdraw = wit;
        this.transfer = tra;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        int bottomY = h - 50;
        int topY = 48;
        int chartHeight = Math.max(60, bottomY - topY);

        double dVal = deposit.doubleValue();
        double wVal = withdraw.doubleValue();
        double tVal = transfer.doubleValue();
        double maxVal = Math.max(1.0, Math.max(dVal, Math.max(wVal, tVal)));
        double sumVal = Math.max(1.0, dVal + wVal + tVal);

        g2.setColor(new Color(226, 232, 240));
        for (int i = 0; i <= 4; i++) {
            int y = bottomY - (chartHeight * i / 4);
            g2.drawLine(24, y, w - 24, y);
        }

        String[] labels = {"NỘP TIỀN", "RÚT TIỀN", "CHUYỂN KHOẢN"};
        BigDecimal[] amounts = {deposit, withdraw, transfer};
        Color[] colors = {UIHelper.SUCCESS, UIHelper.DANGER, UIHelper.WARNING};

        int colWidth = Math.min(85, Math.max(50, (w - 140) / 3));
        int spacing = (w - (colWidth * 3)) / 4;

        for (int i = 0; i < 3; i++) {
            double val = amounts[i].doubleValue();
            int barH = (int) ((val / maxVal) * (chartHeight - 20));
            barH = Math.max(8, barH);
            int x = spacing + i * (colWidth + spacing);
            int y = bottomY - barH;

            g2.setColor(colors[i]);
            g2.fillRoundRect(x, y, colWidth, barH, 12, 12);

            int percent = (int) Math.round((val / sumVal) * 100);
            String pctText = "(" + percent + "%)";
            String amtText = MoneyUtils.formatVND(amounts[i]);

            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();

            g2.setColor(UIHelper.TEXT_MUTED);
            int pctX = x + (colWidth - fm.stringWidth(pctText)) / 2;
            g2.drawString(pctText, Math.max(6, pctX), y - 22);

            g2.setColor(UIHelper.TEXT_MAIN);
            int amtX = x + (colWidth - fm.stringWidth(amtText)) / 2;
            g2.drawString(amtText, Math.max(6, amtX), y - 7);

            g2.setFont(UIHelper.FONT_BOLD);
            g2.setColor(UIHelper.TEXT_MUTED);
            FontMetrics fm2 = g2.getFontMetrics();
            int lblX = x + (colWidth - fm2.stringWidth(labels[i])) / 2;
            g2.drawString(labels[i], Math.max(6, lblX), bottomY + 24);
        }

        g2.dispose();
    }
}
