package bank.ui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

public final class UIHelper {
    public static final Color SIDEBAR_BG = new Color(15, 23, 42);
    public static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    public static final Color SIDEBAR_ACTIVE = new Color(37, 99, 235);
    public static final Color APP_BG = new Color(241, 245, 249);
    public static final Color CARD_BG = Color.WHITE;
    public static final Color BORDER_COLOR = new Color(226, 232, 240);

    public static final Color PRIMARY = new Color(37, 99, 235);
    public static final Color NAVY_DARK = new Color(15, 23, 42);
    public static final Color SUCCESS = new Color(16, 185, 129);
    public static final Color WARNING = new Color(245, 158, 11);
    public static final Color DANGER = new Color(239, 68, 68);
    public static final Color PURPLE = new Color(124, 58, 237);
    public static final Color TEXT_MAIN = new Color(15, 23, 42);
    public static final Color TEXT_MUTED = new Color(100, 116, 139);

    public static final Font FONT_HERO = new Font("SansSerif", Font.BOLD, 22);
    public static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 17);
    public static final Font FONT_SUBTITLE = new Font("SansSerif", Font.BOLD, 14);
    public static final Font FONT_BOLD = new Font("SansSerif", Font.BOLD, 13);
    public static final Font FONT_NORMAL = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font FONT_SMALL = new Font("SansSerif", Font.PLAIN, 12);

    public static ModernButton createButton(String text, Color bgColor) {
        return new ModernButton(text, bgColor, Color.WHITE);
    }

    public static ModernButton createOutlineButton(String text) {
        return new ModernButton(text, new Color(241, 245, 249), TEXT_MAIN);
    }

    public static JPanel createFieldGroup(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 5));
        p.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_BOLD);
        lbl.setForeground(TEXT_MAIN);
        field.setPreferredSize(new Dimension(200, 36));
        p.add(lbl, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        return p;
    }

    public static void setupModernTable(JTable table) {
        table.setFont(FONT_NORMAL);
        table.setRowHeight(40);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(226, 232, 240));
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_MAIN);
        table.setAutoCreateRowSorter(true);
        table.setIntercellSpacing(new Dimension(0, 0));

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_BOLD);
        header.setPreferredSize(new Dimension(0, 42));
        header.setReorderingAllowed(false);
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                lbl.setBackground(new Color(248, 250, 252));
                lbl.setForeground(new Color(71, 85, 105));
                lbl.setFont(FONT_BOLD);
                String colName = t.getColumnName(c).toLowerCase();
                if (colName.contains("số dư") || colName.contains("số tiền") || colName.contains("phát sinh")) {
                    lbl.setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    lbl.setHorizontalAlignment(SwingConstants.LEFT);
                }
                lbl.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 2, 0, BORDER_COLOR),
                        new EmptyBorder(0, 10, 0, 10)
                ));
                return lbl;
            }
        });

        DefaultTableCellRenderer baseRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, val, isSel, hasFocus, r, c);
                String text = val == null ? "" : val.toString();
                lbl.setToolTipText(text.isEmpty() ? null : text);
                if (!isSel) {
                    lbl.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                    lbl.setForeground(TEXT_MAIN);
                } else {
                    lbl.setBackground(new Color(219, 234, 254));
                    lbl.setForeground(PRIMARY);
                }
                if (text.endsWith("VND")) {
                    lbl.setHorizontalAlignment(SwingConstants.RIGHT);
                    lbl.setFont(FONT_BOLD);
                    if (!isSel) lbl.setForeground(new Color(15, 118, 110));
                } else {
                    lbl.setHorizontalAlignment(SwingConstants.LEFT);
                    lbl.setFont(FONT_NORMAL);
                }
                lbl.setBorder(new EmptyBorder(0, 10, 0, 10));
                return lbl;
            }
        };

        StatusBadgeRenderer badgeRenderer = new StatusBadgeRenderer();
        for (int i = 0; i < table.getColumnCount(); i++) {
            TableColumn column = table.getColumnModel().getColumn(i);
            String colName = table.getColumnName(i).toLowerCase();
            if (colName.contains("trạng thái") || colName.contains("loại gd") || colName.contains("loại giao dịch") || colName.contains("vai trò")
                    || colName.contains("bút toán") || colName.contains("trạng thái mới") || colName.contains("trạng thái cũ")) {
                column.setCellRenderer(badgeRenderer);
            } else {
                column.setCellRenderer(baseRenderer);
            }

            if (colName.equals("id") || colName.contains("mã kh") || colName.contains("loại tiền")) {
                column.setPreferredWidth(75);
                column.setMaxWidth(110);
            } else if (colName.contains("ngày sinh") || colName.contains("trạng thái") || colName.contains("vai trò") || colName.contains("loại gd") || colName.contains("loại giao dịch")) {
                column.setPreferredWidth(140);
                column.setMaxWidth(180);
            } else if (colName.contains("số điện thoại") || colName.contains("mã gd") || colName.contains("số tài khoản") || colName.contains("tk ")) {
                column.setPreferredWidth(120);
            } else if (colName.contains("họ và tên") || colName.contains("chủ tài khoản") || colName.contains("email")) {
                column.setPreferredWidth(185);
            } else if (colName.contains("địa chỉ") || colName.contains("diễn giải") || colName.contains("lý do")) {
                column.setPreferredWidth(210);
            } else if (colName.contains("số dư") || colName.contains("số tiền")) {
                column.setPreferredWidth(145);
            }
        }
    }
}
