package bank.ui.components;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

public class ModernPasswordField extends JPasswordField {
    private boolean focused = false;

    public ModernPasswordField(String text, int columns) {
        super(text, columns);
        initStyle();
    }

    private void initStyle() {
        setOpaque(false);
        setFont(UIHelper.FONT_NORMAL);
        setForeground(UIHelper.TEXT_MAIN);
        setBorder(new EmptyBorder(7, 12, 7, 12));
        setPreferredSize(new Dimension(180, 36));
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                focused = true;
                repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                focused = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
        g2.setColor(focused ? UIHelper.PRIMARY : new Color(203, 213, 225));
        g2.setStroke(new BasicStroke(focused ? 1.8f : 1.0f));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
        g2.dispose();
        super.paintComponent(g);
    }
}
