package bank.ui.components;

import java.awt.Component;
import java.util.Locale;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JList;

/** Nhãn hiển thị; mã nghiệp vụ trong dữ liệu vẫn giữ nguyên. */
public final class UiLabels {
    private UiLabels() {}

    public static String text(Object value) {
        if (value == null) return "";
        String raw = value.toString();
        switch (raw.trim().toUpperCase(Locale.ROOT)) {
            case "ALL": return "Tất cả";
            case "ACTIVE": return "Đang hoạt động";
            case "INACTIVE": return "Ngừng hoạt động";
            case "LOCKED": return "Đang khóa";
            case "CLOSED": return "Đã đóng";
            case "SUCCESS": return "Thành công";
            case "REVERSED": return "Đã hoàn tác";
            case "DEPOSIT": return "Nộp tiền";
            case "WITHDRAW": return "Rút tiền";
            case "TRANSFER": return "Chuyển khoản";
            case "REVERSAL": return "Giao dịch đảo";
            case "CREDIT": return "Ghi có";
            case "DEBIT": return "Ghi nợ";
            case "ADMIN": return "Quản trị viên";
            case "STAFF": return "Nhân viên";
            default: return raw;
        }
    }

    public static void localizeCombo(JComboBox<String> combo) {
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean selected, boolean focused) {
                return super.getListCellRendererComponent(list, text(value), index, selected, focused);
            }
        });
    }

    public static String html(Object value) {
        return value == null ? "" : value.toString().replace("&", "&amp;")
                .replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
