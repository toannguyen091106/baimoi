package bank.ui.components;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPanel;

public class RoundedCard extends JPanel {
    private final int radius;
    private Color accentTopColor = null;

    public RoundedCard(LayoutManager layout, int radius) {
        super(layout);
        this.radius = radius;
        setOpaque(false);
        setBackground(Color.WHITE);
    }

    public RoundedCard(LayoutManager layout) {
        this(layout, 16);
    }

    public void setAccentTopColor(Color color) {
        this.accentTopColor = color;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        g2.setColor(getBackground());
        g2.fill(new RoundRectangle2D.Double(0, 0, w - 1, h - 1, radius, radius));

        if (accentTopColor != null) {
            g2.setClip(new RoundRectangle2D.Double(0, 0, w - 1, h - 1, radius, radius));
            g2.setColor(accentTopColor);
            g2.fillRect(0, 0, w, 5);
            g2.setClip(null);
        }

        g2.setColor(UIHelper.BORDER_COLOR);
        g2.draw(new RoundRectangle2D.Double(0, 0, w - 1, h - 1, radius, radius));
        g2.dispose();
        super.paintComponent(g);
    }
}
