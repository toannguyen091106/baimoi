package bank.ui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeListener;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

/** Ô ngày cho phép nhập tay hoặc chọn lịch, dùng cùng định dạng với bộ lọc. */
public final class DatePickerField extends JPanel {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMMM uuuu", Locale.forLanguageTag("vi-VN"));
    private final ModernTextField input;
    private final JButton calendarButton = new JButton("▦");
    private final JPopupMenu popup = new JPopupMenu();
    private final JPanel days = new JPanel(new GridLayout(6, 7, 3, 3));
    private final JLabel monthTitle = new JLabel("", SwingConstants.CENTER);
    private final Map<LocalDate, JButton> dayButtons = new LinkedHashMap<>();
    private YearMonth shownMonth = YearMonth.now();
    private LocalDate focusedDate = LocalDate.now();
    private final PropertyChangeListener focusWatcher = event -> {
        Object owner = event.getNewValue();
        if (popup.isVisible() && owner instanceof Component) {
            Component component = (Component) owner;
            if (!SwingUtilities.isDescendingFrom(component, this)
                    && !SwingUtilities.isDescendingFrom(component, popup)) popup.setVisible(false);
        }
    };

    public DatePickerField(ModernTextField input) {
        super(new BorderLayout(4, 0));
        this.input = Objects.requireNonNull(input, "input");
        setOpaque(false);
        setPreferredSize(new Dimension(175, 36));
        setMinimumSize(new Dimension(145, 36));
        input.setMinimumSize(new Dimension(105, 36));
        calendarButton.setFont(UIHelper.FONT_TITLE);
        calendarButton.setForeground(UIHelper.PRIMARY);
        calendarButton.setBackground(new Color(241, 245, 249));
        calendarButton.setPreferredSize(new Dimension(32, 36));
        calendarButton.setBorder(BorderFactory.createEmptyBorder());
        calendarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
        calendarButton.setToolTipText("Chọn ngày (Alt+↓)");
        calendarButton.getAccessibleContext().setAccessibleName("Chọn ngày");
        calendarButton.addActionListener(event -> {
            if (popup.isVisible()) popup.setVisible(false);
            else showCalendar();
        });
        add(input, BorderLayout.CENTER);
        add(calendarButton, BorderLayout.EAST);
        buildPopup();
        input.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, KeyEvent.ALT_DOWN_MASK), "open-date-calendar");
        input.getActionMap().put("open-date-calendar", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) { showCalendar(); }
        });
        input.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "hide-date-calendar");
        input.getActionMap().put("hide-date-calendar", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) { popup.setVisible(false); }
        });
    }

    public ModernTextField getInput() { return input; }

    /** Trả về null khi để trống hoặc đang nhập dở; bộ lọc kiểm tra lỗi riêng. */
    public LocalDate getSelectedDate() {
        try { return LocalDate.parse(input.getText().trim(), DATE); }
        catch (DateTimeParseException exception) { return null; }
    }

    public void setSelectedDate(LocalDate date) {
        input.setText(date == null ? "" : DATE.format(date));
        input.setCaretPosition(input.getText().length());
        popup.setVisible(false);
        input.requestFocusInWindow();
    }

    private void buildPopup() {
        JPanel content = new JPanel(new BorderLayout(0, 8));
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel header = new JPanel(new BorderLayout(5, 0));
        header.setOpaque(false);
        JButton previous = smallButton("‹", "Tháng trước");
        JButton next = smallButton("›", "Tháng sau");
        previous.addActionListener(event -> moveMonth(-1));
        next.addActionListener(event -> moveMonth(1));
        monthTitle.setFont(UIHelper.FONT_BOLD);
        header.add(previous, BorderLayout.WEST);
        header.add(monthTitle, BorderLayout.CENTER);
        header.add(next, BorderLayout.EAST);
        JPanel grid = new JPanel(new BorderLayout(0, 5));
        grid.setOpaque(false);
        JPanel weekdays = new JPanel(new GridLayout(1, 7, 3, 0));
        weekdays.setOpaque(false);
        for (String name : new String[]{"T2", "T3", "T4", "T5", "T6", "T7", "CN"}) {
            JLabel label = new JLabel(name, SwingConstants.CENTER);
            label.setFont(UIHelper.FONT_SMALL);
            label.setForeground(UIHelper.TEXT_MUTED);
            weekdays.add(label);
        }
        days.setOpaque(false);
        grid.add(weekdays, BorderLayout.NORTH);
        grid.add(days, BorderLayout.CENTER);
        JPanel shortcuts = new JPanel(new GridLayout(1, 2, 8, 0));
        shortcuts.setOpaque(false);
        JButton today = smallButton("Hôm nay", "Chọn ngày hôm nay");
        JButton clear = smallButton("Xóa ngày", "Bỏ giới hạn ngày này");
        today.addActionListener(event -> setSelectedDate(LocalDate.now()));
        clear.addActionListener(event -> setSelectedDate(null));
        shortcuts.add(today);
        shortcuts.add(clear);
        content.add(header, BorderLayout.NORTH);
        content.add(grid, BorderLayout.CENTER);
        content.add(shortcuts, BorderLayout.SOUTH);
        content.setPreferredSize(new Dimension(278, 300));
        popup.setLayout(new BorderLayout());
        popup.setFocusable(true);
        popup.add(content, BorderLayout.CENTER);
        popup.setBorder(BorderFactory.createLineBorder(UIHelper.BORDER_COLOR));
        popup.addPopupMenuListener(new PopupMenuListener() {
            @Override public void popupMenuWillBecomeVisible(PopupMenuEvent event) {
                KeyboardFocusManager.getCurrentKeyboardFocusManager().addPropertyChangeListener("permanentFocusOwner", focusWatcher);
            }
            @Override public void popupMenuWillBecomeInvisible(PopupMenuEvent event) { stopWatchingFocus(); }
            @Override public void popupMenuCanceled(PopupMenuEvent event) { stopWatchingFocus(); }
        });
        bindCalendarKeys(content);
        bindCalendarKeys(previous);
        bindCalendarKeys(next);
        bindCalendarKeys(today);
        bindCalendarKeys(clear);
    }

    private JButton smallButton(String text, String accessibleName) {
        JButton button = new JButton(text);
        button.setFont(UIHelper.FONT_NORMAL);
        button.setMargin(new java.awt.Insets(3, 3, 3, 3));
        button.setBackground(new Color(248, 250, 252));
        button.setForeground(UIHelper.TEXT_MAIN);
        button.getAccessibleContext().setAccessibleName(accessibleName);
        return button;
    }

    private void showCalendar() {
        if (!isEnabled() || !input.isEnabled() || !input.isEditable() || !isShowing()) return;
        LocalDate selected = getSelectedDate();
        focusedDate = selected == null ? LocalDate.now() : selected;
        shownMonth = YearMonth.from(focusedDate);
        renderMonth();
        popup.show(this, 0, getHeight());
        requestDayFocus();
    }

    private void moveMonth(int delta) {
        shownMonth = shownMonth.plusMonths(delta);
        focusedDate = shownMonth.atDay(Math.min(focusedDate.getDayOfMonth(), shownMonth.lengthOfMonth()));
        renderMonth();
        requestDayFocus();
    }

    private void moveDay(int delta) {
        focusedDate = focusedDate.plusDays(delta);
        YearMonth target = YearMonth.from(focusedDate);
        if (!target.equals(shownMonth)) {
            shownMonth = target;
            renderMonth();
        }
        requestDayFocus();
    }

    private void requestDayFocus() {
        SwingUtilities.invokeLater(() -> {
            JButton button = dayButtons.get(focusedDate);
            if (popup.isVisible() && button != null) button.requestFocusInWindow();
        });
    }

    private void renderMonth() {
        monthTitle.setText(MONTH.format(shownMonth));
        dayButtons.clear();
        days.removeAll();
        LocalDate selected = getSelectedDate();
        for (LocalDate date : calendarDays(shownMonth)) {
            if (date == null) {
                days.add(new JLabel());
                continue;
            }
            JButton button = smallButton(Integer.toString(date.getDayOfMonth()), "Chọn ngày " + DATE.format(date));
            if (date.equals(selected)) {
                button.setBackground(UIHelper.PRIMARY);
                button.setForeground(Color.WHITE);
            } else if (date.equals(LocalDate.now())) {
                button.setForeground(UIHelper.PRIMARY);
                button.setFont(UIHelper.FONT_BOLD);
            }
            button.addActionListener(event -> setSelectedDate(date));
            button.addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent event) { focusedDate = date; }
            });
            bindCalendarKeys(button);
            dayButtons.put(date, button);
            days.add(button);
        }
        days.revalidate();
        days.repaint();
    }

    /** Lưới 6 tuần, tuần bắt đầu thứ Hai; ô ngoài tháng là null. */
    static List<LocalDate> calendarDays(YearMonth month) {
        List<LocalDate> result = new ArrayList<>(42);
        int offset = month.atDay(1).getDayOfWeek().getValue() - 1;
        for (int cell = 0; cell < 42; cell++) {
            int day = cell - offset + 1;
            result.add(day >= 1 && day <= month.lengthOfMonth() ? month.atDay(day) : null);
        }
        return Collections.unmodifiableList(result);
    }

    private void bindCalendarKeys(JComponent component) {
        bind(component, KeyEvent.VK_LEFT, 0, "previous-day", () -> moveDay(-1));
        bind(component, KeyEvent.VK_RIGHT, 0, "next-day", () -> moveDay(1));
        bind(component, KeyEvent.VK_UP, 0, "previous-week", () -> moveDay(-7));
        bind(component, KeyEvent.VK_DOWN, 0, "next-week", () -> moveDay(7));
        bind(component, KeyEvent.VK_ESCAPE, 0, "close-calendar", () -> {
            popup.setVisible(false);
            input.requestFocusInWindow();
        });
        bind(component, KeyEvent.VK_TAB, 0, "leave-calendar", () -> {
            popup.setVisible(false);
            input.requestFocusInWindow();
            input.transferFocus();
        });
        bind(component, KeyEvent.VK_TAB, KeyEvent.SHIFT_DOWN_MASK, "leave-calendar-backward", () -> {
            popup.setVisible(false);
            input.requestFocusInWindow();
            input.transferFocusBackward();
        });
    }

    private void bind(JComponent component, int key, int modifiers, String name, Runnable action) {
        component.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(key, modifiers), name);
        component.getActionMap().put(name, new AbstractAction() {
            @Override public void actionPerformed(ActionEvent event) { action.run(); }
        });
    }

    private void stopWatchingFocus() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().removePropertyChangeListener("permanentFocusOwner", focusWatcher);
    }

    @Override public void removeNotify() {
        popup.setVisible(false);
        stopWatchingFocus();
        super.removeNotify();
    }
}
