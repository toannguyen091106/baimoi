package bank.ui.components;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;

public class StatusBadgeRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        String status = value == null ? "" : value.toString().trim().toUpperCase();
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(isSelected ? new Color(219, 234, 254) : (row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252)));

        Color bg;
        Color fg;
        switch (status) {
            case "ACTIVE":
            case "SUCCESS":
            case "DEPOSIT":
            case "CREDIT":
                bg = new Color(209, 250, 229);
                fg = new Color(6, 95, 70);
                break;
            case "LOCKED":
            case "INACTIVE":
            case "CLOSED":
            case "WITHDRAW":
            case "DEBIT":
                bg = new Color(254, 226, 226);
                fg = new Color(153, 27, 27);
                break;
            case "TRANSFER":
            case "REVERSED":
            case "REVERSAL":
                bg = new Color(254, 243, 199);
                fg = new Color(146, 64, 14);
                break;
            case "ADMIN":
                bg = new Color(237, 233, 254);
                fg = new Color(91, 33, 182);
                break;
            default:
                bg = new Color(224, 242, 254);
                fg = new Color(3, 105, 161);
                break;
        }

        JLabel badge = new JLabel(UiLabels.text(status)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setForeground(fg);
        badge.setBorder(new EmptyBorder(3, 10, 3, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(0, 10, 0, 6);
        wrapper.add(badge, gbc);
        return wrapper;
    }
}
