package bank.ui;

import bank.config.ApplicationContext;
import bank.config.DatabaseConnection;
import bank.dao.UserDAO;
import bank.model.User;
import bank.service.AuthService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernPasswordField;
import bank.ui.components.ModernTextField;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class LoginFrame extends JFrame {
    private final AuthService authService = ApplicationContext.getBean(AuthService.class);
    private final UserDAO userDAO = ApplicationContext.getBean(UserDAO.class);

    private final ModernTextField txtUsername = new ModernTextField(DatabaseConnection.getLastLoginUsername(), 18);
    private final ModernPasswordField txtPassword = new ModernPasswordField("", 18);
    private final JCheckBox chkRemember = new JCheckBox("Ghi nhớ tên đăng nhập", DatabaseConnection.isRememberLastLogin());
    private final JComboBox<User> cbQuickAccounts = new JComboBox<>();
    private final ModernButton btnQuick1 = UIHelper.createOutlineButton("👑 Quản trị");
    private final ModernButton btnQuick2 = UIHelper.createOutlineButton("💼 Giao dịch viên");
    private boolean loadingQuickAccounts;

    public LoginFrame() {
        setTitle("Đăng nhập Hệ thống - Core Banking System (Auto-Save Enabled)");
        setSize(880, 560);
        WindowCloseHandler.install(this);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridLayout(1, 2));

        // CỘT TRÁI: Banner thương hiệu Gradient
        JPanel leftBanner = new JPanel(new BorderLayout(0, 16)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(15, 23, 42), getWidth(), getHeight(), new Color(30, 64, 175));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        leftBanner.setBorder(new EmptyBorder(34, 34, 28, 34));

        JPanel brandBox = new JPanel();
        brandBox.setLayout(new BoxLayout(brandBox, BoxLayout.Y_AXIS));
        brandBox.setOpaque(false);

        JLabel lblBadge = new JLabel("QUẢN LÝ NGÂN HÀNG");
        lblBadge.setFont(UIHelper.FONT_SMALL);
        lblBadge.setForeground(new Color(125, 211, 252));

        JLabel lblBrandTitle = new JLabel("<html><div style='margin-top:10px;line-height:1.3'>HỆ THỐNG QUẢN TRỊ<br>NGÂN HÀNG SỐ</div></html>");
        lblBrandTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblBrandTitle.setForeground(Color.WHITE);

        JLabel lblDesc = new JLabel("<html><div style='margin-top:14px;color:#cbd5e1;line-height:1.6'>"
                + "• Quản lý hồ sơ khách hàng và tài khoản<br>"
                + "• Nộp tiền, rút tiền và chuyển khoản<br>"
                + "• Tra cứu lịch sử và xuất danh sách giao dịch<br>"
                + "• Mọi thay đổi được tự động lưu"
                + "</div></html>");
        lblDesc.setFont(UIHelper.FONT_NORMAL);

        brandBox.add(lblBadge);
        brandBox.add(lblBrandTitle);
        brandBox.add(lblDesc);

        JPanel bottomLeftBox = new JPanel(new BorderLayout(0, 8));
        bottomLeftBox.setOpaque(false);
        String mode = DatabaseConnection.isMySqlMode()
                ? "🟢 Đang kết nối cơ sở dữ liệu"
                : "💾 Dữ liệu cục bộ • Tự động lưu";
        JLabel lblMode = new JLabel(mode);
        lblMode.setFont(UIHelper.FONT_BOLD);
        lblMode.setForeground(new Color(167, 243, 208));

        bottomLeftBox.add(lblMode, BorderLayout.NORTH);

        leftBanner.add(brandBox, BorderLayout.CENTER);
        leftBanner.add(bottomLeftBox, BorderLayout.SOUTH);

        // CỘT PHẢI: Biểu mẫu đăng nhập thông minh
        JPanel rightForm = new JPanel(new BorderLayout());
        rightForm.setBackground(Color.WHITE);
        rightForm.setBorder(new EmptyBorder(26, 38, 24, 38));

        JPanel formContent = new JPanel();
        formContent.setLayout(new BoxLayout(formContent, BoxLayout.Y_AXIS));
        formContent.setOpaque(false);

        JLabel lblWelcome = new JLabel("Đăng nhập hệ thống");
        lblWelcome.setFont(UIHelper.FONT_HERO);
        lblWelcome.setForeground(UIHelper.TEXT_MAIN);
        lblWelcome.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSub = new JLabel("Chọn tài khoản và nhập mật khẩu để tiếp tục.");
        lblSub.setFont(UIHelper.FONT_SMALL);
        lblSub.setForeground(UIHelper.TEXT_MUTED);
        lblSub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel userGroup = UIHelper.createFieldGroup("Tên đăng nhập", txtUsername);
        userGroup.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel passGroup = UIHelper.createFieldGroup("Mật khẩu", txtPassword);
        passGroup.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel checkPanel = new JPanel(new GridLayout(2, 1, 0, 2));
        checkPanel.setOpaque(false);
        checkPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        checkPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JCheckBox chkShowPass = new JCheckBox("Hiển thị mật khẩu");
        chkShowPass.setOpaque(false);
        chkShowPass.setFont(UIHelper.FONT_SMALL);
        chkShowPass.setForeground(UIHelper.TEXT_MUTED);
        final char defaultEcho = txtPassword.getEchoChar();
        chkShowPass.addActionListener(e -> txtPassword.setEchoChar(chkShowPass.isSelected() ? (char) 0 : defaultEcho));

        chkRemember.setOpaque(false);
        chkRemember.setFont(UIHelper.FONT_SMALL);
        chkRemember.setForeground(UIHelper.TEXT_MAIN);

        checkPanel.add(chkShowPass);
        checkPanel.add(chkRemember);

        ModernButton btnLogin = UIHelper.createButton("ĐĂNG NHẬP HỆ THỐNG", UIHelper.PRIMARY);
        btnLogin.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        // Khu vực đăng nhập nhanh đồng bộ với dữ liệu đã lưu
        JLabel lblQuick = new JLabel("Chọn nhanh tài khoản (vẫn cần nhập mật khẩu):");
        lblQuick.setFont(UIHelper.FONT_SMALL);
        lblQuick.setForeground(UIHelper.TEXT_MUTED);
        lblQuick.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel quickRolePanel = new JPanel(new GridLayout(1, 2, 10, 0));
        quickRolePanel.setOpaque(false);
        quickRolePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        quickRolePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        quickRolePanel.add(btnQuick1);
        quickRolePanel.add(btnQuick2);

        cbQuickAccounts.setFont(UIHelper.FONT_NORMAL);
        cbQuickAccounts.setAlignmentX(Component.LEFT_ALIGNMENT);
        cbQuickAccounts.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        cbQuickAccounts.setRenderer((list, value, index, selected, focused) -> {
            JLabel label = (JLabel) new DefaultListCellRenderer()
                    .getListCellRendererComponent(list, value, index, selected, focused);
            label.setText(value == null ? "Chọn tên đăng nhập" : value.getUsername()
                    + " — " + UiLabels.text(value.getRole()));
            return label;
        });
        cbQuickAccounts.addActionListener(e -> {
            User selected = (User) cbQuickAccounts.getSelectedItem();
            if (!loadingQuickAccounts && selected != null) {
                fillQuickUser(selected);
            }
        });

        reloadQuickLoginOptions();

        btnLogin.addActionListener(e -> {
            try {
                User user = authService.login(txtUsername.getText(), new String(txtPassword.getPassword()), chkRemember.isSelected());
                dispose();
                new MainFrame(user).setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Từ chối truy cập", JOptionPane.ERROR_MESSAGE);
            }
        });

        formContent.add(lblWelcome);
        formContent.add(Box.createVerticalStrut(3));
        formContent.add(lblSub);
        formContent.add(Box.createVerticalStrut(14));
        formContent.add(userGroup);
        formContent.add(Box.createVerticalStrut(10));
        formContent.add(passGroup);
        formContent.add(Box.createVerticalStrut(6));
        formContent.add(checkPanel);
        formContent.add(Box.createVerticalStrut(12));
        formContent.add(btnLogin);
        formContent.add(Box.createVerticalStrut(14));
        formContent.add(lblQuick);
        formContent.add(Box.createVerticalStrut(6));
        formContent.add(quickRolePanel);
        formContent.add(Box.createVerticalStrut(8));
        formContent.add(cbQuickAccounts);

        rightForm.add(formContent, BorderLayout.CENTER);
        getRootPane().setDefaultButton(btnLogin);

        root.add(leftBanner);
        root.add(rightForm);
        setContentPane(root);
    }

    private void reloadQuickLoginOptions() {
        List<User> allUsers = userDAO.findAll();
        loadingQuickAccounts = true;
        cbQuickAccounts.removeAllItems();
        for (User u : allUsers) {
            if ("ACTIVE".equalsIgnoreCase(u.getStatus())) cbQuickAccounts.addItem(u);
        }
        cbQuickAccounts.setSelectedIndex(-1);
        loadingQuickAccounts = false;

        User u1 = allUsers.stream().filter(u -> "ACTIVE".equalsIgnoreCase(u.getStatus())
                && "ADMIN".equalsIgnoreCase(u.getRole())).findFirst().orElse(null);
        User u2 = allUsers.stream().filter(u -> "ACTIVE".equalsIgnoreCase(u.getStatus())
                && "STAFF".equalsIgnoreCase(u.getRole())).findFirst().orElse(null);
        btnQuick1.setEnabled(u1 != null);
        btnQuick2.setEnabled(u2 != null);

        if (u1 != null) {
            final User target1 = u1;
            String icon1 = "ADMIN".equalsIgnoreCase(target1.getRole()) ? "👑 " : "💼 ";
            btnQuick1.setText(icon1 + target1.getUsername());
            for (ActionListener al : btnQuick1.getActionListeners()) btnQuick1.removeActionListener(al);
            btnQuick1.addActionListener(e -> fillQuickUser(target1));
        }

        if (u2 != null) {
            final User target2 = u2;
            String icon2 = "ADMIN".equalsIgnoreCase(target2.getRole()) ? "👑 " : "💼 ";
            btnQuick2.setText(icon2 + target2.getUsername());
            for (ActionListener al : btnQuick2.getActionListeners()) btnQuick2.removeActionListener(al);
            btnQuick2.addActionListener(e -> fillQuickUser(target2));
        }
    }

    private void fillQuickUser(User user) {
        txtUsername.setText(user.getUsername());
        txtPassword.setText("");
        txtPassword.requestFocusInWindow();
    }
}
