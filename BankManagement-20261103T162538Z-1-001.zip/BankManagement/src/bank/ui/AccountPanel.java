package bank.ui;

import bank.config.ApplicationContext;
import bank.model.AccountStatusHistory;
import bank.model.BankAccount;
import bank.model.Customer;
import bank.model.User;
import bank.service.AccountService;
import bank.service.CustomerService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernTextField;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import bank.util.MoneyUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

public class AccountPanel extends JPanel {
    private final MainFrame parent;
    private final User currentUser;
    private final AccountService accountService = ApplicationContext.getBean(AccountService.class);
    private final CustomerService customerService = ApplicationContext.getBean(CustomerService.class);

    private final ModernTextField txtSearch = new ModernTextField("", 12);
    private final JComboBox<String> cbStatusFilter = new JComboBox<>(new String[]{"ALL", "ACTIVE", "LOCKED", "CLOSED"});
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final ModernButton btnTransact = UIHelper.createButton("💸 Giao dịch", UIHelper.PRIMARY);
    private final ModernButton btnLock = UIHelper.createButton("🔒 Khóa / mở khóa", UIHelper.WARNING);
    private final ModernButton btnCloseAcc = UIHelper.createButton("🚫 Đóng tài khoản", UIHelper.DANGER);
    private List<BankAccount> displayedList = new ArrayList<>();

    public AccountPanel(MainFrame parent, User currentUser) {
        this.parent = parent;
        this.currentUser = currentUser;
        setLayout(new BorderLayout(0, 16));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));

        RoundedCard topBar = new RoundedCard(new BorderLayout(8, 0));
        topBar.setBorder(new EmptyBorder(12, 16, 12, 16));

        JPanel leftSearch = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftSearch.setOpaque(false);
        leftSearch.add(new JLabel("🔍 Số TK / Chủ TK:"));
        leftSearch.add(txtSearch);
        leftSearch.add(new JLabel("Trạng thái:"));
        UiLabels.localizeCombo(cbStatusFilter);
        leftSearch.add(cbStatusFilter);

        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        rightActions.setOpaque(false);
        ModernButton btnOpen = UIHelper.createButton("+ Mở TK", UIHelper.SUCCESS);
        ModernButton btnHistory = UIHelper.createOutlineButton("📋 Nhật ký trạng thái");

        rightActions.add(btnOpen);
        rightActions.add(btnTransact);
        rightActions.add(btnLock);
        rightActions.add(btnCloseAcc);
        rightActions.add(btnHistory);

        topBar.add(leftSearch, BorderLayout.NORTH);
        topBar.add(rightActions, BorderLayout.SOUTH);

        RoundedCard tableCard = new RoundedCard(new BorderLayout());
        tableCard.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[] cols = {"Số tài khoản", "Chủ tài khoản", "Số dư khả dụng", "Loại tiền", "Trạng thái", "Ngày mở"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        UIHelper.setupModernTable(table);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { refreshTable(); }
            public void removeUpdate(DocumentEvent e) { refreshTable(); }
            public void changedUpdate(DocumentEvent e) { refreshTable(); }
        });
        cbStatusFilter.addActionListener(e -> refreshTable());

        btnOpen.addActionListener(e -> showOpenAccountDialog());
        btnLock.addActionListener(e -> toggleAccountLock());
        btnCloseAcc.addActionListener(e -> closeSelectedAccount());
        btnHistory.addActionListener(e -> showStatusHistoryDialog());
        btnTransact.addActionListener(e -> {
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một tài khoản trong bảng.");
                return;
            }
            BankAccount acc = displayedList.get(table.convertRowIndexToModel(viewRow));
            parent.navigateToTransactionTab(acc.getAccountNumber());
        });
        table.getSelectionModel().addListSelectionListener(e -> updateSelectionActions());

        add(topBar, BorderLayout.NORTH);
        add(tableCard, BorderLayout.CENTER);
        refreshTable();
    }

    public void refreshTable() {
        String kw = txtSearch.getText().trim().toLowerCase();
        String status = (String) cbStatusFilter.getSelectedItem();
        displayedList = accountService.getAllAccounts().stream()
                .filter(a -> (kw.isEmpty() || a.getAccountNumber().contains(kw) || a.getCustomerName().toLowerCase().contains(kw))
                        && ("ALL".equals(status) || a.getStatus().equalsIgnoreCase(status)))
                .collect(Collectors.toList());

        tableModel.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        for (BankAccount a : displayedList) {
            tableModel.addRow(new Object[]{
                    a.getAccountNumber(), a.getCustomerName(),
                    MoneyUtils.formatVND(a.getBalance()), a.getCurrency(),
                    a.getStatus(), a.getCreatedAt().format(fmt)
            });
        }
        updateSelectionActions();
    }

    private BankAccount selectedAccount() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) return null;
        int modelRow = table.convertRowIndexToModel(viewRow);
        return modelRow >= 0 && modelRow < displayedList.size() ? displayedList.get(modelRow) : null;
    }

    private void updateSelectionActions() {
        BankAccount selected = selectedAccount();
        boolean active = selected != null && "ACTIVE".equalsIgnoreCase(selected.getStatus());
        boolean closed = selected != null && "CLOSED".equalsIgnoreCase(selected.getStatus());
        btnTransact.setEnabled(active);
        btnLock.setEnabled(selected != null && !closed);
        btnLock.setText(selected != null && "LOCKED".equalsIgnoreCase(selected.getStatus())
                ? "🔓 Mở khóa" : "🔒 Khóa tài khoản");
        btnCloseAcc.setEnabled(selected != null && !closed && selected.getBalance().compareTo(BigDecimal.ZERO) == 0);
        btnCloseAcc.setToolTipText("Chọn tài khoản chưa đóng, có số dư bằng 0 VND để đóng.");
        btnTransact.setToolTipText("Chọn tài khoản đang hoạt động để thực hiện giao dịch.");
    }

    private void showOpenAccountDialog() {
        showOpenAccountDialog(null);
    }

    /** Mở biểu mẫu với đúng khách hàng được chọn ở màn hình hồ sơ. */
    public void openAccountForCustomer(Customer customer) {
        if (customer == null || !"ACTIVE".equalsIgnoreCase(customer.getStatus())) {
            JOptionPane.showMessageDialog(this, "Hãy chọn khách hàng đang hoạt động để mở tài khoản.",
                    "Không thể mở tài khoản", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        showOpenAccountDialog(customer);
    }

    private void showOpenAccountDialog(Customer initialCustomer) {
        List<Customer> activeCustomers = customerService.getAllCustomers().stream()
                .filter(c -> "ACTIVE".equalsIgnoreCase(c.getStatus()))
                .collect(Collectors.toList());

        if (activeCustomers.isEmpty()) {
            int choice = JOptionPane.showConfirmDialog(this,
                    "Chưa có khách hàng đang hoạt động.\nBạn có muốn tạo khách hàng để tiếp tục mở tài khoản?",
                    "Tạo khách hàng trước", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) parent.createCustomerForAccount();
            return;
        }
        if (initialCustomer != null && activeCustomers.stream().noneMatch(c -> c.getId() == initialCustomer.getId())) {
            JOptionPane.showMessageDialog(this,
                    "Khách hàng đã chọn không còn ở trạng thái hoạt động. Vui lòng kiểm tra lại hồ sơ.",
                    "Không thể mở tài khoản", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        final boolean[] createCustomerRequested = {false};
        final BankAccount[] createdAccount = new BankAccount[1];
        JDialog dialog = new JDialog(parent, "Mở tài khoản thanh toán", true);
        dialog.setSize(600, 390);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(18, 22, 14, 22));

        ModernTextField txtNextAcc = new ModernTextField(accountService.generateUniqueAccountNumber());
        txtNextAcc.setEditable(false);
        JComboBox<Customer> cbCustomer = new JComboBox<>(activeCustomers.toArray(new Customer[0]));
        if (initialCustomer != null) {
            for (Customer customer : activeCustomers) {
                if (customer.getId() == initialCustomer.getId()) {
                    cbCustomer.setSelectedItem(customer);
                    break;
                }
            }
        }
        ModernTextField txtInitMoney = new ModernTextField("0");
        JLabel lblEligibility = new JLabel(" ");
        lblEligibility.setFont(UIHelper.FONT_SMALL);
        ModernButton btnCreate = UIHelper.createButton("Mở tài khoản", UIHelper.SUCCESS);

        Runnable updateCheck = () -> {
            Customer selected = (Customer) cbCustomer.getSelectedItem();
            String err = accountService.checkAccountEligibilityError(selected);
            if (err == null) {
                lblEligibility.setForeground(new Color(6, 95, 70));
                lblEligibility.setText("<html><div style='width:300px'>✔ Khách hàng đủ điều kiện mở tài khoản mới. "
                        + "Mỗi khách hàng được có một tài khoản chưa đóng.</div></html>");
            } else {
                lblEligibility.setForeground(UIHelper.DANGER);
                lblEligibility.setText("<html><div style='width:300px'>✖ " + UiLabels.html(err) + "</div></html>");
            }
            btnCreate.setEnabled(err == null);
        };
        cbCustomer.addActionListener(e -> updateCheck.run());
        updateCheck.run();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 6, 7, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.32;
        JLabel l1 = new JLabel("Số tài khoản cấp mới:");
        l1.setFont(UIHelper.FONT_BOLD);
        form.add(l1, gbc);
        gbc.gridx = 1; gbc.weightx = 0.68;
        form.add(txtNextAcc, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.32;
        JLabel l2 = new JLabel("Chủ tài khoản (*):");
        l2.setFont(UIHelper.FONT_BOLD);
        form.add(l2, gbc);
        gbc.gridx = 1; gbc.weightx = 0.68;
        form.add(cbCustomer, gbc);

        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 0.68;
        form.add(lblEligibility, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.32;
        JLabel l3 = new JLabel("Tiền nộp ban đầu (VND):");
        l3.setFont(UIHelper.FONT_BOLD);
        form.add(l3, gbc);
        gbc.gridx = 1; gbc.weightx = 0.68;
        form.add(txtInitMoney, gbc);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        footer.setBackground(new Color(248, 250, 252));
        ModernButton btnNewCustomer = UIHelper.createOutlineButton("+ Thêm khách hàng");
        ModernButton btnCancel = UIHelper.createOutlineButton("Hủy");

        btnNewCustomer.addActionListener(e -> {
            createCustomerRequested[0] = true;
            dialog.dispose();
        });
        btnCancel.addActionListener(e -> dialog.dispose());
        btnCreate.addActionListener(e -> {
            try {
                Customer cust = (Customer) cbCustomer.getSelectedItem();
                String cleaned = txtInitMoney.getText().trim().replace(".", "").replace(",", "").replace(" ", "");
                BigDecimal initDeposit = cleaned.isEmpty() || "0".equals(cleaned)
                        ? BigDecimal.ZERO
                        : MoneyUtils.parseAmount(cleaned);
                createdAccount[0] = accountService.openAccount(cust, initDeposit, currentUser);
                dialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Không thể mở tài khoản", JOptionPane.ERROR_MESSAGE);
            }
        });

        footer.add(btnNewCustomer);
        footer.add(btnCancel);
        footer.add(btnCreate);
        dialog.add(form, BorderLayout.CENTER);
        dialog.add(footer, BorderLayout.SOUTH);
        dialog.setVisible(true);
        if (createCustomerRequested[0]) {
            parent.createCustomerForAccount();
        } else if (createdAccount[0] != null) {
            BankAccount created = createdAccount[0];
            parent.refreshAllViews();
            Object[] options = {"Giao dịch ngay", "Đóng"};
            int choice = JOptionPane.showOptionDialog(this,
                    "Đã mở tài khoản " + created.getAccountNumber() + " cho " + created.getCustomerName()
                            + ".\nSố dư: " + MoneyUtils.formatVND(created.getBalance()),
                    "Mở tài khoản thành công", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);
            if (choice == 0) parent.navigateToTransactionTab(created.getAccountNumber());
        }
    }

    private void toggleAccountLock() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một tài khoản trong bảng.");
            return;
        }
        BankAccount acc = displayedList.get(table.convertRowIndexToModel(viewRow));
        String actionName = "ACTIVE".equalsIgnoreCase(acc.getStatus()) ? "KHÓA" : "MỞ KHÓA";
        String reason = JOptionPane.showInputDialog(this,
                "Nhập lý do " + actionName + " tài khoản " + acc.getAccountNumber() + " (" + acc.getCustomerName() + "):");
        if (reason != null) {
            try {
                accountService.toggleLockStatus(acc, reason, currentUser);
                parent.refreshAllViews();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void closeSelectedAccount() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một tài khoản trong bảng để đóng.");
            return;
        }
        BankAccount acc = displayedList.get(table.convertRowIndexToModel(viewRow));
        String reason = JOptionPane.showInputDialog(this,
                "Nhập lý do ĐÓNG tài khoản " + acc.getAccountNumber() + " (Yêu cầu số dư = 0 VND):");
        if (reason != null) {
            try {
                accountService.closeAccount(acc, reason, currentUser);
                parent.refreshAllViews();
                JOptionPane.showMessageDialog(this, "Đã đóng tài khoản " + acc.getAccountNumber() + " và lưu nhật ký!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể đóng tài khoản", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showStatusHistoryDialog() {
        Long filterAccountId = null;
        String titleSuffix = "Toàn hệ thống";
        int viewRow = table.getSelectedRow();
        if (viewRow >= 0) {
            BankAccount acc = displayedList.get(table.convertRowIndexToModel(viewRow));
            filterAccountId = acc.getId();
            titleSuffix = "TK " + acc.getAccountNumber() + " (" + acc.getCustomerName() + ")";
        }

        List<AccountStatusHistory> histories = accountService.getStatusHistory(filterAccountId);
        JDialog dialog = new JDialog(parent, "Nhật ký Thay đổi Trạng thái Tài khoản - " + titleSuffix, true);
        dialog.setSize(740, 360);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        String[] cols = {"ID", "Số Tài khoản", "Trạng thái cũ", "Trạng thái mới", "Lý do thực hiện", "Người thực hiện", "Thời gian"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        for (AccountStatusHistory h : histories) {
            model.addRow(new Object[]{
                    "#" + h.getId(), h.getAccountNumber(), h.getOldStatus(), h.getNewStatus(),
                    h.getReason(), h.getChangedBy(), h.getChangedAt().format(fmt)
            });
        }
        JTable tblHist = new JTable(model);
        UIHelper.setupModernTable(tblHist);

        dialog.add(new JScrollPane(tblHist), BorderLayout.CENTER);
        dialog.setVisible(true);
    }
}
