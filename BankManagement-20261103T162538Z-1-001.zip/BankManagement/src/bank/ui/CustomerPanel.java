package bank.ui;

import bank.config.ApplicationContext;
import bank.model.Customer;
import bank.service.CustomerService;
import bank.ui.components.ModernButton;
import bank.ui.components.ModernTextField;
import bank.ui.components.RoundedCard;
import bank.ui.components.UIHelper;
import bank.ui.components.UiLabels;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

public class CustomerPanel extends JPanel {
    private final MainFrame parent;
    private final CustomerService customerService = ApplicationContext.getBean(CustomerService.class);
    private final ModernTextField txtSearch = new ModernTextField("", 15);
    private final JComboBox<String> cbStatusFilter = new JComboBox<>(new String[]{"ALL", "ACTIVE", "INACTIVE"});
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final ModernButton btnEdit = UIHelper.createButton("✏️ Sửa hồ sơ", UIHelper.PRIMARY);
    private final ModernButton btnToggleStatus = UIHelper.createButton("🔄 Đổi trạng thái", UIHelper.WARNING);
    private final ModernButton btnOpenAccount = UIHelper.createButton("💳 Mở tài khoản", UIHelper.PRIMARY);
    private List<Customer> currentList = new ArrayList<>();

    public CustomerPanel(MainFrame parent) {
        this.parent = parent;
        setLayout(new BorderLayout(0, 16));
        setBackground(UIHelper.APP_BG);
        setBorder(new EmptyBorder(20, 24, 20, 24));

        RoundedCard topBar = new RoundedCard(new BorderLayout(10, 0));
        topBar.setBorder(new EmptyBorder(12, 16, 12, 16));

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchBox.setOpaque(false);
        searchBox.add(new JLabel("🔍 Tìm kiếm:"));
        searchBox.add(txtSearch);
        searchBox.add(new JLabel("Trạng thái:"));
        UiLabels.localizeCombo(cbStatusFilter);
        searchBox.add(cbStatusFilter);

        JPanel actionBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actionBox.setOpaque(false);
        ModernButton btnAdd = UIHelper.createButton("+ Thêm Khách hàng", UIHelper.SUCCESS);
        actionBox.add(btnAdd);
        actionBox.add(btnEdit);
        actionBox.add(btnToggleStatus);
        actionBox.add(btnOpenAccount);

        topBar.add(searchBox, BorderLayout.NORTH);
        topBar.add(actionBox, BorderLayout.SOUTH);

        RoundedCard tableCard = new RoundedCard(new BorderLayout());
        tableCard.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[] cols = {"Mã KH", "Họ và tên", "Ngày sinh", "Số điện thoại", "Email", "Địa chỉ", "Trạng thái"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        UIHelper.setupModernTable(table);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterData(); }
            public void removeUpdate(DocumentEvent e) { filterData(); }
            public void changedUpdate(DocumentEvent e) { filterData(); }
        });
        cbStatusFilter.addActionListener(e -> filterData());

        btnAdd.addActionListener(e -> addCustomerAndOfferAccount());
        btnEdit.addActionListener(e -> editSelectedCustomer());
        btnToggleStatus.addActionListener(e -> toggleCustomerStatus());
        btnOpenAccount.addActionListener(e -> {
            Customer selected = selectedCustomer();
            if (selected != null) parent.openAccountForCustomer(selected);
        });
        table.getSelectionModel().addListSelectionListener(e -> updateSelectionActions());

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() >= 0) {
                    editSelectedCustomer();
                }
            }
        });

        add(topBar, BorderLayout.NORTH);
        add(tableCard, BorderLayout.CENTER);
        refreshTable();
    }

    private void filterData() {
        currentList = customerService.searchCustomers(txtSearch.getText(), (String) cbStatusFilter.getSelectedItem());
        fillTable();
    }

    public void refreshTable() {
        filterData();
    }

    private void fillTable() {
        tableModel.setRowCount(0);
        for (Customer c : currentList) {
            tableModel.addRow(new Object[]{
                    c.getCustomerCode(), c.getFullName(), c.getDateOfBirth(),
                    c.getPhone(), c.getEmail(), c.getAddress(), c.getStatus()
            });
        }
        updateSelectionActions();
    }

    private Customer selectedCustomer() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) return null;
        int modelRow = table.convertRowIndexToModel(viewRow);
        return modelRow >= 0 && modelRow < currentList.size() ? currentList.get(modelRow) : null;
    }

    private void updateSelectionActions() {
        Customer selected = selectedCustomer();
        btnEdit.setEnabled(selected != null);
        btnToggleStatus.setEnabled(selected != null);
        btnOpenAccount.setEnabled(selected != null && "ACTIVE".equalsIgnoreCase(selected.getStatus()));
        btnToggleStatus.setText(selected != null && "ACTIVE".equalsIgnoreCase(selected.getStatus())
                ? "⏸ Ngừng hoạt động" : "▶ Kích hoạt");
    }

    private void addCustomerAndOfferAccount() {
        Customer created = showCustomerDialog(null);
        if (created == null) return;
        Object[] options = {"Mở tài khoản", "Để sau"};
        int choice = JOptionPane.showOptionDialog(this,
                "Đã lưu khách hàng " + created.getFullName() + " (" + created.getCustomerCode()
                        + ").\nBạn có muốn mở tài khoản cho khách hàng này?",
                "Đã tạo khách hàng", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);
        if (choice == 0) parent.openAccountForCustomer(created);
    }

    /** Tạo khách hàng và tiếp tục bước mở tài khoản khi biểu mẫu đã đóng. */
    public void createCustomerForAccount() {
        Customer created = showCustomerDialog(null);
        if (created != null) parent.openAccountForCustomer(created);
    }

    private void editSelectedCustomer() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một khách hàng trên bảng để chỉnh sửa.");
            return;
        }
        int modelRow = table.convertRowIndexToModel(viewRow);
        showCustomerDialog(currentList.get(modelRow));
    }

    private void toggleCustomerStatus() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một khách hàng trên bảng.");
            return;
        }
        Customer c = currentList.get(table.convertRowIndexToModel(viewRow));
        String nextStatus = "ACTIVE".equalsIgnoreCase(c.getStatus()) ? "INACTIVE" : "ACTIVE";
        int confirm = JOptionPane.showConfirmDialog(this,
                "Đổi trạng thái khách hàng " + c.getFullName() + " thành \"" + UiLabels.text(nextStatus) + "\"?",
                "Xác nhận đổi trạng thái", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            customerService.updateCustomer(c, c.getFullName(), c.getDateOfBirth().toString(),
                    c.getPhone(), c.getEmail(), c.getAddress(), nextStatus);
            parent.refreshAllViews();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không thể đổi trạng thái", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Customer showCustomerDialog(Customer editing) {
        final Customer[] savedCustomer = new Customer[1];
        JDialog dialog = new JDialog(parent, editing == null ? "Thêm Hồ sơ Khách hàng Mới" : "Cập nhật Hồ sơ Khách hàng", true);
        dialog.setSize(520, 470);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(Color.WHITE);
        content.setBorder(new EmptyBorder(18, 24, 18, 24));

        ModernTextField txtCode = new ModernTextField(editing != null ? editing.getCustomerCode() : customerService.generateNextCustomerCode());
        txtCode.setEditable(editing == null);
        ModernTextField txtName = new ModernTextField(editing != null ? editing.getFullName() : "");
        ModernTextField txtDob = new ModernTextField(editing != null && editing.getDateOfBirth() != null ? editing.getDateOfBirth().toString() : "");
        txtDob.setToolTipText("Nhập năm-tháng-ngày, ví dụ: 2000-11-09");
        ModernTextField txtPhone = new ModernTextField(editing != null ? editing.getPhone() : "");
        ModernTextField txtEmail = new ModernTextField(editing != null ? editing.getEmail() : "");
        ModernTextField txtAddress = new ModernTextField(editing != null ? editing.getAddress() : "");
        JComboBox<String> cbStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});
        UiLabels.localizeCombo(cbStatus);
        if (editing != null) cbStatus.setSelectedItem(editing.getStatus());
        cbStatus.setEnabled(editing != null);

        String[] labels = {
                "Mã khách hàng (*):",
                "Họ và tên (*):",
                "Ngày sinh (*, yyyy-MM-dd):",
                "Số điện thoại (Duy nhất *):",
                "Email (Duy nhất *):",
                "Địa chỉ (*):",
                "Trạng thái:"
        };
        JComponent[] fields = {txtCode, txtName, txtDob, txtPhone, txtEmail, txtAddress, cbStatus};

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 0.35;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(UIHelper.FONT_BOLD);
            content.add(lbl, gbc);

            gbc.gridx = 1;
            gbc.weightx = 0.65;
            content.add(fields[i], gbc);
        }

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        footer.setBackground(new Color(248, 250, 252));
        ModernButton btnCancel = UIHelper.createOutlineButton("Hủy bỏ");
        ModernButton btnSave = UIHelper.createButton("Lưu Hồ sơ", UIHelper.SUCCESS);

        btnCancel.addActionListener(e -> dialog.dispose());
        btnSave.addActionListener(e -> {
            try {
                if (editing == null) {
                    customerService.addCustomer(txtCode.getText(), txtName.getText(), txtDob.getText(),
                            txtPhone.getText(), txtEmail.getText(), txtAddress.getText());
                    savedCustomer[0] = customerService.getAllCustomers().stream()
                            .filter(c -> c.getCustomerCode().equalsIgnoreCase(txtCode.getText().trim()))
                            .findFirst().orElse(null);
                } else {
                    customerService.updateCustomer(editing, txtName.getText(), txtDob.getText(),
                            txtPhone.getText(), txtEmail.getText(), txtAddress.getText(), (String) cbStatus.getSelectedItem());
                    savedCustomer[0] = editing;
                }
                dialog.dispose();
                parent.refreshAllViews();
                if (editing != null) JOptionPane.showMessageDialog(this, "Đã cập nhật hồ sơ khách hàng.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Không thể lưu khách hàng", JOptionPane.ERROR_MESSAGE);
            }
        });

        footer.add(btnCancel);
        footer.add(btnSave);

        dialog.add(content, BorderLayout.CENTER);
        dialog.add(footer, BorderLayout.SOUTH);
        dialog.setVisible(true);
        return savedCustomer[0];
    }
}
