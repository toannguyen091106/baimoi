package bank.ui;

import bank.config.DatabaseConnection;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/** Chỉ đóng cửa sổ sau khi dữ liệu đã được ghi thành công. */
public final class WindowCloseHandler {
    private WindowCloseHandler() {}

    public static void install(JFrame window) {
        window.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent event) {
                try {
                    DatabaseConnection.saveState();
                    window.dispose();
                    System.exit(0);
                } catch (RuntimeException error) {
                    JOptionPane.showMessageDialog(window,
                            "Chưa thể lưu dữ liệu nên ứng dụng vẫn được giữ mở.\n"
                                    + "Vui lòng kiểm tra dung lượng và quyền ghi, rồi đóng lại.\n\n"
                                    + error.getMessage(),
                            "Không thể lưu dữ liệu", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
