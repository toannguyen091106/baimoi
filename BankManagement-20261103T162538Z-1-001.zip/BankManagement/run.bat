@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build.ps1" %*
set "BANK_EXIT_CODE=%ERRORLEVEL%"
if not "%BANK_EXIT_CODE%"=="0" (
    echo.
    echo Khong the chay ung dung. Vui long xem thong bao loi o tren.
    pause
)
exit /b %BANK_EXIT_CODE%
