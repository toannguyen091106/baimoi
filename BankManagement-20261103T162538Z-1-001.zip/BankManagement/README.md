# BTL Java - Quản lý ngân hàng

Ứng dụng Swing được tách theo chức năng để dễ tìm và sửa code. Không cần Maven hoặc thư viện ngoài khi dùng dữ liệu cục bộ.

## Chạy chương trình

1. Cài **JDK 11 trở lên**. Script tự tìm JDK qua `JAVA_HOME`, `D:\Java`, rồi `PATH`.
2. Trong VS Code, mở **`src/bank/Main.java`** rồi bấm nút tam giác **▶ Run Java** ở góc trên bên phải. Có thể bấm chữ **Run** phía trên hàm `main` hoặc nhấn **F5**.
3. Đăng nhập bằng `admin / admin123` hoặc `staff / staff123`.

Sau khi sửa code, đóng ứng dụng rồi bấm chạy lại để nhận thay đổi. Bạn cũng có thể bấm đúp **`run.bat`** để tự biên dịch và mở chương trình. Muốn chỉ kiểm tra biên dịch, chạy `run.bat -BuildOnly` trong terminal.

## Các luồng thao tác đã bổ sung

- **Giao dịch:** chọn tài khoản và nhập số tiền → kiểm tra tên chủ tài khoản, số tiền, số dư dự kiến → chọn **Xác nhận giao dịch**. Chọn **Quay lại sửa** sẽ giữ nguyên thông tin và chưa ghi nhận giao dịch.
- **Tìm lịch sử nhanh:** gõ một phần mã giao dịch, số tài khoản/tên chủ tài khoản hoặc tên người tạo; kết quả tự lọc sau khi ngừng gõ khoảng **0,3 giây**. Tên có thể gõ không dấu. Dùng **↑/↓ + Enter/Tab** hoặc chuột để chọn gợi ý; nút **▾** mở danh sách. **Ctrl+F** đưa con trỏ đến ô mã giao dịch, **Enter/Lọc** tìm ngay.
- **Chọn ngày:** bấm nút lịch cạnh ô ngày để chọn, hoặc nhập **dd/MM/yyyy** (tính cả hai ngày đầu và cuối); để trống để xem toàn bộ. **Hôm nay** và **7 ngày gần đây** giúp chọn nhanh. Khi nhập ngày còn dở, thông báo nằm ngay dưới bộ lọc, không bật hộp thoại liên tục. **Xuất CSV** chỉ bật khi kết quả đã cập nhật, lưu đúng danh sách và thứ tự đang hiển thị; CSV mở được bằng Excel với chữ tiếng Việt.
- **Khách hàng → tài khoản → giao dịch:** chọn khách hàng rồi bấm **Mở tài khoản**, hoặc mở tài khoản ngay sau khi lưu khách hàng mới. Sau khi mở tài khoản có thể chọn **Giao dịch ngay**.
- **Quyền quản trị:** chỉ **ADMIN** được hoàn tác giao dịch. **Khôi phục dữ liệu mẫu** nằm trong **Nhân sự & phân quyền**, chỉ dùng ở chế độ dữ liệu cục bộ; luôn tạo tệp `bank_data_store.before-reset-*.ser` trước khi thay dữ liệu và yêu cầu đăng nhập lại.
- **Đăng nhập:** tùy chọn ghi nhớ chỉ giữ tên đăng nhập; luôn cần nhập mật khẩu. Tài khoản và mật khẩu đã thiết lập vẫn dùng được; mật khẩu dạng văn bản từ bản cũ được loại khỏi tệp dữ liệu đang sử dụng khi mở bản mới.

## Tìm code ở đâu?

| Đường dẫn trong `src/bank` | Nội dung |
|---|---|
| `Main.java` | Hàm `main`; mở file này và bấm ▶ để chạy |
| `model/` | Dữ liệu người dùng, khách hàng, tài khoản, giao dịch |
| `dao/` | Đọc và ghi dữ liệu |
| `service/` | Đăng nhập và các quy tắc nghiệp vụ |
| `ui/` | Các màn hình; `components/` chứa thành phần giao diện dùng chung |
| `config/` | Khởi tạo ứng dụng, kết nối và lưu dữ liệu |
| `web/` | Trang web thống kê và API cục bộ |
| `util/` | Định dạng tiền, kiểm tra dữ liệu, xử lý mật khẩu |

Luồng xử lý chính: **giao diện → service → dao → dữ liệu**. Ví dụ sửa chuyển tiền: xem `service/TransactionService.java`; sửa màn hình giao dịch: xem `ui/TransactionPanel.java`.

## Dữ liệu và công cụ

- Dữ liệu được lưu ngay sau mỗi thay đổi vào **`data/bank_data_store.ser`**. Vị trí này cố định theo thư mục dự án, dù chạy bằng nút ▶, `run.bat` hay từ thư mục terminal khác. Khi chuyển máy, mang theo **toàn bộ thư mục `data`** để giữ dữ liệu.
- Lần mở bản mới đầu tiên sẽ chuyển dữ liệu đang có ở `bank_data_store.ser` vào `data/` và giữ lại tệp cũ. Sau đó luôn đọc tệp trong `data/`, không lấy lại dữ liệu mẫu khi mở app.
- Hệ thống giữ bản sao lưu gần nhất **`data/bank_data_store.ser.bak`**. Nếu tệp chính hỏng, chương trình sẽ thử khôi phục bản sao lưu hợp lệ; nếu cả hai không đọc được, chương trình báo lỗi và giữ nguyên tệp để xử lý.
- Chỉ một bản ứng dụng được phép dùng cùng thư mục dữ liệu tại một thời điểm, tránh bản chạy cũ ghi đè thay đổi của bản mới.
- Dữ liệu mẫu chỉ được tạo ở lần chạy đầu khi chưa có dữ liệu nào. Chức năng **Khôi phục dữ liệu mẫu** của ADMIN vẫn cần xác nhận riêng.
- Web thống kê chạy ở `http://localhost:8080`; nếu cổng bận, ứng dụng thử `8081` rồi `8090`.
- Thư mục `build/classes/` chứa kết quả biên dịch; chỉ cần sửa các file trong `src/`.
- VS Code biên dịch riêng vào `build/vscode-classes/`, còn `run.bat` dùng `build/classes/`.
- VS Code đã có cấu hình nguồn và chạy trong `.vscode/`. Khi mở dự án, chọn thư mục **BankManagement** để các cấu hình này được áp dụng.
- Dùng NetBeans, IntelliJ hoặc Eclipse: mở thư mục dự án, chọn `src` làm thư mục nguồn và chạy `bank.Main`. Đặt thư mục làm việc là thư mục chứa `run.bat` để dùng đúng dữ liệu.
- `ApplicationContext` là bộ khởi tạo đơn giản của bài tập, không phải Spring Boot.
