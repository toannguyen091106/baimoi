param(
    [switch]$BuildOnly
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot

function Find-JavaTools {
    $jdkCandidates = @()
    if ($env:JAVA_HOME) {
        $jdkCandidates += $env:JAVA_HOME
    }
    $jdkCandidates += 'D:\Java'

    foreach ($jdkPath in $jdkCandidates) {
        $compiler = Join-Path $jdkPath 'bin\javac.exe'
        $runtime = Join-Path $jdkPath 'bin\java.exe'
        if ((Test-Path -LiteralPath $compiler -PathType Leaf) -and
            (Test-Path -LiteralPath $runtime -PathType Leaf)) {
            return @{ Compiler = $compiler; Runtime = $runtime }
        }
    }

    $compilerCommand = Get-Command javac.exe -ErrorAction SilentlyContinue
    if ($compilerCommand) {
        $compiler = $compilerCommand.Source
        $runtime = Join-Path (Split-Path -Parent $compiler) 'java.exe'
        if (-not (Test-Path -LiteralPath $runtime -PathType Leaf)) {
            $runtimeCommand = Get-Command java.exe -ErrorAction SilentlyContinue
            if ($runtimeCommand) {
                $runtime = $runtimeCommand.Source
            }
        }
        if (Test-Path -LiteralPath $runtime -PathType Leaf) {
            return @{ Compiler = $compiler; Runtime = $runtime }
        }
    }

    throw 'Can JDK 11 tro len. Hay dat JAVA_HOME den thu muc JDK hoac them bin cua JDK vao PATH.'
}

try {
    Set-Location -LiteralPath $projectRoot
    $javaTools = Find-JavaTools
    $sourceRoot = Join-Path $projectRoot 'src'
    $classRoot = Join-Path $projectRoot 'build\classes'
    $sourceFiles = @(Get-ChildItem -LiteralPath $sourceRoot -Recurse -Filter '*.java' -File |
        Sort-Object FullName | ForEach-Object { $_.FullName })
    if ($sourceFiles.Count -eq 0) {
        throw 'Khong tim thay ma nguon Java trong thu muc src.'
    }

    New-Item -ItemType Directory -Path $classRoot -Force | Out-Null
    Write-Host 'Dang bien dich ma nguon...'
    & $javaTools.Compiler --release 11 -encoding UTF-8 -d $classRoot @sourceFiles
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }

    Write-Host 'Bien dich thanh cong.'
    if ($BuildOnly) {
        exit 0
    }

    Write-Host 'Dang mo Core Banking System...'
    & $javaTools.Runtime -cp $classRoot bank.Main
    exit $LASTEXITCODE
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
